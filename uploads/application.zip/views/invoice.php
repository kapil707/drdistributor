<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"><!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<section class="pt-10">
<div class="container">
<?php
error_reporting(0);
$r = $this->db->query("select tbl_sales.vdt,tbl_sales_main.status,tbl_sales_main.gstvno from tbl_sales,tbl_sales_main where tbl_sales_main.url_link='$url_link' and tbl_sales.mdatatype='insert' and tbl_sales.gstvno=tbl_sales_main.gstvno")->row();
?>
<div class="row">
	<div class="col-sm-4">
		<?php
		echo $r->gstvno;
		?>
	</div>
	<div class="col-sm-4 text-center">
	<?php
		echo date("d-M-Y", strtotime($r->vdt));
	?>
	</div>
	<div class="col-sm-4 text-right">
	<?php
		$status = "Pending";
		if($r->status==1)
		{
			$status = "Generated";
		}
		echo $status;
		?>
	</div></div>
<table class="table">
    <thead>
		<tr>
			<th>Sr.No.</th>
			<th>Item Name</th>
			<th>Batch</th>
			<th>Expiry</th>
			<th>Qty</th>
			<th>Free Qty</th>
			<th>Price</th>
			<th>GST</th>
			<th>Total</th>
		</tr>
    </thead>
    <tbody>
	<?php
	$i = 1;
	$full_total = 0;
	$total_qty = 0;
	$total_fqty = 0;
	$total_price = 0;
	$total_gst = 0;	
	$q = $this->db->query("select tbl_sales.netamt,tbl_sales.taxamt,tbl_sales.qty,tbl_sales.fqty,tbl_sales.item_name,tbl_sales.batch,tbl_sales.expiry from tbl_sales,tbl_sales_main where tbl_sales_main.url_link='$url_link' and tbl_sales.mdatatype='insert' and tbl_sales.gstvno=tbl_sales_main.gstvno order by tbl_sales.itemc asc")->result();
    foreach($q as $row)
	{
		$total_price 	= $total_price + $row->netamt;
		$total_gst 		= $total_gst + $row->taxamt;
		$total 			= round($row->netamt + $row->taxamt);
		$full_total 	= $full_total + $total;
		$total_qty 		= $total_qty + $row->qty;
		$total_fqty 	= $total_fqty + $row->fqty;
	  ?>
		<tr>
			<td><?= $i++ ?></td>
			<td><?php echo $row->item_name ?></td>
			<td><?php echo $row->batch ?></td>
			<td><?php echo $row->expiry ?></td>
			<td><?php echo number_format($row->qty) ?></td>
			<td><?php echo number_format($row->fqty) ?></td>
			<td align='right'><?php echo number_format($row->netamt,2) ?></td>
			<td align='right'><?php echo number_format($row->taxamt,2) ?></td>
			<td align='right'><?php echo number_format($total,2) ?></td>
		</tr>
		<?php }?>
		</tbody>
		<tfoot>			<tr>
				<td>
					Total
				</td>
				<td></td>
				<td></td>
				<td></td>
				<td align='right'><?php echo number_format($total_qty) ?></td>
				<td align='right'><?php echo number_format($total_fqty) ?></td>
				<td align='right'><?php echo number_format($total_price) ?></td>
				<td align='right'><?php echo number_format($total_gst) ?></td>
				<td align='right'><?php echo number_format($full_total,2) ?></td>			</tr>
		</tfoot>
	</table>
	<?php
	$q = $this->db->query("select tbl_sales_deleted.id from tbl_sales_deleted,tbl_sales_main where tbl_sales_main.url_link='$url_link' and (tbl_sales_deleted.delete_descp='F.QTY.CHANGE' or tbl_sales_deleted.delete_descp='QTY.CHANGE' or tbl_sales_deleted.delete_descp='ITEM DELETE') and tbl_sales_deleted.gstvno=tbl_sales_main.gstvno order by tbl_sales_deleted.itemc asc")->row();
	if($q->id!=""){	?>
	<br />
	<br />
	<table class="table" id="datatable">
		<thead>
			<tr>
				<th>Sr.No.</th>
				<th>Item Name</th>
				<th>Ordered Quantity</th>
				<th>Billed Quantity</th>
				<th>Descp</th>
			</tr>
		</thead>
		<tbody>
		<?php 
		$i = 1;
		$full_total = 0;
		$total_qty = 0;
		$total_fqty = 0;
		$total_price = 0;
		$total_gst = 0;
		$q = $this->db->query("select tbl_sales_deleted.item_code,tbl_sales_deleted.item_name,tbl_sales_deleted.itemc,tbl_sales_deleted.delete_remarks,tbl_sales_deleted.delete_descp,tbl_sales_deleted.delete_amt,tbl_sales_deleted.delete_namt from tbl_sales_deleted,tbl_sales_main where tbl_sales_main.url_link='$url_link' and (tbl_sales_deleted.delete_descp='F.QTY.CHANGE' or tbl_sales_deleted.delete_descp='QTY.CHANGE' or tbl_sales_deleted.delete_descp='ITEM DELETE') and tbl_sales_deleted.gstvno=tbl_sales_main.gstvno order by tbl_sales_deleted.itemc asc")->result(); 
		foreach($q as $row)
		{
		  ?>
			<tr>
				<td><?= $i++ ?>
				<td><?php echo $row->item_name ?></td>
				<td><?php echo $row->delete_amt ?></td>
				<td><?php echo $row->delete_namt ?></td>
				<td><?php echo $row->delete_descp ?></td>
			</tr>
			<?php }?>
		</tbody>
	</table>
  <?php } ?>
</div>