<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<section class="pt-10">
	<div class="container">
		<table class="table" id="datatable">
			<thead>
			  <tr>
				<th>Bill No.</th>
				<th>Bill Date</th>
				<th>Total</th>
				<th>Status</th>
				<th>View</th>
				<th>Download</th>
			  </tr>
			</thead>
			<tbody>
			<?php 
			$i = 1;
			error_reporting(0);
			$q = $this->db->query("select * from online_main_sales_tbl where acno='$usercode' order by vdt asc")->result();  
			$myv1 = $myv2 = "";
			foreach($q as $r)
			{
				$netamt[$r->gstvno] = $netamt[$r->gstvno] + $r->netamt;
				$taxamt[$r->gstvno] = $taxamt[$r->gstvno] + $r->taxamt;
			}
			foreach($q as $r)
			{
				$myv1 = $r->gstvno;
				if($myv1!=$myv2)
				{
					$myv2 = $myv1;
				
					$status = "Pending";
					if($r->status==1)
					{
						$status = "Generated";
					}
				
			  ?>
			 <tr style='<?php if($r->status==0){ echo "background: #ffabab;"; } ?>'>
				<td><?php echo $r->gstvno ?></td>
				<td><?php echo date("d-M-Y", strtotime($r->vdt)) ?></td>
				<td><?php echo number_format(round($netamt[$r->gstvno] + $taxamt[$r->gstvno]),2) ?></td>
				<td><?php echo $status ?></td>
				<td>
					<a href="<?= base_url();?>chemist/view_invoice/<?php echo $r->gstvno ?>/<?= $usercode ?>/<?= $r->vdt ?>">
						View
					</a>
				</td>
				<td>
					<?php
					if($r->status==1)
					{ 
						if($invexport=="E")
						{
							?>
							<a href="<?= base_url();?>api_mobile_html/download_invoice_excel_chemist_report/<?php echo $invexport ?>/<?php echo $r->gstvno ?>/<?= $usercode ?>/<?= $r->vdt ?>">
								Excle
							</a>
							<?php 
						} 
					?>
					<?php /*<a href="<?= base_url();?>api3/send_email/<?php echo $r->gstvno ?>/<?= $usercode ?>/<?= $r->vdt ?>/email">
						Email / 
					</a>*/ ?>
					<?php 
						if($invexport=="Y")
						{
							?>
							<a href="<?= base_url();?>api_mobile_html/download_invoice_txt_file_chemist_report/<?php echo $invexport ?>/<?php echo $r->gstvno ?>/<?= $usercode ?>/<?= $r->vdt ?>">
								Txt File
							</a>
							<?php
						}
					}
					?>
				</td>
			  </tr>
			<?php } }?>
			</tbody>
		</table>
	</div>
</section>
</body>
</html>
<script src="
https://code.jquery.com/jquery-3.3.1.js" type="text/javascript"></script>
<script src="
https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" type="text/javascript"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<script>
$(document).ready(function() {
    $('#datatable').DataTable( {
        "order": [[ 1, "asc" ]]
    });
} );
</script>