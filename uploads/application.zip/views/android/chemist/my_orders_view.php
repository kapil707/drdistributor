<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<link href="http://drdistributor.com/chemist/assets/website/css/style2.css" rel="stylesheet" type="text/css"/>
</head>
<body style="padding-bottom:10px;">
<style>
.menubtn1
{
	display:none;
}
</style>
<div class="container" style="margin-top:-100px;">
	<div class="row">
		<div class="col-sm-1"></div>
		<div class="col-sm-10 col-12">
			<div class="row">
				<div class="col-sm-12 col-12 text-center div_date_time" style="margin-bottom:10px;">
				</div>
				<div class="col-sm-12 col-12 text-center div_acm" style="margin-bottom:10px;">					
				</div>
				<div class="col-sm-12 load_page_loading" style="margin-top:10px;">
				
				</div>
			</div>
			<span class="load_page"></span>
		</div>
		<div class="col-sm-1"></div>
	</div>
</div>
<script>
$(document).ready(function(){
	call_page("kapil");
});
function call_page_by_last_id()
{
	lastid1=$(".lastid1").val();
	call_page(lastid1)
}
function call_page(lastid1)
{
	order_id 		= "<?php echo $order_id; ?>";
	user_type 		= "<?php echo $user_type; ?>";
	user_altercode 		= "<?php echo $user_altercode; ?>";
	$(".load_more").hide();
	$(".load_page_loading").html('<h1><center><img src="http://drdistributor.com/chemist/images/new/loading.gif" width="100px"></center></h1><h1><center>Loading....</center></h1>');
	$.ajax({
	type       : "POST",
	data       : { lastid1:lastid1,order_id:order_id,user_type:user_type,user_altercode:user_altercode} ,
	url        : "<?php echo base_url(); ?>android/read_json/my_orders_view_api",
	cache	   : false,
	success    : function(data){
		if(data!="")
		{
			$(".load_page").html("");
		}
		$.each(data.items, function(i,item){	
			if (item){
				ptr	 	= parseFloat(item.ptr);
				ptr	 	= ptr.toFixed(2);
				total	= parseFloat(item.total);
				total	= total.toFixed(2);
				$(".div_date_time").html(item.date_time);
				if(item.user_type=="chemist")
				{
				}
				else{
					$(".div_acm").html(item.acm_name+"("+item.chemist_id+")");
				}
				$(".load_page_loading").html('');
				$(".load_page").append('<li class="search_page_hover '+item.css+'"><div class="row"><div class="col-sm-6 col-6 text_cut_or_dot text-capitalize search_page_title">'+item.med_name+'</div><div class="col-sm-6 col-6 text-right search_page_ptr">PTR: <i class="fa fa-inr" aria-hidden="true"></i>'+ptr+'/-</div><div class="col-sm-6 col-6 text_cut_or_dot search_page_stock">Quantity: '+item.qty+'</div><div class="col-sm-6 col-6 text-right search_page_ptr">Total: <i class="fa fa-inr" aria-hidden="true"></i>'+total+'/-</div></div></li>');
				//$(".lastid1").val(item.lastid1);
				if(item.sec_row!="")
				{
					//$(".load_more").show();
				}
			}
		});	
		}
	});
}
</script>