<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<link href="http://drdistributor.com/chemist/assets/website/css/style2.css" rel="stylesheet" type="text/css"/>
</head>
<body style="padding-bottom:10px;">
<style>
.menubtn1
{
	display:none;
}
</style>
<div class="container" style="margin-top:-100px;">
	<div class="row">
		<div class="col-sm-1"></div>
		<div class="col-sm-10 col-12">
			<span class="load_page"></span>
			<div class="row">			
				<div class="col-sm-12 load_page_loading" style="margin-top:10px;">
				
				</div>
				<div class="col-sm-12" style="margin-top:10px;">
					<button onclick="call_page_by_last_id()" class="load_more btn btn-success btn-block" style="background-color: #10847e;border-color: #10847e;">Load More</button>
				</div>
			</div>
		</div>
		<div class="col-sm-1"></div>
	</div>
</div>
<input type="hidden" class="lastid1">
<script>
$(document).ready(function(){
	call_page("kapil");
});
function call_page_by_last_id()
{
	lastid1=$(".lastid1").val();
	call_page(lastid1)
}
function call_page(lastid1)
{
	$(".load_more").hide();
	$(".load_page_loading").html('<h1><center><img src="http://drdistributor.com/chemist/images/new/loading.gif" width="100px"></center></h1><h1><center>Loading....</center></h1>');
	$.ajax({
	type       : "POST",
	data       :  {lastid1:lastid1,user_type:'<?= $user_type; ?>',user_altercode:'<?= $user_altercode; ?>'} ,
	url        : "<?php echo base_url(); ?>android/read_json/notification_api",
	cache	   : false,
	success    : function(data){
		if(data!="")
		{
			$(".load_page_loading").html("");
		}
		$.each(data.items, function(i,item){	
			if (item){
				title = atob(item.title);
				message = atob(item.message);
				message = message.substring(0,100);
				
				$(".load_page").append('<li class="search_page_hover '+item.css+'" style="margin-top:5px;"><a href="<?= base_url(); ?>android/api_mobile_html12/chemist_notification_view/'+item.url+'"><div class="row"><div class="col-sm-6 col-6 search_page_title mar_top10px">'+title+'</b></div><div class="col-sm-6 col-6 text-right search_page_stock mar_top10px">'+item.date_time+'</div><div class="col-sm-12 col-12 text_cut_or_dot text-left search_page_company_name">'+message+'</div></div></a></li>');
				$(".lastid1").val(item.lastid1);
				if(item.css!="")
				{
					$(".load_more").show();
				}
			}
		});
		}
	});
}
function callandroidfun(funtype,id,compname,image,division) {
	if(funtype=="0"){
		window.location.href = "<?= base_url(); ?>android/api_mobile_html12/chemist_notification_view/"+id;
	}
	if(funtype=="1"){
		android.fun_Get_single_medicine_info(id);
	}
	if(funtype=="2"){
		compname = atob(compname);
		android.fun_Featured_brand_medicine_division(id,compname,image,division);
	}
}
</script>