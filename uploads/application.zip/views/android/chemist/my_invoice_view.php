<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<link href="http://drdistributor.com/chemist/assets/website/css/style2.css" rel="stylesheet" type="text/css"/>
</head>
<body style="padding-bottom:10px;">
<style>
.menubtn1
{
	display:none;
}
</style>
<div class="container" style="margin-top:-100px;">
	<div class="row">
		<div class="col-sm-2"></div>
		<div class="col-sm-8 col-12">
			<div class="row">
				<div class="col-sm-3 col-6" style="margin-top:5px">
					<a href="<?php echo base_url(); ?>api_website_html/download_invoice_excel_chemist_report/<?= $gstvno ?>/<?= $acno?>/<?= $vdt?>">
						<button type="button" class="btn btn-warning btn-block">Download Excel</button>
					</a>
				</div>
				<div class="col-sm-3 col-6" style="margin-top:5px">
					<a href="<?php echo base_url(); ?>api_website_html/download_invoice_txt_file_chemist_report/<?= $gstvno ?>/<?= $acno?>/<?= $vdt?>">
						<button type="button" class="btn btn-info btn-block">Download Text</button>
					</a>
				</div>
				<div class="col-sm-3 col-6" style="margin-top:5px">
					<a href="<?php echo base_url(); ?>api_website_html/download_invoice_pdf_file_chemist_report/<?= $gstvno ?>/<?= $acno?>/<?= $vdt?>">
						<button type="button" class="btn btn-danger btn-block">Download Pdf</button>
					</a>
				</div>
				<div class="col-sm-3 col-6" style="margin-top:5px">
					<a href="javascript:send_email();" class="sendemailcss">
						<button type="button" class="btn btn-success btn-block">Send Email</button>
					</a>
				</div>
				<div class="col-sm-12 col-12 text-center" style="margin-top:10px;">
					<h4>Invoice Summary</h4>
				</div>
				<div class="col-sm-6 col-6 div_vdt" style="margin-top:10px;">
					
				</div>		
				<div class="col-sm-6 col-6 text-right div_total_price" style="margin-top:10px;">
					
				</div>
				<div class="col-sm-6 col-6 div_total_qty">
					
				</div>
				<div class="col-sm-6 col-6 text-right div_total_gst">
					
				</div>
				
				<div class="col-sm-6 col-6 div_status">
					
				</div>
				<div class="col-sm-6 col-6 text-right div_full_total">
				</div>
				<div class="col-sm-12 col-12 load_page" style="margin-bottom:20px;">
					
				</div>
				<div class="col-sm-12 col-12 text-center div_item_delete" style="display:none">
					<h4>Free Quantity, Quantity Changed and Items Deleted</h4>
				</div>
				<div class="col-sm-12 col-12 load_page1" style="margin-bottom:20px;">
					
				</div>
				<div class="col-sm-12 load_page_loading" style="margin-top:10px;">
				
				</div>
				<div class="col-sm-12" style="margin-top:10px;">
					<button onclick="call_page_by_last_id()" class="load_more btn btn-success btn-block">Load More</button>
				</div>
			</div>
		</div>
		<div class="col-sm-2"></div>
	</div>     
</div>
<script>
$(document).ready(function(){
	call_page("kapil");
});
function call_page_by_last_id()
{
	lastid1=$(".lastid1").val();
	call_page(lastid1)
}
function call_page(lastid1)
{
	$(".load_more").hide();
	$(".load_page_loading").html('<h1><center><img src="http://drdistributor.com/chemist/images/new/loading.gif" width="100px"></center></h1><h1><center>Loading....</center></h1>');
	gstvno	= "<?php echo $gstvno; ?>";
	acno	= "<?php echo $acno; ?>";
	vdt		= "<?php echo $vdt; ?>";
	$.ajax({
	type       : "POST",
	data       :  {lastid1:lastid1,gstvno:gstvno,acno:acno,vdt:vdt} ,
	url        : "<?php echo base_url(); ?>android/read_json/my_invoice_view_api",
	cache	   : false,
	success    : function(data){
		if(data!="")
		{
			$(".load_page_loading").html("");
		}
		$.each(data.items, function(i,item){	
			if (item){
				expiry	 =item.expiry;
				netamt	 = parseFloat(item.netamt);
				netamt	 = netamt.toFixed(2);
				taxamt	 = parseFloat(item.taxamt);
				taxamt	 = taxamt.toFixed(2);
				total	 = parseFloat(item.total);
				total	 = total.toFixed(2);
				if(item.inv_type=="insert")
				{
					$(".div_vdt").html(''+item.vdt);
					$(".div_status").html(''+item.status);
					$(".div_total_qty").html('Items: '+item.total_qty);
					$(".div_total_price").html('Total: '+item.total_price);
					$(".div_total_gst").html('GST:'+item.total_gst);
					$(".div_full_total").html('Grand Total: '+item.full_total);
					$(".load_page").append('<li class="search_page_hover '+item.css+'"><div class="row"><div class="col-sm-6 col-6 text_cut_or_dot text-capitalize search_page_title">'+item.item_name+'</div><div class="col-sm-6 col-6 text-right text_cut_or_dot search_page_batch_no">Batch No: '+item.batch+'</div><div class="col-sm-6 col-6 search_page_exp">Expiry: '+expiry+'</div><div class="col-sm-6 col-6 text-right search_page_stock ">Quantity: '+item.qty+'</div><div class="col-sm-6 col-6 search_page_stock">Free Quantity: '+item.fqty+'</div><div class="col-sm-6 col-6 text-right search_page_mrp">PTR: <i class="fa fa-inr" aria-hidden="true"></i>'+netamt+'/-</div><div class="col-sm-6 col-6 search_page_mrp">GST: <i class="fa fa-inr" aria-hidden="true"></i>'+taxamt+'/-</div><div class="col-sm-6 col-6 text-right search_page_mrp">Total: <i class="fa fa-inr" aria-hidden="true"></i>'+total+'/-</div></div></li>');
				}
				if(item.inv_type=="delete")
				{
					$(".div_item_delete").show();
					$(".load_page1").append('<li class="search_page_hover '+item.css+'"><div class="row"><div class="col-sm-6 col-6">'+item.item_name+'</div><div class="col-sm-6 col-6 text-right">Descp: '+item.delete_descp+'</div><div class="col-sm-6 col-6">Total Qty: '+item.delete_amt+'</div><div class="col-sm-6 col-6 text-right">Change Qty: '+item.delete_namt+'</div><div class="col-sm-12 col-12">Remarks: '+item.delete_remarks+'</div></div></li>');
				}
				//$(".lastid1").val(item.lastid1);
				if(item.sec_row!="")
				{
					//$(".load_more").show();
				}
			}
		});	
		}
	});
}
</script>
<script>
function send_email()
{
	$(".sendemailcss").hide();
	select_user = "";
	$.ajax({
		url: "<?php echo base_url(); ?>android/read_json/send_email_invoice_chemist_report",
		type:"POST",
		dataType: 'html',
		data: {gstvno:'<?= $gstvno ?>',acno:'<?= $acno ?>',vdt:'<?= $vdt ?>'},
		success: function(data){
			alert("Email Sent")
			$(".sendemailcss").show();
		}
	});
}
</script>