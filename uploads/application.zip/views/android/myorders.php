<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<section class="pt-10">
	<div class="container">
        <table class="table">
			<thead>
				<tr>
					<th>Sr No.</th>
					<th>Order ID</th>
					<?php	
					if($user_type=="sales"){?>
					<th>Chemist </th>
					<?php } ?>
					<th>Price</th>
					<th>Detail</th>
				</tr>
			</thead>
			<tbody>
			<?php 
			$html = "";
			error_reporting(0);
			$i = 1;
			foreach($list as $key=>$val)
			{
				$myval = 0;
				$order_id = $val['order_id'];
				$total = $this->db->query("SELECT ptr,qty FROM `ci_temp_order` where order_id='$order_id'")->result();
				foreach($total as $mytotal)
				{
					$myval = $myval + ($mytotal->ptr * $mytotal->qty);
				}
				
				$customerDetail = $this->auth_model->Get_userbyId($val['customer_code']);
				if($val['sales_user_id'] != "")
					$SalesDetail = $this->auth_model->Get_userId($val['sales_user_id']);
				else
					$SalesDetail[0]['customer_name'] = "N/A";
				$html .= "<tr>";
				$html .="<td>$i</td>";
				$html .="<td>$val[order_id]</td>";
				if($user_type=="sales"){	
					$html .="<td>".$customerDetail[0]['name']." - ".$customerDetail[0]['altercode']."</td>";
				}
				$html .="<td>".$myval."</td>";
				$html .="<td><a href=order_detail/$val[order_id]>Detail</a></td>";
				$html .= "</tr>";
				$i++;
			}?>
			<?php echo $html;?>
			</tbody>
		</table>
	</div>
</section>
</body>
</html>