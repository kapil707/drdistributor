<div class="row">
    <div class="col-xs-12" style="margin-bottom:5px;">		<a href="add">
            <button type="submit" class="btn btn-info">
                Add
            </button>
        </a>
   	</div>
    <div class="col-xs-12">
         <div class="table-responsive">
			<table id="data-table-basic" class="table table-striped">
                <thead>
                    <tr>
                    	<th>
                        	Sno.
                        </th>
						<th>
							Function Type
						</th>
						<th>
							Chemist
						</th>
						<th>
							Title
						</th>
                    </tr>
                </thead>				<tbody>
                <?php
				$i=1;
                foreach ($result as $row)
                {
					?>
                    <tr id="row_<?= $row->id; ?>">
                    	<td>
                        	<?= $i++; ?>
                        </td>
						<td>
                        	<?if($row->funtype=="0"){ ?>Not Need<?php } ?>
							<?if($row->funtype=="1"){ ?>Item <?= $row->itemid; ?><?php } ?>
							<?if($row->funtype=="2"){ ?>Company <?= $row->compid; ?><?php } ?>
							<?if($row->funtype=="3"){ ?>Map Page<?php } ?>
							<?if($row->funtype=="4"){ ?>Orders Page<?php } ?>
							<?if($row->funtype=="5"){ ?>Invoice Page<?php } ?>
                        </td>
						<td>
							<?= ($row->user_type); ?> (<?= ($row->chemist_id); ?>)
                        </td>
						<td>
							<?= base64_decode($row->title); ?>
                        </td>
                    </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>