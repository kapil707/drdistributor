<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Excel_Model extends CI_Model
{	public function chemist_invoice_report_txt($gstvno,$acno,$vdt,$mytype)
	{
		$txt = "";
		$qr = $this->db->query("select name from tbl_acm where code='$acno' ")->row();
		$qr1 = $this->db->query("select comp_name from tbl_sales_main where gstvno='$gstvno' and vdt='$vdt'")->row();		

		$q = $this->db->query("select * from tbl_sales where gstvno='$gstvno' and vdt='$vdt' and mdatatype='insert'")->result();  
		foreach($q as $row)
		{
			$comp_name 	= $qr1->comp_name;
			$item_code 	= $row->item_code;
			$item_name 	= $row->item_name;
			$i_code 	= $row->itemc;
			$packing 	= $row->packing;			

			$vt 		= date("d-M-y", strtotime($row->vdt));			

			$txt.= " | $qr->name | $row->gstvno | $vt | $comp_name | $i_code | $item_code | $item_name | $packing | $row->batch | $row->expiry | ".round($row->qty,2)." | ".round($row->fqty,2)." | ".round($row->halfp,2)." | ".round($row->ftrate,2)." | ".round($row->ftrate,2)." | ".round($row->mrp,2)." | ".round($row->dis,2)." | $row->excise | 0 | ".round($row->adnlvat,2)." | ".$row->netamt." | $row->localcent | $row->scm1 | $row->scm2 | $row->scmper | $row->escode | $row->hsncode | ".round($row->cgst)." | ".round($row->sgst)." | ".round($row->igst)." \n";
		}
		
		$name = substr($qr->name,0,19);
		if($mytype=="cronjob_download")
		{
			echo $file_name = "email_files/".$gstvno.".txt";		
			file_put_contents($file_name, $txt.PHP_EOL , FILE_APPEND | LOCK_EX);
			return $file_name;
		}
		else
		{
			$file_name_1= $gstvno."_D.R.DISTRIBUTORS PVT_".$name.".txt";
			$handle = fopen($file_name_1, "w");
			fwrite($handle, $txt);
			fclose($handle);

			header('Content-Type: application/octet-stream');
			header('Content-Disposition: attachment; filename='.basename($file_name_1));
			header('Expires: 0');
			header('Cache-Control: must-revalidate');
			header('Pragma: public');
			header('Content-Length: ' . filesize($file_name_1));
			readfile('file.txt');
			exit;
		}
	}
	
	public function chemist_invoice_report_excel($gstvno,$acno,$vdt,$mytype)
	{
		$this->load->library('excel');
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		error_reporting(0);
		ob_clean();		

		date_default_timezone_set('Asia/Calcutta');
		$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A1', 'SUPPLIER')
		->setCellValue('B1', 'BILL NO.')
		->setCellValue('C1', 'DATE')
		->setCellValue('D1', 'COMPANY')
		->setCellValue('E1', 'CODE')
		->setCellValue('F1', 'BARCODE')
		->setCellValue('G1', 'ITEM NAME')
		->setCellValue('H1', 'PACK')
		->setCellValue('I1', 'BATCH')
		->setCellValue('J1', 'EXPIRY')
		->setCellValue('K1', 'QTY')
		->setCellValue('L1', 'F.QTY')
		->setCellValue('M1', 'HALFP')
		->setCellValue('N1', 'FTRATE')
		->setCellValue('O1', 'SRATE')
		->setCellValue('P1', 'MRP')
		->setCellValue('Q1', 'DIS')
		->setCellValue('R1', 'EXCISE')
		->setCellValue('S1', 'VAT')
		->setCellValue('T1', 'ADNLVAT')
		->setCellValue('U1', 'AMOUNT')
		->setCellValue('V1', 'LOCALCENT')
		->setCellValue('W1', 'SCM1')
		->setCellValue('X1', 'SCM2')
		->setCellValue('Y1', 'SCMPER')
		->setCellValue('Z1', 'HSNCODE')
		->setCellValue('AA1', 'CGST')
		->setCellValue('AB1', 'SGST')
		->setCellValue('AC1', 'IGST');		

		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(50);
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(11);
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(50);
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(11);
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(21);
		$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(50);
		$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(13);
		$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(20);
		$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(8);
		$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(9);
		$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(9);
		$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(9);
		$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(11);
		$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(11);
		$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(11);
		$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(6);
		$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(7);
		$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(6);
		$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(11);
		$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(13);
		$objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(13);
		$objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(8);
		$objPHPExcel->getActiveSheet()->getColumnDimension('X')->setWidth(8);
		$objPHPExcel->getActiveSheet()->getColumnDimension('Y')->setWidth(9);
		$objPHPExcel->getActiveSheet()->getColumnDimension('Z')->setWidth(13);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AA')->setWidth(9);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AB')->setWidth(9);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AC')->setWidth(9);	

		$objPHPExcel->getActiveSheet()
        ->getStyle('A1:AC1')
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB('ccffff');		

		$BStyle = array(
		  'borders' => array(
			'allborders' => array(
			  'style' => PHPExcel_Style_Border::BORDER_THIN
			)
		  )
		);
		$objPHPExcel->getActiveSheet()->getStyle('A1:AC1')->applyFromArray($BStyle);		

		$objPHPExcel->getActiveSheet()->getStyle('A1:AC1')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'color' => array('rgb' => '800000'),'name'  => 'Arial')));		

		$qr = $this->db->query("select name,altercode from tbl_acm where code='$acno' ")->row();
		$qr1 = $this->db->query("select comp_name from tbl_sales_main where gstvno='$gstvno' and vdt='$vdt'")->row();
		$rowCount = 2;
		$q = $this->db->query("select * from tbl_sales where gstvno='$gstvno' and vdt='$vdt' and mdatatype='insert' order by id asc")->result(); 
		foreach($q as $row)
		{			
			$qty 	= round("$row->qty");
			$fqty 	= round("$row->fqty");
			
			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':AC'.$rowCount)->applyFromArray($BStyle);			

			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':AC'.$rowCount)->applyFromArray(array('font' => array('size' => 10,'bold' => FALSE,'name'  => 'Arial')));			

			$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,$qr->name);
			$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount,$row->gstvno);

			$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount,date("d-m-Y", strtotime($row->vdt)));
			$objPHPExcel->getActiveSheet()->getStyle('C'.$rowCount)->getNumberFormat()->setFormatCode('dd-mm-yyyy');			

			$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$qr1->comp_name);
			$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$row->itemc);
			$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$row->item_code);
			$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount,$row->item_name);
			$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount,$row->packing);
			$objPHPExcel->getActiveSheet()->SetCellValue('I'.$rowCount,$row->batch);
			$objPHPExcel->getActiveSheet()->SetCellValue('J'.$rowCount,$row->expiry);
			$objPHPExcel->getActiveSheet()->SetCellValue('K'.$rowCount,$qty);
			$objPHPExcel->getActiveSheet()->SetCellValue('L'.$rowCount,$fqty);
			$objPHPExcel->getActiveSheet()->SetCellValue('M'.$rowCount,$row->halfp);
			$objPHPExcel->getActiveSheet()->SetCellValue('N'.$rowCount,$row->ftrate);
			$objPHPExcel->getActiveSheet()->SetCellValue('O'.$rowCount,$row->ftrate);
			$objPHPExcel->getActiveSheet()->SetCellValue('P'.$rowCount,$row->mrp);

			$objPHPExcel->getActiveSheet()->SetCellValue('Q'.$rowCount,$row->dis);
			$objPHPExcel->getActiveSheet()->SetCellValue('R'.$rowCount,$row->excise);
			$objPHPExcel->getActiveSheet()->SetCellValue('S'.$rowCount,'0');
			$objPHPExcel->getActiveSheet()->SetCellValue('T'.$rowCount,$row->adnlvat);

			$objPHPExcel->getActiveSheet()->SetCellValue('U'.$rowCount,$row->netamt);
			$objPHPExcel->getActiveSheet()->SetCellValue('V'.$rowCount,$row->localcent);
			$objPHPExcel->getActiveSheet()->SetCellValue('W'.$rowCount,$row->scm1);
			$objPHPExcel->getActiveSheet()->SetCellValue('X'.$rowCount,$row->scm2);
			$objPHPExcel->getActiveSheet()->SetCellValue('Y'.$rowCount,$row->scmper);
			$objPHPExcel->getActiveSheet()->SetCellValue('Z'.$rowCount,$row->hsncode);
			$objPHPExcel->getActiveSheet()->SetCellValue('AA'.$rowCount,$row->cgst);
			$objPHPExcel->getActiveSheet()->SetCellValue('AB'.$rowCount,$row->sgst);
			$objPHPExcel->getActiveSheet()->SetCellValue('AC'.$rowCount,$row->igst);			

			$objPHPExcel->getActiveSheet()->getStyle('E'.$rowCount)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
			$objPHPExcel->getActiveSheet()->getStyle('F'.$rowCount)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
			$objPHPExcel->getActiveSheet()->getStyle('I'.$rowCount)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
			$objPHPExcel->getActiveSheet()->getStyle('Z'.$rowCount)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
			//$objPHPExcel->getActiveSheet()->getStyle('K'.$rowCount)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
			//$objPHPExcel->getActiveSheet()->getStyle('L'.$rowCount)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);			

			$rowCount++;
		}
		
		$file_name = $gstvno.".xls";
		if($mytype=="")
		{
			$name = substr($qr->name,0,19);
			$file_name = $gstvno."_D.R.DISTRIBUTORS PVT_".$name.".xls";
			//$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
			$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
			/*$objWriter->save('uploads_sales/kapilkifile.xls');*/		

			header('Content-type: application/vnd.ms-excel');
			header('Content-Disposition: attachment; filename='.$file_name);
			header('Cache-Control: max-age=0');
			ob_start();
			$objWriter->save('php://output');
			$data = ob_get_contents();
		}
		if($mytype=="invoice_page_3party")
		{
			$file_name = $qr->altercode."_".$gstvno.".xls";
			//$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
			$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
			/*$objWriter->save('uploads_sales/kapilkifile.xls');*/		

			header('Content-type: application/vnd.ms-excel');
			header('Content-Disposition: attachment; filename='.$file_name);
			header('Cache-Control: max-age=0');
			ob_start();
			$objWriter->save('php://output');
			$data = ob_get_contents();
		}
		if($mytype=="cronjob_download")
		{
			$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
			$file_name = $gstvno."_D.R.DISTRIBUTORS PVT_".$name.".xls";
			$file_name = "email_files/".$file_name;
			$objWriter->save($file_name);
			return $file_name;
		}
	}
	
	public function import_orders_delete_items($date,$time)
	{
		$this->load->library('excel');
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		error_reporting(0);
		ob_clean();		

		date_default_timezone_set('Asia/Calcutta');
		$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A1', 'Sno')
		->setCellValue('B1', 'Item Name')
		->setCellValue('C1', 'Item Mrp.')
		->setCellValue('D1', 'Item Quantity');		

		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(10);	

		$i = 0;
		$rowCount = 2;
		$q = $this->db->query("select * from tbl_delete_import where date='$date' and time='$time'")->result(); 
		foreach($q as $row)
		{
			$i++;
			$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,$i);
			$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount,$row->your_item_name);
			$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount,$row->your_item_mrp);
			$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$row->item_qty);
			$rowCount++;
		}
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
		$file_name = "email_files/import_orders_delete_items_".time().".xls";
		$objWriter->save($file_name);
		return $file_name;
	}
	
	public function save_order($temp_rec,$order_id,$chemist_excle)
	{
		$this->load->library('excel');
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		error_reporting(0);
		ob_clean();		

		date_default_timezone_set('Asia/Calcutta');
		$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A1','Code')
		->setCellValue('B1','Name')
		->setCellValue('C1','Quantity')
		->setCellValue('D1','PTR')
		->setCellValue('E1','Total')
		->setCellValue('F1','Chemist');		

		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(9);
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(9);
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(20);	
		
		$objPHPExcel->getActiveSheet()->getStyle('A1:F1')->applyFromArray(array('font' => array('size' => 12,'bold' => TRUE,'color' => array('rgb' => '000000'),'name'  => 'Arial')));

		$i = 0;
		$rowCount = 2;
		$query = $this->db->query("select * from tbl_order where temp_rec='$temp_rec' and order_id='$order_id'")->result(); 
		foreach($query as $row)
		{
			$i++;
			$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,$row->item_code);
			$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount,$row->item_name);
			$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount,$row->quantity);
			$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$row->sale_rate);
			$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$row->sale_rate * $row->quantity);
			$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$chemist_excle);
			
			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':F'.$rowCount)->applyFromArray(array('font' => array('size' => 8,'bold' => false,'color' => array('rgb' => '000000'),'name'  => 'Arial')));
			
			
			$rowCount++;
		}
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
		$file_name = "email_files/save_order_".time().".xls";
		$objWriter->save($file_name);

		return $file_name;
	}
	
	/******************07-11-19********************************/	
	public function sales_deleted_daily_report($vdt)
	{
		$this->load->library('excel');
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		error_reporting(0);
		ob_clean();		

		date_default_timezone_set('Asia/Calcutta');
		$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A3', 'Sno')
		->setCellValue('B3', 'Gstvno')
		->setCellValue('C3', 'Date')
		->setCellValue('D3', 'Chemist')
		->setCellValue('E3', 'Item Name')
		->setCellValue('F3', 'Sale Rate')
		->setCellValue('G3', 'Net Amt')
		->setCellValue('H3', 'Final Amt')
		->setCellValue('I3', 'Descp');
		

		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(25);
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
		$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(15);
		$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);	
		$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(25);	

		$BStyle = array(
		  'borders' => array(
			'allborders' => array(
			  'style' => PHPExcel_Style_Border::BORDER_THIN
			)
		  )
		);		
		$objPHPExcel->getActiveSheet()->getStyle('A3:I3')->applyFromArray($BStyle);
		
		$objPHPExcel->getActiveSheet()->getStyle('A3:I3')->applyFromArray(array('font' => array('size' => 12,'bold' => TRUE,'color' => array('rgb' => '800000'),'name'  => 'Arial')));
		$sheet = $objPHPExcel->getActiveSheet();
		
		$vt 		= date("d-M-y", strtotime($vdt));
		$objPHPExcel->getActiveSheet()->SetCellValue('A1','Sales Deleted Daily Report '.$vt);
		$sheet->mergeCells('A1:H1');
		$objPHPExcel->getActiveSheet()->getStyle('A1:H1')->applyFromArray(array('font' => array('size' => 13,'bold' => TRUE,'color' => array('rgb' => '000000'),'name'  => 'Arial')));
		$sheet->mergeCells('A1:H1');
		$sheet->getStyle('A1')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		
		$i = 0;
		$rowCount = 4;
		$result = $this->db->query("select * from tbl_sales_deleted where(delete_descp='ITEM DELETE' or delete_descp='QTY.CHANGE') and vdt='$vdt' and email_status='0' order by id desc")->result();
		foreach ($result as $row)
		{			
			$i++;
			$vt 		= date("d-M-y", strtotime($row->vdt));
			$row1 = $this->db->query("select acno from tbl_sales_main where gstvno='$row->gstvno' and vdt='$row->vdt'")->row();
			$row2 = $this->db->query("select name,altercode from tbl_acm where code='$row1->acno'")->row();
			$chemist = $row2->name." (".$row2->altercode.")";
			
			$row2 = $this->db->query("select sale_rate from tbl_medicine where item_code='$row->item_code'")->row();
			
			$sale_rate  = $row2->sale_rate;
			$total_sale_rate = $total_sale_rate + $sale_rate;
			
			$net_amt = $row->delete_amt - $row->delete_namt;
			$total_net_amt = $total_net_amt + $net_amt;
			
			$final_amt = $net_amt*$sale_rate;
			$total_final_amt = $total_final_amt + $final_amt;			
			
			$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,$i);
			$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount,$row->gstvno);
			$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount,$vt);
			$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$chemist);
			$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$row->item_name);
			$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$sale_rate);
			$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount,$net_amt);
			$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount,$final_amt);
			$objPHPExcel->getActiveSheet()->SetCellValue('I'.$rowCount,$row->delete_descp);
			
			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':I'.$rowCount)->applyFromArray($BStyle);
			
			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':I'.$rowCount)->applyFromArray(array('font' => array('size' => 10,'bold' => false,'color' => array('rgb' => '000000'),'name'  => 'Arial')));
			$rowCount++;
		}
		$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':I'.$rowCount)->applyFromArray($BStyle);
		$rowCount++;
		$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':I'.$rowCount)->applyFromArray($BStyle);
		$rowCount++;
		
		$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount,"Total");
		$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$total_sale_rate);
		$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount,$total_net_amt);
		$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount,$total_final_amt);
		
		$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':I'.$rowCount)->applyFromArray($BStyle);
		$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':I'.$rowCount)->applyFromArray(array('font' => array('size' => 12,'bold' => TRUE,'color' => array('rgb' => '800000'),'name'  => 'Arial')));
		
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
		$file_name = "email_files/sales_deleted_daily_report_".time().".xls";
		$objWriter->save($file_name);
		
		$x[0] = $file_name;
		$x[1] = $total_sale_rate;
		$x[2] = $total_net_amt;
		$x[3] = $total_final_amt;
		return $x;
	}
	
	/******************09-11-19********************************/	
	public function sales_deleted_daily_report_chemist_wise($vdt)
	{
		$this->load->library('excel');
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		error_reporting(0);
		ob_clean();		

		date_default_timezone_set('Asia/Calcutta');
		$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A3', '')
		->setCellValue('B3', 'Gstvno')
		->setCellValue('C3', 'Date')
		->setCellValue('D3', 'Item Name')
		->setCellValue('E3', 'Sale Rate')
		->setCellValue('F3', 'Net Amt')
		->setCellValue('G3', 'Final Amt')
		->setCellValue('H3', 'Descp');
		

		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(25);
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
		$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(15);	
		$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(25);	

		$BStyle = array(
		  'borders' => array(
			'allborders' => array(
			  'style' => PHPExcel_Style_Border::BORDER_THIN
			)
		  )
		);		
		$objPHPExcel->getActiveSheet()->getStyle('A3:H3')->applyFromArray($BStyle);
		
		$objPHPExcel->getActiveSheet()->getStyle('A3:H3')->applyFromArray(array('font' => array('size' => 12,'bold' => TRUE,'color' => array('rgb' => '800000'),'name'  => 'Arial')));
		$sheet = $objPHPExcel->getActiveSheet();
		
		$vt 		= date("d-M-y", strtotime($vdt));
		$objPHPExcel->getActiveSheet()->SetCellValue('A1','Sales Deleted Daily Report Chemist Wise '.$vt);
		$sheet->mergeCells('A1:H1');
		$objPHPExcel->getActiveSheet()->getStyle('A1:H1')->applyFromArray(array('font' => array('size' => 13,'bold' => TRUE,'color' => array('rgb' => '000000'),'name'  => 'Arial')));
		$sheet->mergeCells('A1:H1');
		$sheet->getStyle('A1')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		
		$rowCount = 4;
		$result3 = $this->db->query("select gstvno,acno from tbl_sales_main where vdt='$vdt' order by acno asc")->result();
		foreach ($result3 as $row3)
		{
			$row4 = $this->db->query("select id from tbl_sales_deleted where(delete_descp='ITEM DELETE' or delete_descp='QTY.CHANGE') and vdt='$vdt' and gstvno='$row3->gstvno' and email_status='0' order by id desc")->row();
			if($row4->id!="")
			{
				$row2 = $this->db->query("select name,altercode from tbl_acm where code='$row3->acno'")->row();
				$chemist = $row2->name." (".$row2->altercode.")";
				$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,$chemist);
				$sheet->mergeCells('A'.$rowCount.':H'.$rowCount);
				$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray(array('font' => array('size' => 11,'bold' => TRUE,'color' => array('rgb' => '000000'),'name'  => 'Arial')));
				$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray($BStyle);
				$rowCount++;
				
				$small_sale_rate = $small_net_amt = $small_final_amt = 0;
				$result = $this->db->query("select * from tbl_sales_deleted where(delete_descp='ITEM DELETE' or delete_descp='QTY.CHANGE') and vdt='$vdt' and gstvno='$row3->gstvno' and email_status='0' order by id desc")->result();
				foreach ($result as $row)
				{			
					$vt 		= date("d-M-y", strtotime($row->vdt));
					$row1 = $this->db->query("select acno from tbl_sales_main where gstvno='$row->gstvno' and vdt='$row->vdt'")->row();
					
					$row2 = $this->db->query("select sale_rate from tbl_medicine where item_code='$row->item_code'")->row();
					
					$sale_rate  = $row2->sale_rate;
					$total_sale_rate = $total_sale_rate + $sale_rate;
					$small_sale_rate = $small_sale_rate + $sale_rate;
					
					$net_amt = $row->delete_amt - $row->delete_namt;
					$total_net_amt = $total_net_amt + $net_amt;
					$small_net_amt = $small_net_amt + $net_amt;
					
					$final_amt = $net_amt*$sale_rate;
					$total_final_amt = $total_final_amt + $final_amt;			
					$small_final_amt = $small_final_amt + $final_amt;
					
					$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount,$row->gstvno);
					$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount,$vt);
					$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$row->item_name);
					$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$sale_rate);
					$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$net_amt);
					$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount,$final_amt);
					$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount,$row->delete_descp);
					
					$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray($BStyle);
					
					$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray(array('font' => array('size' => 10,'bold' => false,'color' => array('rgb' => '000000'),'name'  => 'Arial')));
					$rowCount++;
				}
				$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount,"Total");
				$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$small_sale_rate);
				$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$small_net_amt);
				$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount,$small_final_amt);
				$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'color' => array('rgb' => '000000'),'name'  => 'Arial')));
				
				$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray($BStyle);
				$rowCount++;
				$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray($BStyle);
				$rowCount++;
			}
		}
		
		$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount,"Full Total");
		$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$total_sale_rate);
		$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$total_net_amt);
		$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount,$total_final_amt);
		
		$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray($BStyle);
		$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray(array('font' => array('size' => 12,'bold' => TRUE,'color' => array('rgb' => '800000'),'name'  => 'Arial')));
		
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
		$file_name = "email_files/sales_deleted_daily_report_chemist_wise_".time().".xls";
		$objWriter->save($file_name);

		return $file_name;
	}
	
	/******************18-11-19********************************/	
	public function insert_pending_order($company,$date_range)
	{
		$this->load->library('excel');
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		error_reporting(0);
		ob_clean();		

		date_default_timezone_set('Asia/Calcutta');
		$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A7', 'Company')
		->setCellValue('B7', 'Item Code')
		->setCellValue('C7', 'Item Name')
		->setCellValue('D7', 'Pack')
		->setCellValue('E7', 'Qty.')
		->setCellValue('F7', 'F.Qty.')
		->setCellValue('G7', 'Item Division');
		

		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(12);
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(8);
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(8);
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(8);
		$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(11);

		$BStyle = array(
		  'borders' => array(
			'allborders' => array(
			  'style' => PHPExcel_Style_Border::BORDER_THIN
			)
		  )
		);		
		$objPHPExcel->getActiveSheet()->getStyle('A7:G7')->applyFromArray($BStyle);
		
		$objPHPExcel->getActiveSheet()->getStyle('A7:G7')->applyFromArray(array('font' => array('size' => 8,'bold' => TRUE,'color' => array('rgb' => '000000'),'name'  => 'Arial')));
		$sheet = $objPHPExcel->getActiveSheet();
		
		$objPHPExcel->getActiveSheet()
        ->getStyle('A7:G7')
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB('9f9fff');		
		
		$objPHPExcel->getActiveSheet()->SetCellValue('A1','D.R.DISTRIBUTORS PVT.LTD.');
		$sheet->mergeCells('A1:G1');
		$objPHPExcel->getActiveSheet()->getStyle('A1:G1')->applyFromArray(array('font' => array('size' => 18,'bold' => TRUE,'color' => array('rgb' => '800000'),'name'  => 'Arial')));
		$sheet->getStyle('A1')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		
		$objPHPExcel->getActiveSheet()->SetCellValue('A2','200 B  GAUTAM NAGAR NEW DELHI 110049');
		$sheet->mergeCells('A2:G2');
		$objPHPExcel->getActiveSheet()->getStyle('A2:G2')->applyFromArray(array('font' => array('size' => 9,'bold' => TRUE,'color' => array('rgb' => '978000'),'name'  => 'Arial')));
		$sheet->getStyle('A2')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		
		$objPHPExcel->getActiveSheet()->SetCellValue('A3','ORDER FORM');
		$sheet->mergeCells('A3:G3');
		$objPHPExcel->getActiveSheet()->getStyle('A3:G3')->applyFromArray(array('font' => array('size' => 12,'bold' => TRUE,'color' => array('rgb' => '800000'),'name'  => 'Arial')));
		$sheet->getStyle('A3')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		$objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setUnderline(true);
		
		$objPHPExcel->getActiveSheet()->SetCellValue('A4','ORDER');
		$sheet->mergeCells('A4:G4');
		$objPHPExcel->getActiveSheet()->getStyle('A4:G4')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'color' => array('rgb' => '6600ff'),'name'  => 'Arial')));
		
		$objPHPExcel->getActiveSheet()->SetCellValue('A5',$date_range);
		$sheet->mergeCells('A5:G5');
		$objPHPExcel->getActiveSheet()->getStyle('A5:G5')->applyFromArray(array('font' => array('size' => 8,'bold' => TRUE,'color' => array('rgb' => '000000'),'name'  => 'Arial')));
		
		$objPHPExcel->getActiveSheet()->SetCellValue('A6','Remarks : 0');
		$sheet->mergeCells('A6:G6');
		$objPHPExcel->getActiveSheet()->getStyle('A6:G6')->applyFromArray(array('font' => array('size' => 9,'bold' => TRUE,'color' => array('rgb' => '6600ff'),'name'  => 'Arial')));
		
		$rowCount = 8;
		$result = $this->db->query("select * from tbl_pending_order where company='$company'")->result();
		foreach ($result as $row)
		{
			$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,$row->company);
			$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount,$row->item_code);
			$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount,$row->item_name);
			$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$row->pack);
			$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$row->qty);
			$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$row->f_qty);
			$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount,$row->division);
			
			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':G'.$rowCount)->applyFromArray($BStyle);
			
			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':G'.$rowCount)->applyFromArray(array('font' => array('size' => 8,'bold' => false,'color' => array('rgb' => '000000'),'name'  => 'Arial')));
			$rowCount++;
		}
		
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
		$file_name = "email_files/pending_order_report_".time().".xls";
		$objWriter->save($file_name);

		return $file_name;
	}
	
	/******************07-12-19********************************/	
	public function insert_pending_order_fail_report($date_range)
	{
		$this->load->library('excel');
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		error_reporting(0);
		ob_clean();		

		date_default_timezone_set('Asia/Calcutta');
		$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A7', 'Company')
		->setCellValue('B7', 'Item Code')
		->setCellValue('C7', 'Item Name')
		->setCellValue('D7', 'Pack')
		->setCellValue('E7', 'Qty.')
		->setCellValue('F7', 'F.Qty.')
		->setCellValue('G7', 'Item Division');
		

		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(12);
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(8);
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(8);
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(8);
		$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(11);

		$BStyle = array(
		  'borders' => array(
			'allborders' => array(
			  'style' => PHPExcel_Style_Border::BORDER_THIN
			)
		  )
		);		
		$objPHPExcel->getActiveSheet()->getStyle('A7:G7')->applyFromArray($BStyle);
		
		$objPHPExcel->getActiveSheet()->getStyle('A7:G7')->applyFromArray(array('font' => array('size' => 8,'bold' => TRUE,'color' => array('rgb' => '000000'),'name'  => 'Arial')));
		$sheet = $objPHPExcel->getActiveSheet();
		
		$objPHPExcel->getActiveSheet()
        ->getStyle('A7:G7')
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB('9f9fff');		
		
		$objPHPExcel->getActiveSheet()->SetCellValue('A1','D.R.DISTRIBUTORS PVT.LTD.');
		$sheet->mergeCells('A1:G1');
		$objPHPExcel->getActiveSheet()->getStyle('A1:G1')->applyFromArray(array('font' => array('size' => 18,'bold' => TRUE,'color' => array('rgb' => '800000'),'name'  => 'Arial')));
		$sheet->getStyle('A1')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		
		$objPHPExcel->getActiveSheet()->SetCellValue('A2','200 B  GAUTAM NAGAR NEW DELHI 110049');
		$sheet->mergeCells('A2:G2');
		$objPHPExcel->getActiveSheet()->getStyle('A2:G2')->applyFromArray(array('font' => array('size' => 9,'bold' => TRUE,'color' => array('rgb' => '978000'),'name'  => 'Arial')));
		$sheet->getStyle('A2')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		
		$objPHPExcel->getActiveSheet()->SetCellValue('A3','ORDER FORM');
		$sheet->mergeCells('A3:G3');
		$objPHPExcel->getActiveSheet()->getStyle('A3:G3')->applyFromArray(array('font' => array('size' => 12,'bold' => TRUE,'color' => array('rgb' => '800000'),'name'  => 'Arial')));
		$sheet->getStyle('A3')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		$objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setUnderline(true);
		
		$objPHPExcel->getActiveSheet()->SetCellValue('A4','PENDING ORDER');
		$sheet->mergeCells('A4:G4');
		$objPHPExcel->getActiveSheet()->getStyle('A4:G4')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'color' => array('rgb' => '6600ff'),'name'  => 'Arial')));
		
		$objPHPExcel->getActiveSheet()->SetCellValue('A5',$date_range);
		$sheet->mergeCells('A5:G5');
		$objPHPExcel->getActiveSheet()->getStyle('A5:G5')->applyFromArray(array('font' => array('size' => 8,'bold' => TRUE,'color' => array('rgb' => '000000'),'name'  => 'Arial')));
		
		$objPHPExcel->getActiveSheet()->SetCellValue('A6','Remarks : 0');
		$sheet->mergeCells('A6:G6');
		$objPHPExcel->getActiveSheet()->getStyle('A6:G6')->applyFromArray(array('font' => array('size' => 9,'bold' => TRUE,'color' => array('rgb' => '6600ff'),'name'  => 'Arial')));
		
		$rowCount = 8;
		$result = $this->db->query("select * from tbl_pending_order where status='2'")->result();
		foreach ($result as $row)
		{
			$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,$row->company);
			$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount,$row->item_code);
			$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount,$row->item_name);
			$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$row->pack);
			$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$row->qty);
			$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$row->f_qty);
			$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount,$row->division);
			
			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':G'.$rowCount)->applyFromArray($BStyle);
			
			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':G'.$rowCount)->applyFromArray(array('font' => array('size' => 8,'bold' => false,'color' => array('rgb' => '000000'),'name'  => 'Arial')));
			$rowCount++;
		}
		
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
		$file_name = "email_files/insert_pending_order_fail_report_".time().".xls";
		$objWriter->save($file_name);

		return $file_name;
	}
	
	/*************************staff reports*****************************/
	public function staff_download_item_wise_report($user_session,$user_division,$user_compcode,$from,$to,$download_type)
	{
		$this->load->library('excel');
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		error_reporting(0);
		ob_clean();
		
		date_default_timezone_set('Asia/Calcutta');
		$from1 	= date("d-M-Y",strtotime($from));
		$to1 	= date("d-M-Y",strtotime($to));

		$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A5','')
		->setCellValue('B5','CODE')
		->setCellValue('C5','CUSTOMER')
		->setCellValue('D5','QTY')
		->setCellValue('E5','FREE')
		->setCellValue('F5','AMOUNT')
		->setCellValue('G5','ADDRESS')
		->setCellValue('H5','MOBILE');
		
		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(5);
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(6);
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(6);
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(8);
		$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(99);
		$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(64);
		
		$sheet = $objPHPExcel->getActiveSheet();
		$sheet->setCellValueByColumnAndRow(0, 1, "D.R.DISTRIBUTORS PVT.LTD.");
		$sheet->setCellValueByColumnAndRow(0, 2, "200 B  GAUTAM NAGAR NEW DELHI 110049");
		$sheet->setCellValueByColumnAndRow(0, 3, "Item Wise - Customer Wise Sale");
		$sheet->setCellValueByColumnAndRow(0, 4, "From :$from1 To : $to1");
		$sheet->mergeCells('A1:H1');
		$sheet->mergeCells('A2:H2');
		$sheet->mergeCells('A3:H3');
		$sheet->mergeCells('A4:H4');
		$sheet->getStyle('A1')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		$sheet->getStyle('A2')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		$sheet->getStyle('A3')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		
		$objPHPExcel->getActiveSheet()->getStyle('A1:H1')->applyFromArray(array('font' => array('size' => 18,'bold' => FALSE,'name'  => 'Calibri','color' => ['rgb' => '973939'],)));		
		
		$objPHPExcel->getActiveSheet()->getStyle('A2:H2')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Calibri','color' => ['rgb' => '398000'],)));		
		
		$objPHPExcel->getActiveSheet()->getStyle('A3:H3')->applyFromArray(array('font' => array('size' => 15,'bold' => TRUE,'name'  => 'Calibri','color' => ['rgb' => '000080'],)));	
		$objPHPExcel->getActiveSheet()->getStyle('A3:H3')->getFont()->setUnderline(true);		
		
		$objPHPExcel->getActiveSheet()->getStyle('A4:H4')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Calibri','color' => ['rgb' => '973939'],)));			
		
		$objPHPExcel->getActiveSheet()
        ->getStyle('A5:H5')
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB('FDFE9F');
		
		$BStyle = array(
		  'borders' => array(
			'allborders' => array(
			  'style' => PHPExcel_Style_Border::BORDER_THIN
			)
		  )
		);
		$objPHPExcel->getActiveSheet()->getStyle('A5:H5')->applyFromArray($BStyle);
		
		$objPHPExcel->getActiveSheet()->getStyle('A5:H5')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Calibri','color' => ['rgb' => '973939'],)));	
		
		$medicine_josn 	= $this->Scheme_Model->medicine_josn_read();
		$acm_josn	 	= $this->Scheme_Model->acm_josn_read();
		
		$myint_i = 0;
		$query = $this->db->query("select item_name,acno,item_code,itemc,packing,qty,fqty,netamt,vdt from tbl_sales_staff where division='$user_division' and compcode='$user_compcode' and vdt>='$from' and vdt<= '$to' order by item_name asc")->result();
		$rowCount 		= 6;
		$total_qty1 	= 0;
		$total_free1 	= 0;
		$total_amt1 	= 0;
		$itm_c1 = $itm_c2 =0;
		$itm_c3 = $itm_c4 =0;
		$showone = 0;
		$fileok = 0;
		foreach($query as $row)
		{
			$fileok = 1;
			$item_code 	= $row->item_code;
			$c = count($medicine_josn);
			for($i=0;$i<$c;$i++)
			{
				if($medicine_josn[$i]["item_code"]==$item_code)
				{
					$total_qty_sk = $medicine_josn[$i]["batchqty"];
				}
			}
			/*$row2 = $this->db->query("select batchqty from tbl_medicine where item_code='$item_code'")->row();
			$total_qty_sk = $row2->batchqty;*/
			
			$itm_c3 = $row->item_code;
			if($itm_c3!=$itm_c4)
			{
				if($showone!=0)
				{
					$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,"Total");
					$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$total_qty);
					$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$total_free);
					$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$total_amt);
					
					$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray($BStyle);
					$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Calibri','color' => ['rgb' => '000080'],)));	
					$rowCount++;
				}
			}
			$showone++;
			
			$itm_c1 = $row->item_code;
			if($itm_c1!=$itm_c2)
			{
				$itm_c2 = $row->item_code;
				$itm_c4 = $row->item_code;
				$sheet->mergeCells('A'.$rowCount.':H'.$rowCount);
				$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,"Item :".$row->item_name." PACK :".$row->packing." Quantity: ".$total_qty_sk);
				$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Calibri','color' => ['rgb' => '973939'],)));		
				$rowCount++;
				
				$total_qty 	= 0;
				$total_free	= 0;
				$total_amt 	= 0;
			}
			
			$acno = $row->acno;
			$c = count($acm_josn);
			for($i=0;$i<$c;$i++)
			{
				if($acm_josn[$i]["code"]==$acno)
				{
					$altercode 	= $acm_josn[$i]["altercode"];
					$name 		= $acm_josn[$i]["name"];
					$address 	= $acm_josn[$i]["address"];
					$mobile 	= $acm_josn[$i]["mobile"];
				}
			}
			
			//$row3 = $this->db->query("select * from tbl_acm where code='$row->acno'")->row();
				
			$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount,$altercode);
			$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount,$name);
			$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$row->qty);
			$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$row->fqty);
			$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$row->netamt);
			$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount,base64_decode($address));
			$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount,$mobile);
			$objPHPExcel->getActiveSheet()->getStyle('H'.$rowCount)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray($BStyle);
			
			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray(array('font' => array('size' => 10,'bold' => FALSE,'name'  => 'Calibri')));
			$rowCount++;
			
			$total_qty 	= $total_qty 	+ $row->qty;
			$total_free	= $total_free 	+ $row->fqty;
			$total_amt 	= $total_amt 	+ $row->netamt;
			
			$total_qty1	= $total_qty1	+ $row->qty;
			$total_free1= $total_free1 	+ $row->fqty;
			$total_amt1	= $total_amt1 	+ $row->netamt;			
		}
		
		/**************last walay total ko show ke liya******************/
		$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,"Total");
		$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$total_qty);
		$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$total_free);
		$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$total_amt);
		
		$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray($BStyle);
		$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Calibri','color' => ['rgb' => '000080'],)));	
		$rowCount++;
		/*******************************************************/
		
		$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,"Grand Total:");
		$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$total_qty1);
		$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$total_free1);
		$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$total_amt1);
		
		$objPHPExcel->getActiveSheet()
        ->getStyle('A'.$rowCount.':H'.$rowCount)
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB('FDFE9F');
		
		$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray($BStyle);
		
		$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Calibri','color' => ['rgb' => '973939'],)));
		
		$name = "Item Wise - Customer Wise Sale";
		if($download_type=="direct_download")
		{
			$file_name = $name.".xls";
			
			//$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
			$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
			/*$objWriter->save('uploads_sales/kapilkifile.xls');*/
			
			header('Content-type: application/vnd.ms-excel');
			header('Content-Disposition: attachment; filename='.$file_name);
			header('Cache-Control: max-age=0');
			ob_start();
			$objWriter->save('php://output');
			$data = ob_get_contents();
		}
		if($download_type=="cronjob_download")
		{
			if($fileok==1)
			{
				$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
				$file_name = "email_files/item_wise_report_".$user_compcode."_".$user_division."_".time().".xls";
				$objWriter->save($file_name);
				return $file_name;
			}
			else
			{
				$file_name = "";
				return $file_name;
			}
		}
	}
	
	public function staff_download_chemist_wise_report($user_session,$user_division,$user_compcode,$from,$to,$download_type)
	{
		$this->load->library('excel');
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		error_reporting(0);
		ob_clean();
		
		$tbl_staffdetail = $this->db->query("select company_full_name,comp_altercode from tbl_staffdetail where compcode='$user_compcode'")->row();
		
		date_default_timezone_set('Asia/Calcutta');
		$from1 	= date("d-M-Y",strtotime($from));
		$to1 	= date("d-M-Y",strtotime($to));

		$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A6','Party Name')
		->setCellValue('B6','Item Code')
		->setCellValue('C6','Item Name')
		->setCellValue('D6','Pack')
		->setCellValue('E6','Rate')
		->setCellValue('F6','Qty.')
		->setCellValue('G6','Free')
		->setCellValue('H6','Amount')
		->setCellValue('I6','Dis.')
		->setCellValue('J6','Address')
		->setCellValue('K6','Mobile');
		
		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(8);
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(5);
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(5);
		$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(5);
		$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(7);
		$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(5);
		$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(70);
		$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(30);
		
		$sheet = $objPHPExcel->getActiveSheet();
		$sheet->setCellValueByColumnAndRow(0, 1, "D.R.DISTRIBUTORS PVT.LTD.");
		$sheet->setCellValueByColumnAndRow(0, 2, "200 B  GAUTAM NAGAR NEW DELHI 110049\nCIN : U51909DL2004PTC125295  GST No. : 07AABCD9532A1Z1");
		$sheet->setCellValueByColumnAndRow(0, 3, "CUSTOMER-ITEM WISE SALE");
		$sheet->setCellValueByColumnAndRow(0, 4, "From :$from1 To : $to1");
		$sheet->setCellValueByColumnAndRow(0, 5, "COMPANY : $tbl_staffdetail->comp_altercode  [ $tbl_staffdetail->company_full_name ]   DIVISION : $user_division");
		$objPHPExcel->getActiveSheet()->getRowDimension('2')->setRowHeight(25);
		$objPHPExcel->getActiveSheet()->getStyle('A2')->getAlignment()->setWrapText(true);
		$sheet->mergeCells('A1:K1');
		$sheet->mergeCells('A2:K2');
		$sheet->mergeCells('A3:K3');
		$sheet->mergeCells('A4:K4');
		$sheet->mergeCells('A5:K5');
		$sheet->getStyle('A1')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		$sheet->getStyle('A2')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		$sheet->getStyle('A3')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		
		$objPHPExcel->getActiveSheet()->getStyle('A1:K1')->applyFromArray(array('font' => array('size' => 12,'bold' => FALSE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));		
		
		$objPHPExcel->getActiveSheet()->getStyle('A2:K2')->applyFromArray(array('font' => array('size' => 8,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));		
		
		$objPHPExcel->getActiveSheet()->getStyle('A3:K3')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));	
		$objPHPExcel->getActiveSheet()->getStyle('A3:K3')->getFont()->setUnderline(true);		
		
		$objPHPExcel->getActiveSheet()->getStyle('A4:K4')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));
		
		$objPHPExcel->getActiveSheet()->getStyle('A5:K5')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));		
		
		$objPHPExcel->getActiveSheet()
        ->getStyle('A6:K6')
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB('e68c85');
		
		$BStyle = array(
		  'borders' => array(
			'allborders' => array(
			  'style' => PHPExcel_Style_Border::BORDER_THIN
			)
		  )
		);
		$objPHPExcel->getActiveSheet()->getStyle('A6:K6')->applyFromArray($BStyle);
		$objPHPExcel->getActiveSheet()->getStyle('A6:K6')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));
		
		$myint_i = 0;
		$query = $this->db->query("select * from tbl_sales_staff where division='$user_division' and compcode='$user_compcode' and vdt>='$from' and vdt<= '$to' order by acno asc")->result();
		$rowCount 		= 7;
		$total_qty1 	= 0;
		$total_free1 	= 0;
		$total_amt1 	= 0;
		$fileok=0;
		foreach($query as $row)
		{		
			$fileok=1;
			$row3 = $this->db->query("select * from tbl_acm where code='$row->acno'")->row();
			
			$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,$row3->name);
			$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount,$row->itemc);
			$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount,$row->item_name);
			$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$row->packing);
			$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$row->qty);
			$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$row->fqty);
			$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount,$row->dis);
			$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount,$row->netamt);
			$objPHPExcel->getActiveSheet()->SetCellValue('I'.$rowCount,$row->dis);
			$objPHPExcel->getActiveSheet()->SetCellValue('J'.$rowCount,base64_decode($row3->address));
			$objPHPExcel->getActiveSheet()->SetCellValue('K'.$rowCount,$row3->mobile);
			$objPHPExcel->getActiveSheet()->getStyle('K'.$rowCount)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':K'.$rowCount)->applyFromArray($BStyle);
			
			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':K'.$rowCount)->applyFromArray(array('font' => array('size' => 9,'bold' => false,'name'  => 'Arial','color' => ['rgb' => '000000'],)));
			
			$total_amt 	= $total_amt 	+ $row->netamt;
			$rowCount++;
		}
		
		$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,"Total:");
		$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount,$total_amt);
		
		$objPHPExcel->getActiveSheet()
        ->getStyle('A'.$rowCount.':K'.$rowCount)
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB('FDFE9F');
		
		$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':K'.$rowCount)->applyFromArray($BStyle);
		
		$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':K'.$rowCount)->applyFromArray(array('font' => array('size' => 9,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '973939'],)));
		
		$name = "Customer - Item Wise Sale";
		if($download_type=="direct_download")
		{
			$file_name = $name.".xls";
			
			//$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
			$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
			/*$objWriter->save('uploads_sales/kapilkifile.xls');*/
			
			header('Content-type: application/vnd.ms-excel');
			header('Content-Disposition: attachment; filename='.$file_name);
			header('Cache-Control: max-age=0');
			ob_start();
			$objWriter->save('php://output');
			$data = ob_get_contents();
		}
		if($download_type=="cronjob_download")
		{
			if($fileok==1)
			{
				$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
				$file_name = "email_files/chemist_wise_report_".$user_compcode."_".$user_division."_".time().".xls";
				$objWriter->save($file_name);
				return $file_name;
			}
			else
			{
				$file_name = "";
				return $file_name;
			}
		}
	}

	
	/******************27-01-2020********************************/	
	public function staff_download_stock_and_sales_analysis($user_session,$user_division,$user_compcode,$year,$month,$d1,$d2,$vdt1,$vdt2,$download_type)
	{
		$this->load->library('excel');
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		error_reporting(0);
		ob_clean();
		
		$division = $user_division;
		$compcode = $user_compcode;
		
		$tbl_staffdetail = $this->db->query("select company_full_name,comp_altercode from tbl_staffdetail where compcode='$user_compcode' and id='$user_session'")->row();	
		
		$report = "From : $d1 To:  $d2";

		$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A6','Item')
		->setCellValue('B6','Pack')
		->setCellValue('C6','Opening')
		->setCellValue('D6','Purchase / Return')
		->setCellValue('E6','Sale')
		->setCellValue('F6','Closing');
		
		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
		
		$sheet = $objPHPExcel->getActiveSheet();
		$sheet->setCellValueByColumnAndRow(0, 1, "D.R.DISTRIBUTORS PVT.LTD.");
		$sheet->setCellValueByColumnAndRow(0, 2, "200 B  GAUTAM NAGAR NEW DELHI 110049\nCIN : U51909DL2004PTC125295  GST No. : 07AABCD9532A1Z1");
		$sheet->setCellValueByColumnAndRow(0, 3, "Stock And Sales Analysis");
		$sheet->setCellValueByColumnAndRow(0, 4, $report);
		$sheet->setCellValueByColumnAndRow(0, 5, "COMPANY : $tbl_staffdetail->comp_altercode  [ $tbl_staffdetail->company_full_name ]   DIVISION : $user_division");
		$objPHPExcel->getActiveSheet()->getRowDimension('2')->setRowHeight(25);
		$objPHPExcel->getActiveSheet()->getStyle('A2')->getAlignment()->setWrapText(true);
		$sheet->mergeCells('A1:F1');
		$sheet->mergeCells('A2:F2');
		$sheet->mergeCells('A3:F3');
		$sheet->mergeCells('A4:F4');
		$sheet->mergeCells('A5:F5');
		$sheet->getStyle('A1')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		$sheet->getStyle('A2')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		$sheet->getStyle('A3')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		
		$objPHPExcel->getActiveSheet()->getStyle('A1:F1')->applyFromArray(array('font' => array('size' => 12,'bold' => FALSE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));		
		
		$objPHPExcel->getActiveSheet()->getStyle('A2:F2')->applyFromArray(array('font' => array('size' => 8,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));		
		
		$objPHPExcel->getActiveSheet()->getStyle('A3:F3')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));	
		$objPHPExcel->getActiveSheet()->getStyle('A3:F3')->getFont()->setUnderline(true);		
		
		$objPHPExcel->getActiveSheet()->getStyle('A4:F4')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));
		
		$objPHPExcel->getActiveSheet()->getStyle('A5:F5')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));		
		
		$objPHPExcel->getActiveSheet()
        ->getStyle('A6:F6')
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB('e68c85');
		
		$BStyle = array(
		  'borders' => array(
			'allborders' => array(
			  'style' => PHPExcel_Style_Border::BORDER_THIN
			)
		  )
		);
		$objPHPExcel->getActiveSheet()->getStyle('A6:F6')->applyFromArray($BStyle);
		$objPHPExcel->getActiveSheet()->getStyle('A6:F6')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));
		
		$medicine_josn  		= $this->Scheme_Model->medicine_josn_read();
		$medicine_month_josn 	= $this->Scheme_Model->medicine_month_josn_read($year,$month);
		
		//$query = $this->db->query("select item_name,packing,batchqty,item_code from tbl_stock_of_medicine_month_to_month where division='$user_division' and compcode='$user_compcode' and year='$year' and month='$month' order by item_name asc")->result();
		$rowCount 		= 7;
		$total_qty1 	= 0;
		$total_free1 	= 0;
		$total_amt1 	= 0;
		$fileok=0;
		$c = count($medicine_month_josn);
		for($i=0;$i<$c;$i++)
		{
			if($medicine_month_josn[$i]["division"]==$division && $medicine_month_josn[$i]["compcode"]==$compcode)
			{
				$fileok=1;
				$item_name 	= $medicine_month_josn[$i]["item_name"];	
				$packing 	= $medicine_month_josn[$i]["packing"];	
				$batchqty 	= $medicine_month_josn[$i]["batchqty"];	
				$item_code 	= $medicine_month_josn[$i]["item_code"];
				
				$qty 		= $batchqty;
				$time 	= time();
				
				$sale 	= 0;
				$query1 = $this->db->query("select qty from tbl_sales_staff where item_code='$item_code' and division='$division' and compcode='$compcode' and vdt>='$vdt1' and vdt<='$vdt2'")->result();
				foreach($query1 as $row1)
				{
					$sale = $sale + $row1->qty;
				}
				
				$closing=0;
				$cs = count($medicine_josn);
				for($is=0;$is<$cs;$is++)
				{
					if($medicine_josn[$is]["item_code"]==$item_code)
					{
						$closing = $medicine_josn[$is]["batchqty"];
					}
				}
				/*$row = $this->db->query("select batchqty from tbl_medicine where item_code='$item_code'")->row();
				if($row->batchqty!="")
				{
					$closing = $row->batchqty;
				}*/
				$purchase = $qty - $closing;
				$purchase = $sale - $purchase;
				
				$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,$item_name);
				$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount,$packing);
				$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount,$qty);
				$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$purchase);
				$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$sale);
				$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$closing);
				
				$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':F'.$rowCount)->applyFromArray($BStyle);
				
				$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':F'.$rowCount)->applyFromArray(array('font' => array('size' => 9,'bold' => false,'name'  => 'Arial','color' => ['rgb' => '000000'],)));
				
				$rowCount++;
			}
		}
		
		$name = "Stock And Sales Analysis";
		if($download_type=="direct_download")
		{
			$file_name = $name.".xls";
			
			//$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
			$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
			/*$objWriter->save('uploads_sales/kapilkifile.xls');*/
			
			header('Content-type: application/vnd.ms-excel');
			header('Content-Disposition: attachment; filename='.$file_name);
			header('Cache-Control: max-age=0');
			ob_start();
			$objWriter->save('php://output');
			$data = ob_get_contents();
		}
		if($download_type=="cronjob_download")
		{
			if($fileok==1)
			{
				$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
				$file_name = "email_files/stock_and_sales_analysis_report_".time().".xls";
				$objWriter->save($file_name);
				return $file_name;
			}
			else
			{
				$file_name = "";
				return $file_name;
			}
		}
	}}