<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Cronjob_Model extends CI_Model
{
	public function create_medicine_json()
	{
		error_reporting(0);
		$i = 0;
		$q = $this->db->query("select * from tbl_medicine order by item_name asc")->result();
		foreach($q as $row)
		{
			if(substr($row->item_name,0,1)==".")
			{
			}
			else
			{
				if($row->misc_settings=="#ITNOTE" && $row->batchqty=="0.000")
				{					

				}
				else
				{
					if($row->sale_rate=="0" || $row->sale_rate=="0.0")
					{					

					}
					else
					{						
						$id			=	$row->id; 
						$company_name=	$row->company_full_name;
						$title		=	$row->title;
						$item_name	=	$row->item_name;
						$batch_no	=	$row->batch_no;
						$item_code	=	$row->item_code;
						$packing	=	$row->packing;
						$sale_rate	=	$row->sale_rate;
						$mrp		=	$row->mrp;
						$salescm1	=	$row->salescm1;
						$salescm2	=	$row->salescm2;
						$batchqty	=	$row->batchqty;
						$expiry		=	$row->expiry;
						$gstper		=	$row->gstper;
						$compcode	=	$row->compcode;
						
						$image 		=   "";
						$row2 		=   $this->db->query("select * from tbl_medicine_image where itemid='$id'")->row();
						if($row2->image!="")
						{
							$image      =   base_url()."uploads/manage_medicine_image/photo/resize/".$row2->image;
						}
						$discount	=	"4.5";
						$row2 		=   $this->db->query("select * from tbl_company_discount where compcode='$compcode' and status='1'")->row();
						if($row2->discount!="")
						{
							$discount	=	$row2->discount;
						}
						
						/*********************yha decount karta h**************/
						$final_price0=  $sale_rate * $discount / 100;
						$final_price0=	$sale_rate - $final_price0;
						
						/*********************yha gst add karta h**************/
						$final_price=   $final_price0 * $gstper / 100;
						$final_price=	$final_price0 + $final_price;
						
						$final_price= 	round($final_price,2);
						$i_code		=	$row->i_code;

						$time = time();
						$posts[] = array('id'=> $id,'company_name'=>$company_name,'title'=> $title,'item_name'=>$item_name,'batch_no'=>$batch_no, 'item_code'=>$item_code,'packing'=>$packing,'mrp'=>$mrp,'expiry'=>$expiry,'batchqty'=>$batchqty,'salescm1'=>$salescm1,'salescm2'=>$salescm2,'sale_rate'=>$sale_rate,'i_code'=>$i_code,'gstper'=>$gstper,'discount'=>$discount,'discount'=>$discount,'final_price'=>$final_price,'image'=>$image,'compcode'=>$compcode,'time'=>$time);
						$i++;
					}
				}
			}
		}
		if($posts!="")
		{
			$fp = fopen('uploads_json/medicine_json.json', 'w');
			fwrite($fp, json_encode($posts));
			fclose($fp);
		}
	}
		public function create_new_json_for_items()
	{
		$i = 0;
		$q = $this->db->query("select * from tbl_medicine order by item_name asc")->result();
		foreach($q as $row)
		{
			if(substr($row->item_name,0,1)==".")
			{
			}
			else
			{
				/*if($row->misc_settings=="#ITNOTE" || $row->batchqty=="0.000")
				{					

				}
				else
				{*/
					if($row->mrp=="0" || $row->mrp=="0.0")
					{					

					}
					else
					{
						$posme 		= 	$i;
						$id			=	$row->id; 
						$company_name=	$row->company_name;
						$title		=	$row->title;
						$item_name	=	$row->item_name;
						$batch_no	=	$row->batch_no;
						$item_code	=	$row->item_code;
						$packing	=	$row->packing;
						$sale_rate	=	$row->sale_rate;
						$mrp		=	$row->mrp;
						$salescm1	=	$row->salescm1;
						$salescm2	=	$row->salescm2;
						$batchqty	=	$row->batchqty;
						$expiry		=	$row->expiry;
						$i_code		=	$row->i_code;						

						$time = time();
						$posts[] = array('id'=> $id,'company_name'=>$company_name,'title'=> $title,'item_name'=>$item_name,'batch_no'=>$batch_no, 'item_code'=>$item_code,'packing'=>$packing,'mrp'=>$mrp,'expiry'=>$expiry,'batchqty'=>$batchqty,'salescm1'=>$salescm1,'salescm2'=>$salescm2,'sale_rate'=>$sale_rate,'posme'=>$posme,'i_code'=>$i_code,'time'=>$time);
						$i++;
					}
				//}
			}
		} 
		if($posts!="")
		{
			$fp = fopen('uploads_json/medicine_results.json', 'w');
			fwrite($fp, json_encode($posts));
			fclose($fp);
		}
	}
	
	public function create_new_json_for_items_stock_and_sales_analysis()
	{	
		error_reporting(0);
		$time 	= time();
		$year 	= date("Y",$time);
		$month 	= date("m",$time);
		$url 	= 'uploads_json/medicine_month_'.$year.'_'.$month.'.json';
		$x = file_exists($url);
		if($x==0)
		{
			$i = 0;
			$q = $this->db->query("select * from tbl_medicine order by item_name asc")->result();
			foreach($q as $row)
			{
				if(substr($row->item_name,0,1)==".")
				{
				}
				else
				{
					if($row->misc_settings=="#ITNOTE" && $row->batchqty=="0.000")
					{					

					}
					else
					{
						if($row->mrp=="0" || $row->mrp=="0.0")
						{					

						}
						else
						{
							$posme 			= 	$i;
							$id				=	$row->id; 
							$comp_altercode	=	$row->comp_altercode;
							$compcode		=	$row->compcode;
							$item_code		=	$row->item_code;
							$item_name		=	$row->item_name;
							$packing		=	$row->packing;
							$batchqty		=	$row->batchqty;
							$company_name	=	$row->company_name;
							$division		=	$row->division;
							$expiry			=	$row->expiry;
							$i_code			=	$row->i_code;						

							$time = time();
							$posts[] = array('id'=> $id,'comp_altercode'=>$comp_altercode,'compcode'=> $compcode,'item_code'=>$item_code,'item_name'=>$item_name, 'packing'=>$packing,'batchqty'=>$batchqty,'company_name'=>$company_name,'division'=>$division,'expiry'=>$expiry,'i_code'=>$i_code);
							$i++;
						}
					}
				}
			} 
			if($posts!="")
			{
				
				$fp = fopen($url, 'w');
				fwrite($fp, json_encode($posts));
				fclose($fp);
			}
		}
	}

	public function create_new_json_for_acm()
	{
		$i = 0;
		$q = $this->db->query("select * from tbl_acm where slcd='CL' order by id asc")->result();	
		foreach($q as $row)
		{
			if(substr($row->name,0,1)==".")
			{
			}
			else
			{
				$posme 		= 	$i;
				$id			=	$row->id; 
				$code		=	$row->code;
				$altercode	=	$row->altercode;
				$name		=	($row->name);
				$email		=	$row->email;
				$mobile		=	$row->mobile;
				$address	=	$row->address;
				$status		=	$row->status;	
				$exp_date   =   "";

				$time = time();
				$posts[] = array('id'=>$id,'code'=>$code,'altercode'=>$altercode,'name'=>$name,'email'=>$email,'mobile'=>$mobile,'address'=>$address,'status'=>$status,'exp_date'=>$exp_date,'posme'=>$posme);
				$i++;
			}
		}
		if($posts!="")
		{
			//$response['posts'] = $posts;
			$fp = fopen('uploads_json/acm_results.json', 'w');
			fwrite($fp, json_encode($posts));
			fclose($fp);
		}
	}

	public function create_new_json_for_staff()
	{
		/*$i = 0;
		$q = $this->db->query("select staffdetail.id,staffdetail.code,staffdetail.compcode,staffdetail.company_full_name,staffdetail.staffname,staffdetail.degn,staffdetail.memail,staffdetail.mobilenumber,staffdetail.division,staffdetail.automail,staffdetail_other.status,staffdetail_other.exp_date,staffdetail_other.daily_email,staffdetail_other.monthly_email from staffdetail,staffdetail_other where staffdetail.code=staffdetail_other.code order by staffdetail.id asc")->result();
		foreach($q as $row)
		{
			if(substr($row->degn,0,1)==".")
			{
			}
			else
			{
				$posme 		= 	$i;
				$id			=	$row->id;
				$staffname	=	$row->staffname;
				$degn		=	$row->degn;
				$code		=	$row->code;
				$compcode	=	$row->compcode;
				$name		=	strtolower($row->degn);
				$email		=	$row->memail;
				$mobile		=	$row->mobilenumber;
				$division	=	$row->division;
				$automail	=	$row->automail;
				$daily_email=	$row->daily_email;
				$monthly_email=	$row->monthly_email;
				$status		=	$row->status;
				$exp_date	=	$row->exp_date;
				$company_full_name =	$row->company_full_name;				

				$time = time();
				$posts[] = array('id'=> $id, 'code'=> $code, 'compcode'=> $compcode, 'name'=> $name, 'email'=> $email, 'mobile'=> $mobile,'division'=> $division,'company_full_name'=> $company_full_name,'automail'=> $automail,'daily_email'=> $daily_email,'monthly_email'=> $monthly_email, 'status'=> $status, 'exp_date'=> $exp_date, 'posme'=> $posme);
				$i++;
			}
		}
		if($posts!="")
		{
			//$response['posts'] = $posts;
			$fp = fopen('uploads_json/staff_results.json', 'w');
			fwrite($fp, json_encode($posts));
			fclose($fp);
		}*/
	}}