<?php
defined('BASEPATH') OR exit('No direct script access allowed');
ini_set('memory_limit', '-1');
ini_set('post_max_size', '100M');
ini_set('upload_max_filesize', '100M');
ini_set('max_execution_time', 36000);
require_once APPPATH."/third_party/PHPExcel.php";
class Invoice_page extends CI_Controller {
	public function index($altercode,$gstvno)
	{
		error_reporting(0);
		$gstvno 	= ($gstvno);
		$altercode 	= ($altercode);
		
		$qr = $this->db->query("select code from tbl_acm where altercode='$altercode' ")->row();
		
		$qr1 = $this->db->query("select * from tbl_sales_main where gstvno='$gstvno' and acno='$qr->code'")->row();
		
		$this->Excel_Model->chemist_invoice_report_excel($qr1->gstvno,$qr1->acno,$qr1->vdt,"invoice_page_3party");
		exit;
	}
	
	public function gstvno_to_altercode($gstvno)
	{
		error_reporting(0);
		$gstvno 	= ($gstvno);		
		
		$qr1 = $this->db->query("select * from tbl_sales_main where gstvno='$gstvno'")->row();
		
		$qr = $this->db->query("select altercode from tbl_acm where code='$qr1->acno' ")->row();
		
		echo $qr->altercode;
	}
}