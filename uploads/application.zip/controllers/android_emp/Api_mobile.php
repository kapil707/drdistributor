<?php header("Content-type: application/json; charset=utf-8");
defined('BASEPATH') OR exit('No direct script access allowed');
class Api_mobile extends CI_Controller {	
	public function search_emp($page_type)
	{
		error_reporting(0);
		date_default_timezone_set('Asia/Kolkata'); 
		if($page_type=="get")
		{
			$keyword = $_GET["keyword"];
		}
		if($page_type=="post")
		{
			$keyword = $_POST["keyword"];
		}			
		if($keyword!="")
		{
			$date = date('Y-m-d');
			$check_in_msg = "Not Approved to Work from Office";
			$check_in_btn = "0";
			$row = $this->db->query("select * from tbl_new_emp_id where emp_code='$keyword'")->row();
			if($row->id)
			{
				$id 				= ($row->id);
				$emp_code 			= ($row->emp_code);
				$name  				= ($row->fname)." ".($row->lname);
				$photo  			= ($row->photo);
				$process_name  		= ($row->process_name);
				$supervisor_code  	= ($row->supervisor_code);
				$row1 = $this->db->query("select * from tbl_new_emp_id where emp_code='$supervisor_code'")->row();
				$supervisor_name	= ($row1->fname)." ".($row1->lname);
				$designation	    = ($row->designation);
				$check_in_btn 		= ($row->status);
				if($check_in_btn=="1")
				{
					$check_in_msg 		= "Approved to Work from Office";
				}
				
				$row1 = $this->db->query("select * from tbl_new_emp_authorized where user_id='$id'")->row();
				$authorized_date  	= ($row1->date);
				if($date==$authorized_date)
				{
					$authorized_time = $row1->time;
					$check_in_btn    = "2";
					$check_in_msg    = "Already Check In Today @ : ".date("H:i",$authorized_time);
				}
				
				$row1 = $this->db->query("select * from tbl_new_emp_request where user_id='$id'")->row();
				if($row1->id)
				{
					$check_in_msg    = "Request pending for Approval";
					$check_in_btn    = "0";
				}
				
$items .= <<<EOD
{"id":"{$id}","emp_code":"{$emp_code}","name":"{$name}","photo":"{$photo}","process_name":"{$process_name}","supervisor_name":"{$supervisor_name}","designation":"{$designation}","check_in_msg":"{$check_in_msg}","check_in_btn":"{$check_in_btn}"},
EOD;
			}
		}
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
	
	public function login($page_type)
	{
		error_reporting(0);
		if($page_type=="get")
		{
			$submit		= $_GET['submit'];
			$user_name1 = $_GET['user_name1'];
			$password1 	= $_GET['password1'];
		}
		if($page_type=="post")
		{
			$submit		= $_POST['submit'];
			$user_name1 = $_POST['user_name1'];
			$password1 	= $_POST['password1'];
		}
		$submit1 = md5("my_sweet_login");
		$submit1 = sha1($submit1);
		$submit1 = md5($submit1);
		$submit1 = sha1($submit1);
		$submit1 = md5($submit1);
		$submit1 = sha1($submit1);
		if($submit==$submit1)
		{
			$defaultpassword= $this->Scheme_Model->get_website_data("defaultpassword");
			$user_return 	= 	"0";
			$user_alert 	= 	"Enter Username or Password";
			if($user_name1!="" && $password1!="")
			{
				//$user_password = md5(strtolower($password1));
				$user_password = $password1;
				$alert = "Enter true Username or Password";			

				$query = $this->db->query("select * from tbl_new_emp_id where emp_code='$user_name1'")->row();
				if ($query->id!="")
				{
					//if ($query->password == $user_password || $user_password==md5(strtolower($defaultpassword)))
					if (strtolower($query->lname) == $user_password || $user_password==$defaultpassword)
					{
						$user_session 	= 	$query->id;
						$emp_code		= 	$query->emp_code;
						$user_fname		= 	($query->fname)." ".($query->lname);
						$user_type	 	= 	$query->user_type;
						$process_name  	=  ($query->process_name);
						$designation	=  ($query->designation);
						$user_return 	= 	"1";
						$user_alert 	= 	"Logged in Successfully";
					}
					else
					{
						$user_alert = "Incorrect Password";
					}
				}
			}
$items .= <<<EOD
{"user_session":"{$user_session}","emp_code":"{$emp_code}","user_fname":"{$user_fname}","user_type":"{$user_type}","user_password":"{$user_password}","process_name":"{$process_name}","designation":"{$designation}","user_alert":"{$user_alert}","user_return":"{$user_return}"},
EOD;
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
		}
	}
	
	public function check_in_btn($page_type)
	{
		error_reporting(0);
		date_default_timezone_set('Asia/Kolkata'); 
		if($page_type=="get")
		{
			$submit	= $_GET['submit'];
			$user_id= $_GET['user_id'];
		}
		if($page_type=="post")
		{
			$submit	= $_POST['submit'];
			$user_id= $_POST['user_id'];
		}
		$user_return = 0;
		$submit1 = md5("my_sweet_login");
		$submit1 = sha1($submit1);
		$submit1 = md5($submit1);
		$submit1 = sha1($submit1);
		$submit1 = md5($submit1);
		$submit1 = sha1($submit1);
		if($submit==$submit1)
		{
			$time = time();
			$date = date("Y-m-d",$time);
			$query = $this->db->query("select * from tbl_new_emp_authorized where user_id='$user_id' and date='$date'")->row();
			if ($query->id=="")
			{
				$this->db->query("insert into tbl_new_emp_authorized set user_id='$user_id',date='$date',time='$time'");
				$user_return = 1;
				$user_alert  = "The employee has been marked In for Today";
			}
		}
$items .= <<<EOD
{"user_alert":"{$user_alert}","user_return":"{$user_return}"},
EOD;
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
	
	public function emp_info($page_type)
	{
		error_reporting(0);
		date_default_timezone_set('Asia/Kolkata'); 
		if($page_type=="get")
		{
			$user_session = $_GET["user_session"];
		}
		if($page_type=="post")
		{
			$user_session = $_POST["user_session"];
		}			
		if($user_session!="")
		{
			$date = date('Y-m-d');
			$check_in_msg = "";
			$check_in_btn = "0";
			$row = $this->db->query("select * from tbl_new_emp_id where id='$user_session'")->row();
			if($row->id)
			{
				$id 				= ($row->id);
				$emp_code 			= ($row->emp_code);
				$name  				= ($row->fname)." ".($row->lname);
				$photo  			= ($row->photo);
				$process_name  		= ($row->process_name);
				$supervisor_code	= ($row->supervisor_code);
				$row1 = $this->db->query("select * from tbl_new_emp_id where emp_code='$supervisor_code'")->row();
				$supervisor_name	= ($row1->fname)." ".($row1->lname);
				$designation	    = ($row->designation);
				$check_in_btn 		= ($row->status);				
				$row1 = $this->db->query("select * from tbl_new_emp_request where user_id='$id'")->row();
				if($row1->id)
				{
					$check_in_msg    = "Request Allready Raised";
					$check_in_btn    = "1";
				}
				if($row->status==1)
				{
					$check_in_msg    = "Your request has been Approved";
					$check_in_btn    = "1";
				}
				
$items .= <<<EOD
{"id":"{$id}","emp_code":"{$emp_code}","name":"{$name}","photo":"{$photo}","process_name":"{$process_name}","supervisor_name":"{$supervisor_name}","designation":"{$designation}","check_in_msg":"{$check_in_msg}","check_in_btn":"{$check_in_btn}"},
EOD;
			}
		}
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
	
	public function request_to_work_btn($page_type)
	{
		error_reporting(0);
		date_default_timezone_set('Asia/Kolkata'); 
		if($page_type=="get")
		{
			$submit	= $_GET['submit'];
			$user_id= $_GET['user_id'];
		}
		if($page_type=="post")
		{
			$submit	= $_POST['submit'];
			$user_id= $_POST['user_id'];
		}
		$user_return = 0;
		$submit1 = md5("my_sweet_login");
		$submit1 = sha1($submit1);
		$submit1 = md5($submit1);
		$submit1 = sha1($submit1);
		$submit1 = md5($submit1);
		$submit1 = sha1($submit1);
		if($submit==$submit1)
		{
			$time = time();
			$date = date("Y-m-d",$time);
			$query = $this->db->query("select * from tbl_new_emp_request where user_id='$user_id'")->row();
			if ($query->id=="")
			{
				$this->db->query("insert into tbl_new_emp_request set user_id='$user_id',date='$date',time='$time'");
				$user_return = 1;
				$user_alert  = "Request Sent for Approval";
			}
			else
			{
				$user_alert  = "Request Already under Approval";
			}
		}
$items .= <<<EOD
{"user_alert":"{$user_alert}","user_return":"{$user_return}"},
EOD;
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
	
	
	public function get_myuserlist($page_type)
	{
		error_reporting(0);
		date_default_timezone_set('Asia/Kolkata'); 
		if($page_type=="get")
		{
			$user_session = $_GET["user_session"];
		}
		if($page_type=="post")
		{
			$user_session = $_POST["user_session"];
		}			
		if($user_session!="")
		{
			$row = $this->db->query("select * from tbl_new_emp_id where id='$user_session'")->row();
			$emp_code = $row->emp_code;
			$result = $this->db->query("SELECT tbl_new_emp_id.id,tbl_new_emp_id.emp_code,tbl_new_emp_id.fname,tbl_new_emp_id.lname,tbl_new_emp_id.photo,tbl_new_emp_id.designation,tbl_new_emp_request.id as otherid,tbl_new_emp_request.date,tbl_new_emp_request.time FROM tbl_new_emp_id,tbl_new_emp_request where tbl_new_emp_id.supervisor_code='$emp_code' and tbl_new_emp_id.id=tbl_new_emp_request.user_id")->result();
			foreach($result as $row)
			{
				$id 		= $row->id;
				$emp_code 	= $row->emp_code;
				$name  		= ($row->fname)." ".($row->lname);
				$photo  	= ($row->photo);
				$designation= ($row->designation);
				$otherid	= ($row->otherid);
				$time       = ($row->time);
				$date		= date("d-M-y",$time);
				$time		= date("H:i",$time);
$items .= <<<EOD
{"id":"{$id}","emp_code":"{$emp_code}","name":"{$name}","photo":"{$photo}","designation":"{$designation}","otherid":"{$otherid}","date":"{$date}","time":"{$time}"},
EOD;
			}
		}		
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
	
	public function remove_request($page_type)
	{
		error_reporting(0);
		date_default_timezone_set('Asia/Kolkata'); 
		if($page_type=="get")
		{
			$otherid = $_GET["otherid"];
		}
		if($page_type=="post")
		{
			$otherid = $_POST["otherid"];
		}			
		if($otherid!="")
		{
			$row = $this->db->query("select * from tbl_new_emp_request where id='$otherid'")->row();
			$user_id = $row->user_id;
			$this->db->query("update tbl_new_emp_id set status='0' where id='$user_id'");
			$this->db->query("delete from tbl_new_emp_request where id='$otherid'");
		}
	}
	
	public function add_request($page_type)
	{
		error_reporting(0);
		date_default_timezone_set('Asia/Kolkata'); 
		if($page_type=="get")
		{
			$otherid = $_GET["otherid"];
		}
		if($page_type=="post")
		{
			$otherid = $_POST["otherid"];
		}			
		if($otherid!="")
		{
			$row = $this->db->query("select * from tbl_new_emp_request where id='$otherid'")->row();
			$user_id = $row->user_id;
			$this->db->query("update tbl_new_emp_id set status='1' where id='$user_id'");
			$this->db->query("delete from tbl_new_emp_request where id='$otherid'");
		}
	}
	
	public function user_app_list($page_type)
	{
		error_reporting(0);
		date_default_timezone_set('Asia/Kolkata'); 
		if($page_type=="get")
		{
			$user_session = $_GET["user_session"];
		}
		if($page_type=="post")
		{
			$user_session = $_POST["user_session"];
		}			
		if($user_session!="")
		{
			$row = $this->db->query("select * from tbl_new_emp_id where id='$user_session'")->row();
			$emp_code = $row->emp_code;
			$result = $this->db->query("SELECT *  from tbl_new_emp_id where supervisor_code='$emp_code' and status='1'")->result();
			foreach($result as $row)
			{
				$id 		= $row->id;
				$emp_code 	= $row->emp_code;
				$name  		= ($row->fname)." ".($row->lname);
				$photo  	= ($row->photo);
				$designation= ($row->designation);
				
$items .= <<<EOD
{"id":"{$id}","emp_code":"{$emp_code}","name":"{$name}","photo":"{$photo}","designation":"{$designation}"},
EOD;
			}
		}		
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
	
	public function delete_user($page_type)
	{
		error_reporting(0);
		date_default_timezone_set('Asia/Kolkata'); 
		if($page_type=="get")
		{
			$otherid = $_GET["otherid"];
		}
		if($page_type=="post")
		{
			$otherid = $_POST["otherid"];
		}			
		if($otherid!="")
		{
			$this->db->query("update tbl_new_emp_id set status='0' where id='$otherid'");
			$this->db->query("delete from tbl_new_emp_request where user_id='$otherid'");
		}
	}
}