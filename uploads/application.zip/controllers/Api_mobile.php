<?php header("Content-type: application/json; charset=utf-8");
defined('BASEPATH') OR exit('No direct script access allowed');
class Api_mobile extends CI_Controller {
	public function login()
	{
		error_reporting(0);
		$submit = $_REQUEST["submit"];
		$submit1 = md5("my_sweet_login");
		$submit1 = sha1($submit1);
		$submit1 = md5($submit1);
		$submit1 = sha1($submit1);
		$submit1 = md5($submit1);
		$submit1 = sha1($submit1);
		if($submit==$submit1)
		{
			$user_return 	= 	"0";
			$user_alert 	= 	"Wrong Anything Else";
			$user_name1 	= $_REQUEST["user_name1"];
			$password1 		= $_REQUEST["password1"];
			if($user_name1!="" && $password1!="")
			{
				$user_password = md5($password1);
				$alert = "Enter true User name or Password";			
				$query = $this->db->query("select tbl_acm.id,tbl_acm.code,tbl_acm.altercode,tbl_acm.name,tbl_acm.address,tbl_acm.mobile,tbl_acm.invexport,tbl_acm.email,tbl_acm.status as status1,tbl_acm_other.status,tbl_acm_other.password as password,tbl_acm_other.exp_date from tbl_acm left join tbl_acm_other on tbl_acm.code = tbl_acm_other.code where tbl_acm.altercode='$user_name1' and tbl_acm.code=tbl_acm_other.code limit 1")->row();
				if ($query->id!="")
				{
					if ($query->password == $user_password)
					{
						$user_session 	= 	$query->id;
						$user_fname		= 	$query->name;
						$user_code	 	= 	$query->code;
						$user_altercode	= 	$query->altercode;
						$user_type 		= 	"chemist";
						$user_return 	= 	"1";
						$user_alert 	= 	"Logged in Successfully";
					}
					else
					{
						$user_alert = "Incorrect Password";
					}
				}
				else
				{
					$query = $this->db->query("select tbl_staffdetail.compcode,tbl_staffdetail.division,tbl_staffdetail.id,tbl_staffdetail.code,tbl_staffdetail.degn as name,tbl_staffdetail.mobilenumber as mobile,tbl_staffdetail.memail as email,tbl_staffdetail_other.status,tbl_staffdetail_other.exp_date,tbl_staffdetail_other.password from tbl_staffdetail left join tbl_staffdetail_other on tbl_staffdetail.code = tbl_staffdetail_other.code where tbl_staffdetail.memail='$user_name1' and tbl_staffdetail.code=tbl_staffdetail_other.code limit 1")->row();
					if ($query->id!="")
					{
						if ($query->password == $user_password)
						{
							$user_session 	= 	$query->id;
							$user_fname		= 	$query->name;
							$user_code	 	= 	$query->code;
							$user_altercode	= 	$query->code;
							$user_type 		= 	"corporate";
							$user_return 	= 	"1";
							$user_alert 	= 	"Logged in Successfully";
							$user_division	= 	$query->division;
							$user_compcode	= 	$query->compcode;
							$user_compname	= 	"";
						}
						else
						{
							$user_alert = "Incorrect Password";
						}
					}
					else
					{
						$query = $this->db->query("select u.id,u.customer_code,u.customer_name,u.cust_addr1,u.cust_mobile,u.cust_email,u.is_active,u.user_role,u.login_expiry,u.divison,u.company_name,lu.password	from tbl_users u left join tbl_users_other lu on lu.customer_code = u.customer_code where lu.customer_code='$user_name1' limit 1")->row();
						if ($query->id!="")
						{
							if ($query->password == $user_password)
							{
								$user_session 	= 	$query->id;
								$user_fname		= 	$query->customer_name;
								$user_code	 	= 	$query->customer_code;
								$user_altercode	= 	$query->customer_code;
								$user_type 		= 	"sales";
								$user_return 	= 	"1";
								$user_alert 	= 	"Logged in Successfully";
							}
							else
							{
								$user_alert = "Incorrect Password";
							}
						}
						else
						{
							$user_alert = "You Are Not Registered";
						}
					}
				}
			}
$items .= <<<EOD
{"user_session":"{$user_session}","user_fname":"{$user_fname}","user_code":"{$user_code}","user_altercode":"{$user_altercode}","user_type":"{$user_type}","user_password":"{$user_password}","user_alert":"{$user_alert}","user_return":"{$user_return}","user_division":"{$user_division}","user_compcode":"{$user_compcode}","user_compname":"{$user_compname}"},
EOD;
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
		}
	}	
	public function search()
	{
		error_reporting(0);
		$med_date_time = date('d-M-y h:i A');
		$session_id = $_REQUEST["session_id"] = "ok";
		$keyword = $_REQUEST["keyword"];
		if($session_id!="")
		{
			$query = $this->db->query("select * from tbl_medicine where title like '".$keyword."%' or item_name like '".$keyword."%' limit 0,10")->result();
			foreach ($query as $row)
			{
				$posme 		= 	$i;
				$id			=	$row->id;
				$company_name=	$row->company_name;				$title		=	$row->title;
				$item_name	=	$row->item_name;
				$batch_no	=	$row->batch_no;
				$item_code	=	$row->item_code;
				$packing	=	$row->packing;
				$sale_rate	=	$row->sale_rate;
				$mrp		=	$row->mrp;
				$salescm1	=	$row->salescm1;
				$salescm2	=	$row->salescm2;
				$batchqty	=	$row->batchqty;
				$expiry		=	$row->expiry;
				$i_code		=	$row->i_code;
				$compcode 	=   $row->compcode;
				$company_full_name 	=  base64_decode($row->company_full_name);
				$item_date 	=   $row->item_date;
				$present 	=   $row->present;
				$hotdeals 	=   $row->hotdeals;
				$hotdeals_short =   $row->hotdeals_short;			
$items .= <<<EOD
{"id":"{$id}","company_name":"{$company_name}","title":"{$title}","item_name":"{$item_name}","batch_no":"{$batch_no}","item_code":"{$item_code}","packing":"{$packing}","mrp":"{$mrp}","expiry":"{$expiry}","batchqty":"{$batchqty}","salescm1":"{$salescm1}","salescm2":"{$salescm2}","sale_rate":"{$sale_rate}","posme":"{$posme}","i_code":"{$i_code}","compcode":"{$compcode}","company_full_name":"{$company_full_name}","item_date":"{$item_date}","present":"{$present}","hotdeals":"{$hotdeals}","hotdeals_short":"{$hotdeals_short}","time":"{$time}","med_date_time":"{$med_date_time}"},
EOD;
		}
	}
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]<?php
	}
	function clean1($string) {
		// Replaces all spaces with hyphens.		return str_replace('"', "'", $string); // Removes special chars.
	}	
	function clean($string) {
		$string = str_replace(' ', '', $string); // Replaces all spaces with hyphens.
		return preg_replace('/[^A-Za-z0-9\#]/', '', $string); // Removes special chars.
	}		public function get_json()
	{		error_reporting(0);
		$med_date_time = date('d-M-y h:i A');
		$session_id = $_REQUEST["session_id"] = "ok";
		$last_id = $_REQUEST["last_id"];
		$limit = $_REQUEST["limit"];
		if($session_id!="")
		{
			$i = 0;
			$query = $this->db->query("select * from tbl_medicine where id>'$last_id' limit 0,$limit")->result();
			foreach ($query as $row)
			{				$posme 		= 	$i;
				$id			=	$row->id;
				$company_name=	$row->company_name;
				$title		=	strtolower($this->clean($row->item_name));
				$item_name	=	$this->clean1($row->item_name);
				$batch_no	=	$row->batch_no;
				$item_code	=	$row->item_code;
				$packing	=	$this->clean1($row->packing);
				$sale_rate	=	$row->sale_rate;
				$mrp		=	$row->mrp;
				$salescm1	=	$row->salescm1;
				$salescm2	=	$row->salescm2;
				$batchqty	=	round($row->batchqty,2);
				$expiry		=	$row->expiry;
				$i_code		=	$row->i_code;
				$compcode 	=   $row->compcode;
				$company_full_name 	=  base64_decode($row->company_full_name);
				$item_date 	=   $row->item_date;
				$present 	=   round($row->present,2);
				$hotdeals 	=   $row->hotdeals;
				$hotdeals_short 	=   $row->hotdeals_short;
				$i++;
			
$items .= <<<EOD
{"id":"{$id}","company_name":"{$company_name}","title":"{$title}","item_name":"{$item_name}","batch_no":"{$batch_no}","item_code":"{$item_code}","packing":"{$packing}","mrp":"{$mrp}","expiry":"{$expiry}","batchqty":"{$batchqty}","salescm1":"{$salescm1}","salescm2":"{$salescm2}","sale_rate":"{$sale_rate}","posme":"{$posme}","i_code":"{$i_code}","compcode":"{$compcode}","company_full_name":"{$company_full_name}","item_date":"{$item_date}","present":"{$present}","hotdeals":"{$hotdeals}","hotdeals_short":"{$hotdeals_short}","time":"{$time}","med_date_time":"{$med_date_time}"},
EOD;
			}
		}
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
	public function myorders()	{
		error_reporting(0);
		$user_type 		= $_POST["user_type"];
		$user_altercode	= $_POST["user_altercode"]; 
		$user_session 	= $_POST['user_session'];
		if($user_type=="chemist")
		{
			$acm = $this->db->query("select * from tbl_acm where altercode='$id'")->row();
			$id = $acm->id;
		}
		if($user_type=="sales")
		{			$x = $this->db->query("SELECT * FROM `tbl_order` where user_altercode='$user_altercode'")->result();
		}
		else
		{
			$x = $this->db->query("SELECT * FROM `tbl_order` where user_session='$user_session'")->result(); 
		}
		foreach($x as $row)
		{
			$this_time_up = date("d-M-y h:i a ",$row->time);
			if($row->gstvno=="")
			{
				$status = "Pending";
			}
			else
			{
				$status = "Generated";
			}
			$gst = "12";
			$ptr = round($row->sale_rate,2);
$items .= <<<EOD
{"order_id":"{$row->order_id}","med_code":"{$row->item_code}","med_name":"{$row->item_name}","ptr":"{$ptr}","qty":"{$row->quantity}","customer_code":"{$row->customer_code}","gst":"{$gst}","status":"{$status}","user_type":"{$row->user_type}","sales_user_id":"{$row->user_altercode}","this_time_up":"{$this_time_up}","gstvno":"{$row->gstvno}"},
EOD;
		}
if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
	public function myinvoice()
	{
		error_reporting(0);
		$user_type 	= $_POST["user_type"];
		$id 		= $_POST["user_altercode"];
		if($user_type=="chemist")
		{
			$acm = $this->db->query("select * from tbl_acm where altercode='$id'")->row();
			$acno = $acm->code;
		}		
		$x = $this->db->query("SELECT * from tbl_sales where acno='$acno' and mdatatype='insert' order by gstvno desc")->result();
		foreach($x as $row)
		{			$status = "Pending";
			if($row->status==1)
			{				$status = "Generated";
			}
			$vdt 	= date("d-M-y",strtotime($row->vdt));
			$qty 	= round($row->qty,2);
			$fqty 	= round($row->fqty,2);
			$netamt = round($row->netamt,2);
			$taxamt = round($row->taxamt,2);
			$amt 	= round($row->amt,2);			
			$downloadurl = base64_encode($row->gstvno)."/".base64_encode($acno)."/".base64_encode($row->vdt);			
$items .= <<<EOD
{"gstvno":"{$row->gstvno}","vdt":"{$vdt}","vno":"{$row->vno}","psrlno":"{$row->psrlno}","itemc":"{$row->itemc}","item_name":"{$row->item_name}","batch":"{$row->batch}","qty":"{$qty}","fqty":"{$fqty}","netamt":"{$netamt}","taxamt":"{$taxamt}","amt":"{$amt}","status":"{$status}","expiry":"{$row->expiry}","mdatatype":"{$row->mdatatype}","downloadurl":"{$downloadurl}"},
EOD;
		}
if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
	public function acm_search()
	{		error_reporting(0);
		$session_id = $_REQUEST["session_id"] = "ok";
		$keyword = $_REQUEST["keyword"];
		if($session_id!="")
		{
			$query = $this->db->query("select * from tbl_acm where name like '".$keyword."%' limit 0,10")->result();
			foreach ($query as $row)
			{
				if(substr($row->name,0,1)==".")
				{
				}
				else
				{
					$id			=	$row->id;
					$name		=	$row->name;
					$code		=	$row->code;
					$altercode	=	$row->altercode;			
$items .= <<<EOD
{"id":"{$id}","name":"{$name}","code":"{$code}","altercode":"{$altercode}"},
EOD;
				}
			}
		}
if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
}