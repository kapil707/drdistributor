<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Api_website extends CI_Controller {
	public function add_temp_order_no($user_session,$user_type)
	{
		error_reporting(0);
		$x = $user_type."_".$user_session;
		return $x;
	}
	public function login()
	{
		error_reporting(0);
		$submit 	= $_GET["submit"];
		$submit1 	= md5("my_sweet_login");
		$submit1 	= sha1($submit1);
		$submit1	= md5($submit1);
		$submit1 	= sha1($submit1);
		$submit1 	= md5($submit1);
		$submit1 	= sha1($submit1);
		if($submit==$submit1)
		{
			$defaultpassword= $this->Scheme_Model->get_website_data("defaultpassword");
			$user_return 	= 	"0";
			$user_alert 	= 	"Wrong Anything Else";
			$user_name1 	= 	$_GET["user_name1"];
			$password1 		= 	$_GET["password1"];
			if($user_name1!="" && $password1!="")
			{
				$user_password = md5(strtolower($password1));
				$alert = "Enter true User name or Password";			
				$query = $this->db->query("select tbl_acm.id,tbl_acm.code,tbl_acm.altercode,tbl_acm.name,tbl_acm.address,tbl_acm.mobile,tbl_acm.invexport,tbl_acm.email,tbl_acm.status as status1,tbl_acm_other.status,tbl_acm_other.password as password,tbl_acm_other.exp_date,tbl_acm_other.block from tbl_acm left join tbl_acm_other on tbl_acm.code = tbl_acm_other.code where tbl_acm.altercode='$user_name1' and tbl_acm.code=tbl_acm_other.code limit 1")->row();
				if ($query->id!="")
				{
					if ($query->password == $user_password || $user_password==md5(strtolower($defaultpassword)))
					{
						if($query->block=="0")
						{
							$user_session 	= 	$query->id;
							$user_fname		= 	$query->name;
							$user_code	 	= 	$query->code;
							$user_altercode	= 	$query->altercode;
							$user_type 		= 	"chemist";
							$user_return 	= 	"1";
							$user_alert 	= 	"Logged in Successfully";
							$user_temp_rec	=   $this->add_temp_order_no($user_session,$user_type);
						}
						else
						{
							$user_alert = "Your Account Is Blocked";
						}
					}
					else
					{
						$user_alert = "Incorrect Password";
					}
				}
				else
				{
					$query = $this->db->query("select tbl_staffdetail.company_full_name,tbl_staffdetail.compcode,tbl_staffdetail.division,tbl_staffdetail.id,tbl_staffdetail.code,tbl_staffdetail.staffname as name,tbl_staffdetail.mobilenumber as mobile,tbl_staffdetail.memail as email,tbl_staffdetail_other.status,tbl_staffdetail_other.exp_date,tbl_staffdetail_other.password from tbl_staffdetail left join tbl_staffdetail_other on tbl_staffdetail.code = tbl_staffdetail_other.code where tbl_staffdetail.memail='$user_name1' and tbl_staffdetail.code=tbl_staffdetail_other.code limit 1")->row();
					if ($query->id!="")
					{
						if ($query->password == $user_password || $user_password==md5(strtolower($defaultpassword)))
						{
							if($query->status==1)
							{
								$user_session 	= 	$query->id;
								$user_fname		= 	$query->name;
								$user_code	 	= 	$query->code;
								$user_altercode	= 	$query->code;
								$user_type 		= 	"corporate";
								$user_return 	= 	"1";
								$user_alert 	= 	"Logged in Successfully";
								$user_division	= 	$query->division;
								$user_compcode	= 	$query->compcode;
								$user_compname	= 	($query->company_full_name);
							}
							else
							{
								$user_alert = "Access Denied";
							}
						}
						else
						{
							$user_alert = "Incorrect Password";
						}
					}
					else
					{
						$query = $this->db->query("select u.id,u.customer_code,u.customer_name,u.cust_addr1,u.cust_mobile,u.cust_email,u.is_active,u.user_role,u.login_expiry,u.divison,u.company_name,lu.password from tbl_users u left join tbl_users_other lu on lu.customer_code = u.customer_code where lu.customer_code='$user_name1' limit 1")->row();
						if ($query->id!="")
						{
							if ($query->password == $user_password || $user_password==md5(strtolower($defaultpassword)))
							{
								$user_session 	= 	$query->id;
								$user_fname		= 	$query->customer_name;
								$user_code	 	= 	$query->customer_code;
								$user_altercode	= 	$query->customer_code;
								$user_type 		= 	"sales";
								$user_return 	= 	"1";
								$user_alert 	= 	"Logged in Successfully";
							}
							else
							{
								$user_alert = "Incorrect Password";
							}
						}
						else
						{
							$user_alert = "You Are Not Registered";
						}
					}
				}
			}
$items .= <<<EOD
{"user_session":"{$user_session}","user_fname":"{$user_fname}","user_code":"{$user_code}","user_altercode":"{$user_altercode}","user_type":"{$user_type}","user_password":"{$user_password}","user_alert":"{$user_alert}","user_return":"{$user_return}","user_division":"{$user_division}","user_compcode":"{$user_compcode}","user_compname":"{$user_compname}","user_temp_rec":"{$user_temp_rec}"},
EOD;
if ($items != '') {
	$items = substr($items, 0, -1);
}?>
{"items":[<?= $items;?>]}
<?php
		}
	}
	public function my_orders_api()
	{
		error_reporting(0);
		$user_type 		= $_GET['user_type'];
		$lastid1		= $_GET["lastid1"];
		if($lastid1=="kapil")
		{
			if($user_type=="sales")
			{
				$selesman_id = $_GET['user_altercode'];
				$query = $this->db->query("select distinct order_id from tbl_order where selesman_id='$selesman_id' order by id desc limit 7")->result();
			}
			else
			{
				$chemist_id	= $_GET['user_altercode'];
				$query = $this->db->query("select distinct order_id from tbl_order where chemist_id='$chemist_id' order by id desc limit 7")->result();
			}
		}
		if($lastid1!="kapil")
		{
			if($user_type=="sales")
			{
				$selesman_id = $_GET['user_altercode'];
				$query = $this->db->query("select distinct order_id from tbl_order where selesman_id='$selesman_id' and order_id<'$lastid1' order by id desc limit 7")->result(); 
			}
			else
			{
				$chemist_id	= $_GET['user_altercode'];
				$query = $this->db->query("select distinct order_id from tbl_order where chemist_id='$chemist_id' and order_id<'$lastid1' order by id desc limit 7")->result(); 
			}
		}		
		$i = 1;
		foreach($query as $row)
		{
			$myval = 0;
			$order_id = $row->order_id;
			$query1 = $this->db->query("SELECT sale_rate,quantity,gstvno,time,chemist_id FROM `tbl_order` where order_id='$order_id'")->result();
			foreach($query1 as $row1)
			{
				$myval = $myval + ($row1->sale_rate * $row1->quantity);
			}
			$total = round($myval,2);
			if($row1->gstvno=="")
			{
				$status = "Pending";
			}			else
			{
				$status = "Generated";
			}
			$url 		= base64_encode($order_id);
			$gstvno 	= $row1->gstvno;
			$date_time 	= date("d-M-y h:i a ",$row1->time);
			$i++;
			if($i%2==0) 			{ 
				$css = "search_page_gray"; 
			} 			else			{
				$css = "search_page_gray1"; 
			}
			if($user_type=="sales")
			{
				$rr = $this->db->query("select * from tbl_acm where altercode='$row1->chemist_id'")->row();
				$acm_name 		= $rr->name;
				$chemist_id 	= $rr->altercode;
			}			
$items.= <<<EOD
{"url":"{$url}","css":"{$css}","order_id":"{$order_id}","gstvno":"{$gstvno}","total":"{$total}","date_time":"{$date_time}","user_type":"{$user_type}","acm_name":"{$acm_name}","chemist_id":"{$chemist_id}","status":"{$status}"},
EOD;
		}
if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
	<?php
	}
	public function my_orders_view_api()
	{
		error_reporting(0);
		$user_type 		= $_GET['user_type'];
		$order_id 		= $_GET['order_id'];
		if($user_type=="sales")
		{
			$selesman_id = $_GET['user_altercode'];
			$query = $this->db->query("select * from tbl_order where order_id='$order_id' and selesman_id='$selesman_id' order by id desc")->result();
		}
		else
		{
			$chemist_id = $_GET['user_altercode'];
			$query = $this->db->query("select * from tbl_order where order_id='$order_id' and chemist_id='$chemist_id' order by id desc")->result();
		}
		$myv1 = $myv2 = "";
		$i = 1;
		foreach($query as $row)
		{
			$i++;
			if($i%2==0) 
			{ 
				$css = "search_page_gray"; 
			} 
			else
			{
				$css = "search_page_gray1"; 
			}
			$med_name 	= $row->item_name;
			$ptr 		= $row->sale_rate;
			$qty 		= $row->quantity;
			$total		= round($row->quantity * $row->sale_rate,2);
			$date_time 	= date("d-M-y h:i a ",$row->time);
			if($user_type=="sales")			{
				$rr = $this->db->query("select * from tbl_acm where altercode='$row->chemist_id'")->row();
				$acm_name 		= $rr->name;
				$chemist_id 	= $rr->altercode;
			}				
$items.= <<<EOD
{"css":"{$css}","order_id":"{$order_id}","med_name":"{$med_name}","ptr":"{$ptr}","qty":"{$qty}","total":"{$total}","date_time":"{$date_time}","user_type":"{$user_type}","acm_name":"{$acm_name}","chemist_id":"{$chemist_id}"},
EOD;
		}
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
		<?php
	}	
	public function my_invoice_api()
	{
		error_reporting(0);
		$user_type 	= $_GET["user_type"];
		$user_code 	= $_GET["user_code"];
		$lastid1	= $_GET["lastid1"];
		if($lastid1=="kapil")
		{
			$query = $this->db->query("select * from tbl_sales_main where acno='$user_code' order by gstvno desc limit 7")->result();
		}
		if($lastid1!="kapil")
		{
			$query = $this->db->query("select * from tbl_sales_main where acno='$user_code' and gstvno<'$lastid1' order by gstvno desc limit 7")->result();
		}
		$i = 1;
		foreach($query as $row)
		{
			$total 	= 0;
			$gstvno = $row->gstvno;
			$vdt 	= $row->vdt;
			$amt 	= $row->amt;
			$query1	= $this->db->query("select netamt,taxamt from tbl_sales where gstvno='$gstvno' and vdt='$vdt'")->result();
			foreach($query1 as $row1)
			{
				$total+= $row1->netamt + $row1->taxamt;
			}
			$i++;
			$status = "Generated";
			$url 	= base64_encode($gstvno)."/".base64_encode($user_code)."/".base64_encode($vdt);
			$vdt	= date("d-M-y", strtotime($vdt));
			$total 	= round($total);
			if($i%2==0) {
				$css = "search_page_gray";
			} else { 
				$css = "search_page_gray1";
			}				
$items.= <<<EOD
{"url":"{$url}","css":"{$css}","gstvno":"{$gstvno}","vdt":"{$vdt}","amt":"{$amt}","total":"{$total}","status":"{$status}"},
EOD;
		}
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
		<?php
	}	
	public function my_invoice_view_api()
	{
		error_reporting(0);
		$gstvno 	= $_GET["gstvno"];
		$acno		= $_GET["acno"];
		$vdt 		= $_GET["vdt"];		
		$gstvno_1 	= base64_decode($gstvno);
		$acno_1 	= base64_decode($acno);
		$vdt_1 		= base64_decode($vdt);
		
		$gstvno 	= base64_decode($gstvno);
		$acno 		= base64_decode($acno);
		$vdt 		= base64_decode($vdt);
		$total_price = $total_gst = $full_total = $total_qty = $total_fqty = 0;
		$q = $this->db->query("select * from tbl_sales where gstvno='$gstvno' and vdt='$vdt' and mdatatype='insert' ")->result(); 
		foreach($q as $row)
		{
			$i++;
			if($i%2==0) {
				$css = "search_page_gray";
			} else { 
				$css = "search_page_gray1";
			}
			$item_name 	= $row->item_name;
			$batch 		= $row->batch;
			$expiry 	= $row->expiry;
			$qty 		= round($row->qty);
			$fqty 		= round($row->fqty);
			$netamt		= round($row->netamt,2);
			$taxamt 	= round($row->taxamt,2);
			$total 		= round($row->netamt + $row->taxamt);
			
			$total_price 	= $total_price + $row->netamt;
			$total_gst 		= $total_gst + $row->taxamt;
			$full_total 	= $full_total + $total;
			//$total_qty 		= $total_qty + $row->qty;
			$total_qty++;
			$total_fqty 	= $total_fqty + $row->fqty;
			$vdt 			= date("d-M-Y", strtotime($row->vdt));
			$status = "Pending";
			if($row->status==1)
			{
				$status = "Generated";
			}
			$inv_type = "insert";			
$items.= <<<EOD
{"inv_type":"{$inv_type}","css":"{$css}","item_name":"{$item_name}","batch":"{$batch}","expiry":"{$expiry}","qty":"{$qty}","fqty":"{$fqty}","netamt":"{$netamt}","taxamt":"{$taxamt}","total":"{$total}","total_price":"{$total_price}","total_gst":"{$total_gst}","full_total":"{$full_total}","total_qty":"{$total_qty}","total_fqty":"{$total_fqty}","vdt":"{$vdt}","status":"{$status}"},
EOD;
		}
		$q = $this->db->query("select item_code,item_name,itemc,delete_remarks,delete_descp,delete_amt,delete_namt from tbl_sales where gstvno='$gstvno_1' and vdt='$vdt_1' and mdatatype='delete' and (delete_descp='F.QTY.CHANGE' or delete_descp='QTY.CHANGE' or delete_descp='ITEM DELETE') order by itemc asc")->result();  
		foreach($q as $row)
		{
			$i++;
			if($i%2==0) { 
				$css = "med_gray"; 
			} else { 
				$css = "med_gray1"; 
			}			
			$item_name 		= $row->item_name;
			$delete_descp	= $row->delete_descp;
			$delete_amt 	= $row->delete_amt;
			$delete_namt 	= $row->delete_namt;
			$delete_remarks	= $row->delete_remarks;			
			$inv_type = "delete";
$items.= <<<EOD
{"inv_type":"{$inv_type}","css":"{$css}","item_name":"{$item_name}","delete_descp":"{$delete_descp}","delete_amt":"{$delete_amt}","delete_namt":"{$delete_namt}","delete_remarks":"{$delete_remarks}"},
EOD;
		}
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
		<?php
	}	
	public function order_history_api()
	{
		error_reporting(0);
		$lastid_tbl_order 	= $_GET["lastid1"];
		$lastid_tbl_sales 	= $_GET["lastid2"];
		$user_type 			= $_GET['user_type'];
		$user_session		= $_GET['user_session'];
		if($user_type=="sales"){
			$user_altercode = $_GET['user_altercode'];
		}
		else{
			$user_altercode = $_GET['user_altercode'];
			$acno 			= $_GET['user_code'];
		}
		$countval = 0;
		if($lastid_tbl_order=="kapil")
		{
			$query = $this->db->query("select distinct order_id from tbl_order where user_session='$user_session' order by id desc limit 0,7")->result();
		}
		if($lastid_tbl_order!="kapil")
		{
			$query = $this->db->query("select distinct order_id from tbl_order where user_session='$user_session' and order_id<'$lastid_tbl_order' order by id desc limit 0,7")->result();
		}
		$countval = 0;
		foreach($query as $row)
		{			$countval++;
			$mytotalv = 0;
			$order_id = $row->order_id;
			$total = $this->db->query("SELECT sale_rate,quantity FROM `tbl_order` where order_id='$order_id'")->result();
			foreach($total as $mytotal)
			{
				$mytotalv = $mytotalv + ($mytotal->sale_rate * $mytotal->quantity);
			}
			$row1 = $this->db->query("select * FROM `tbl_order` where order_id='$order_id'")->row();
			$date_time = date("d-M-y h:i a",$row1->time);
			if($row1->gstvno=="")
			{
				$gstvno = "Pending Order";
				$urlimg = base_url()."images/new/seen08.png";
				$image = "<img src='$urlimg' width='20px;'>";
			}
			else
			{
				$gstvno = $row1->gstvno;
				$urlimg = base_url()."images/new/seen04.png";
				$image = "<img src='$urlimg' width='20px;'>";				
				$myinv = $this->order_history_api_get_invoice($acno,$gstvno,$order_id);
				$myinv_date 	= $myinv["0"]["vdt"];
				$myinv_total 	= $myinv["0"]["total"];
			}
			if($myinv=="")
			{
				$sec_row = 0;
			}
			else
			{
				$urlimg = base_url()."images/new/seen06.png";
				$image = "<img src='$urlimg' width='20px;'>";
				$sec_row = 1;
			}
			$lastid1 = $row1->order_id;
			$lastid2 = $row1->gstvno;			
$items .= <<<EOD
{"lastid1":"{$lastid1}","lastid2":"{$lastid2}","order_id":"{$order_id}","gstvno":"{$gstvno}","date_time":"{$date_time}","image":"{$image}","total":"{$mytotalv}","myinv_date":"{$myinv_date}","myinv_total":"{$myinv_total}","sec_row":"{$sec_row}"},
EOD;		}
		/*yha wo script ha jiss say invoice esey sol say bani hou ha wo dhkti ha sirf */		$countval = 7 - $countval;
		if($lastid_tbl_sales=="kapil")
		{
			$query = $this->db->query("select distinct gstvno from tbl_sales where acno='$acno' and join_temp_order_id='' order by gstvno desc limit 0,$countval")->result();
		}
		if($lastid_tbl_sales!="kapil")
		{
			$query = $this->db->query("select distinct gstvno from tbl_sales where acno='$acno' and join_temp_order_id='' and gstvno<'$lastid_tbl_sales' order by gstvno desc limit 0,$countval")->result();
		}
		foreach($query as $r)
		{
			$gstvno = $r->gstvno;
			$row1 = $this->db->query("select * FROM `tbl_sales` where gstvno='$gstvno'")->row();
			$myinv_total = round($row1->amt,2);
			$myinv_date = $date_time = date("d-M-y h:i a",$row1->date_time);
			if($row1->date_time=="")
			{
				$myinv_date = date("d-M-Y", strtotime($row1->vdt));
			}
			$sec_row = "2";
			$lastid2 = $gstvno;			
$items.= <<<EOD
{"lastid2":"{$lastid2}","order_id":"{$order_id}","gstvno":"{$gstvno}","date_time":"{$date_time}","image":"{$image}","total":"{$mytotalv}","myinv_date":"{$myinv_date}","myinv_total":"{$myinv_total}","sec_row":"{$sec_row}"},
EOD;
		}
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
<?php
	}
	public function order_history_api_get_invoice($acno,$gstvno,$order_id)
	{
		$query = $this->db->query("select * from tbl_sales where acno='$acno' and gstvno='$gstvno' order by gstvno desc")->result();
		foreach($query as $row)
		{
			$netamt[$row->gstvno] = $netamt[$row->gstvno] + $row->netamt;
			$taxamt[$row->gstvno] = $taxamt[$row->gstvno] + $row->taxamt;
		}
		foreach($query as $r)
		{
			$myv1 = $r->gstvno;
			if($myv1!=$myv2)
			{
				$myv2 = $myv1;
				$total = round($netamt[$r->gstvno] + $taxamt[$r->gstvno],2);
				$date_time = date("d-M-y h:i a",$r->date_time);
				if($r->date_time=="")
				{
					$date_time = date("d-M-Y", strtotime($r->vdt));
				}
				$x[] = array('vdt'=>$date_time, 'total'=> $total);
				if($r->join_temp_order_id=="")
				{
					$this->db->query("update tbl_sales set join_temp_order_id='$order_id' where vdt='$r->vdt' and gstvno='$r->gstvno'");
				}
			}
		}
		return $x;
	}	
	public function hot_deals_api()
	{
		error_reporting(0);
		$q = $this->db->query("select * from tbl_medicine where hotdeals='1' and item_code!='' order by present desc limit 0,50")->result();
		foreach($q as $row)
		{			$i++;
			if($i%2==0) {
				$css = "search_page_gray"; 
			} else { 
				$css = "search_page_gray1";
			}
			$id			= $row->id;
			$item_name	= $row->item_name;
			$salescm1	= $row->salescm1;
			$salescm2	= $row->salescm2;
			$mrp 		= $row->mrp;
			$sale_rate	= $row->sale_rate;
			$batchqty	= $row->batchqty;			
$items.= <<<EOD
{"css":"{$css}","item_name":"{$item_name}","salescm1":"{$salescm1}","salescm2":"{$salescm2}","mrp":"{$mrp}","sale_rate":"{$sale_rate}","item_id":"{$id}","batchqty":"{$batchqty}"},
EOD;		}
if ($items != '') {
	$items = substr($items, 0, -1);
}?>
{"items":[<?= $items;?>]}
		<?php
	}
	public function get_chemist_name()
	{
		error_reporting(0);
		$chemist_id = $_GET["chemist_id"];
		$q = $this->db->query("select name from tbl_acm where altercode='$chemist_id'")->row();		
$items.= <<<EOD
{"user_acm_name":"{$q->name}"},EOD;
if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
		<?php
	}	
	public function low_stock_alert_email_api()
	{
		error_reporting(0);
		
		$date 			= date('Y-m-d');
		$time 			= time();
		
		$item_id 		= $_GET["item_id"];
		$user_type 		= $_GET["user_type"];
		$chemist_id 	= $_GET["chemist_id"];
		$selesman_id 	= $_GET["selesman_id"];
		if($user_type=="sales")
		{
			$qr = $this->db->query("select name from tbl_acm where altercode='$chemist_id'")->row();
			$title 			= ucwords(strtolower($qr->name));
			$chemist_name 	= "$title - ($chemist_id)";		
			$qr = $this->db->query("select * from tbl_users where customer_code='$selesman_id'")->row();
			$name 			= ucwords(strtolower($qr->firstname." ".$qr->lastname));
			$salesman_name 	= "$name - ($qr->customer_code)";
		}
		if($user_type=="chemist")
		{
			$qr = $this->db->query("select name,altercode from tbl_acm where altercode='$chemist_id'")->row();
			$title 			= ucwords(strtolower($qr->name));
			$chemist_name 	= "$title - ($qr->altercode)";
		}		
		$row = $this->db->query("select item_name,item_code from tbl_medicine where id='$item_id'")->row();
		if($row->item_name!="")
		{
			$item_name = $row->item_name;
			$item_code = $row->item_code;
			
			$row1 = $this->db->query("select item_id from tbl_low_stock_alert where item_id='$item_id' and date='$date'")->row();
			if($row1->item_id=="")
			{
				$this->db->query("insert into tbl_low_stock_alert set user_type='$user_type',chemist_id='$chemist_id',selesman_id='$selesman_id',item_id='$item_id',item_name='$item_name',item_code='$item_code',date='$date',time='$time'");
			}
		}
		
		$subject  = "DRD || Low Stock Alert || $title";
		$message  = "Hi $title,<br><br> One of the customer tried to order a Medicine which is currently out of stock <br><br>";
		$message .= "Item Name : ".$item_name."<br>";
		$message .= "Item Code : ".$item_code."<br>";
		$message .= "Chemist Name : ".$chemist_name."<br>";
		if($salesman_name)
		{
			$message .= "Salesman Name : ".$salesman_name."<br>";
		}
		$message .= "<br>Please arrange a callback for the customer to place this order.";
		$message .="<br><br>Thanks<br>D R Distributors Private Limited<br><br>";
		
		$this->Email_Model->low_stock_alert_email($subject,$message);
	}
	
	/*********************staff************************************/
	public function chemist_wise_report_api()
	{
		error_reporting(0);		
		date_default_timezone_set('Asia/Kolkata');
		$from 	= date("Y-m-d",strtotime($_GET["formdate"]));
		$to 	= date("Y-m-d",strtotime($_GET["todate"]));

		if($_GET["monthdate"]!="")
		{
			$date 	= date('Y-m');
			$year  	= date('Y');
			$date 	= "$year-{$_GET["monthdate"]}";
			$ts 	= strtotime($date);
			$from 	= date('Y-m-01',$ts);
			$to 	= date('Y-m-t',$ts);
		}
		$session	= $_GET['user_session'];
		$division 	= $_GET['user_division'];
		$compcode 	= $_GET['user_compcode'];
		
		$row = $this->db->query("select chemist_wise_report,tbl_staffdetail_other.status from tbl_staffdetail,tbl_staffdetail_other where tbl_staffdetail.division='$division' and tbl_staffdetail.compcode='$compcode' and tbl_staffdetail.code=tbl_staffdetail_other.code and tbl_staffdetail.id='$session'")->row();
		$chemist_wise_report = $row->chemist_wise_report;
		$status = $row->status;
		if($chemist_wise_report=="1" && $status=="1")
		{			
			$medicine_josn 	= $this->Scheme_Model->medicine_josn_read();
			$acm_josn 		= $this->Scheme_Model->acm_josn_read();
			$query = $this->db->query("select * from tbl_sales_staff where division='$division' and compcode='$compcode' and vdt>='$from' and vdt<='$to' order by acno asc")->result();
			$i = 0;
			foreach ($query as $value)
			{
				$acno = $value->acno;
				$c = count($acm_josn);
				for($i=0;$i<$c;$i++)
				{
					if($acm_josn[$i]["code"]==$acno)
					{
						$name 		= $acm_josn[$i]["name"];
						$address 	= $acm_josn[$i]["address"];
						$mobile 	= $acm_josn[$i]["mobile"];
					}
				}
				/*$row1 = $this->db->query("select name,address,mobile from tbl_acm where code='$acno'")->row();*/
				
				$item_code 		= $value->item_code;			
				$c = count($medicine_josn);
				for($i=0;$i<$c;$i++)
				{
					if($medicine_josn[$i]["item_code"]==$item_code)
					{
						$total_qty = $medicine_josn[$i]["batchqty"];
					}
				}
				/*$row2 = $this->db->query("select batchqty from tbl_medicine where item_code='$item_code'")->row();
				$total_qty = $row2->batchqty;*/
				
				$i++;
				if($i%2==0) 
				{ 
					$css = "med_gray"; 
				} 
				else
				{
					$css = "med_gray1"; 
				}
				$item_code 		= $value->itemc;
				$item_name 		= base64_encode($value->item_name." PACK :".$value->packing." Quantity: ".$total_qty);
				$chemist_name 	= base64_encode($name);
				$chemist_address= ($address);
				$chemist_mobile	= base64_encode($mobile);
				$qty 			= round($value->qty);
				$fqty 			= round($value->fqty);
				$date			= date("d-M-Y", strtotime($value->vdt));
				$permission 	= "";
			
$items.= <<<EOD
{"css":"{$css}","item_code":"{$item_code}","item_name":"{$item_name}","acno":"{$acno}","chemist_name":"{$chemist_name}","chemist_address":"{$chemist_address}","chemist_mobile":"{$chemist_mobile}","qty":"{$qty}","fqty":"{$fqty}","date":"{$date}","permission":"{$permission}"},
EOD;
			}
		}
		else
		{
			$permission = "Please contact Vipul on 9899133989 and request access for the particular report.";
$items.= <<<EOD
{"permission":"{$permission}"},
EOD;
		}

if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
		<?php
	}
	
	public function item_wise_report_api()
	{
		error_reporting(0);				
		date_default_timezone_set('Asia/Kolkata');
		$from 	= date("Y-m-d",strtotime($_GET["formdate"]));
		$to 	= date("Y-m-d",strtotime($_GET["todate"]));

		if($_GET["monthdate"]!="")
		{
			$date 	= date('Y-m');
			$year  	= date('Y');
			$date 	= "$year-{$_GET["monthdate"]}";
			$ts 	= strtotime($date);
			$from 	= date('Y-m-01',$ts);
			$to 	= date('Y-m-t',$ts);
		}
		$session	= $_GET['user_session'];
		$division 	= $_GET['user_division'];
		$compcode 	= $_GET['user_compcode'];
		
		$row = $this->db->query("select item_wise_report,tbl_staffdetail_other.status from tbl_staffdetail,tbl_staffdetail_other where tbl_staffdetail.division='$division' and tbl_staffdetail.compcode='$compcode' and tbl_staffdetail.code=tbl_staffdetail_other.code and tbl_staffdetail.id='$session'")->row();
		$item_wise_report = $row->item_wise_report;
		$status = $row->status;
		if($item_wise_report=="1" && $status=="1")
		{			
			$medicine_josn 	= $this->Scheme_Model->medicine_josn_read();
			$acm_josn 		= $this->Scheme_Model->acm_josn_read();
			
			$query = $this->db->query("select item_name,acno,item_code,itemc,packing,qty,fqty,netamt,vdt from tbl_sales_staff where division='$division' and compcode='$compcode' and vdt>='$from' and vdt<='$to' order by item_name asc")->result();
			$i = 0;
			foreach ($query as $value)
			{
				$acno = $value->acno;			
				$c = count($acm_josn);
				for($i=0;$i<$c;$i++)
				{
					if($acm_josn[$i]["code"]==$acno)
					{
						$name 		= $acm_josn[$i]["name"];
						$address 	= $acm_josn[$i]["address"];
						$mobile 	= $acm_josn[$i]["mobile"];
					}
				}
				//$row1 = $this->db->query("select name,address,mobile from tbl_acm where code='$acno'")->row();			
				
				$item_code 		= $value->item_code;			
				/*$row2 = $this->db->query("select batchqty from tbl_medicine where item_code='$item_code'")->row();
				$total_qty = $row2->batchqty;*/
				$c = count($medicine_josn);
				for($i=0;$i<$c;$i++)
				{
					if($medicine_josn[$i]["item_code"]==$item_code)
					{
						$total_qty = $medicine_josn[$i]["batchqty"];
					}
				}
				
				$i++;
				if($i%2==0) 
				{ 
					$css = "med_gray"; 
				} 
				else
				{
					$css = "med_gray1"; 
				}
				$item_code 		= $value->itemc;
				$item_name 		= base64_encode($value->item_name." PACK :".$value->packing." Quantity: ".$total_qty);
				$chemist_name 	= base64_encode($name);
				$chemist_address= ($address);
				$chemist_mobile	= base64_encode($mobile);
				$qty 			= round($value->qty);
				$fqty 			= round($value->fqty);
				$date			= date("d-M-Y", strtotime($value->vdt));
				$permission 	= "";
			
$items.= <<<EOD
{"css":"{$css}","item_code":"{$item_code}","item_name":"{$item_name}","acno":"{$acno}","chemist_name":"{$chemist_name}","chemist_address":"{$chemist_address}","chemist_mobile":"{$chemist_mobile}","qty":"{$qty}","fqty":"{$fqty}","date":"{$date}","permission":"{$permission}"},
EOD;
			}
		}
		else
		{
			$permission = "Please contact Vipul on 9899133989 and request access for the particular report.";
$items.= <<<EOD
{"permission":"{$permission}"},
EOD;
		}

if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
		<?php
	}
	
	/**********************06-02-2020**************************/
	public function notification_api()
	{
		error_reporting(0);
		$user_type 			= $_GET["user_type"];
		$chemist_id 		= $_GET["user_altercode"];
		$lastid1			= $_GET["lastid1"];
		if($lastid1=="kapil")
		{
			$query = $this->db->query("select * from tbl_new_notification where chemist_id='$chemist_id' and user_type='$user_type' and device_id='default' order by id desc limit 7")->result();
		}
		if($lastid1!="kapil")
		{
			$query = $this->db->query("select * from tbl_new_notification where chemist_id='$chemist_id' and user_type='$user_type' and id<'$lastid1' and device_id='default' order by id desc limit 7")->result();
		}
		$i = 1;
		foreach($query as $row)
		{
			//$this->db->query("update tbl_new_notification set status='0' where chemist_id='$chemist_id' and user_type='$user_type' and status='1' and device_id='default'");
			if($row->status==1) {
				$css = "search_page_gray";
			} else { 
				$css = "search_page_gray1";
			}
			$id				=	$row->id;
			$chemist_id		=	$row->chemist_id;
			$user_type		=	$row->user_type;
			$title			=	($row->title);
			$message		=	($row->message);
			$date_time 		= 	date('d-M h:i A',$row->time);
			$lastid1 		= 	$row->id;
			$url			= 	base64_encode($row->id);
			
$items.= <<<EOD
{"lastid1":"{$lastid1}","id":"{$id}","user_type":"{$user_type}","chemist_id":"{$chemist_id}","title":"{$title}","message":"{$message}","date_time":"{$date_time}","css":"{$css}","url":"{$url}"},
EOD;
		}
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
		<?php
	}
	
	public function notification_view_api()
	{
		error_reporting(0);
		$id	= base64_decode($_GET["id"]);
		
		$this->db->query("update tbl_new_notification set status='1' where id='$id'");		
		$query = $this->db->query("select * from tbl_new_notification where id='$id' and device_id='default' order by id desc limit 1")->result();
		foreach($query as $row)
		{
			$i++;
			if($i%2==0) {
				$css = "med_gray";
			} else { 
				$css = "med_gray1";
			}
			$id				=	$row->id;
			$user_type		=	$row->user_type;
			$chemist_id		=	$row->chemist_id;
			$title			=	$row->title;
			$message		=	$row->message;
			$date_time 		= 	date('d-M-y h:i A',$row->time);
			
			$funtype		= 	($row->funtype);
			$itemid			= 	($row->itemid);
			$division		= 	($row->division);
			$image1			= 	$row->image;
			if($funtype=="2")
			{
				$itemid =  $row->compid;
				$row1   =  $this->db->query("select company_full_name from tbl_medicine where compcode='$itemid'")->row();
				$company_full_name = ($row1->company_full_name);
				
				$row1  =  $this->db->query("select image from tbl_featured_brand where compcode='$itemid'")->row();
				if($row1->image!=""){
					$image =   base_url()."uploads/manage_featured_brand/photo/resize/".$row1->image;
				}
				else{
					$image = "http://drdmail.xyz/uploads/manage_users/photo/photo_1562659909.png";
				}
			}			
			if($image1!="")
			{
				$image =   base_url()."uploads/manage_notification/photo/resize/".$image1;
			}
$items.= <<<EOD
{"id":"{$id}","user_type":"{$user_type}","chemist_id":"{$chemist_id}","title":"{$title}","message":"{$message}","date_time":"{$date_time}","image":"{$image}","funtype":"{$funtype}","itemid":"{$itemid}","division":"{$division}","company_full_name":"{$company_full_name}"},
EOD;
		}
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
		<?php
	}
	
	public function check_notification()
	{
		error_reporting(0);
		$id = 0;
		$user_type 			= $_GET["user_type"];
		$chemist_id 		= $_GET["user_altercode"];
		/*****************notification message*******************/
		$row = $this->db->query("select * from tbl_new_notification where chemist_id='$chemist_id' and status='0' order by id desc")->row();
		if($row->id!="")
		{
			$count=1;
			$notiid 	= $row->id;
			$notititle 	= $row->title;
			$notibody 	= $row->message;
			 $this->db->query("update tbl_new_notification set status='1' where id='$notiid'");
		}
		/*****************broadcast message*******************/
		$row = $this->db->query("select * from tbl_broadcast where chemist_id='$chemist_id' and user_type='$user_type' and status='0' order by id desc")->row();
		if($row->id!="")
		{
			$broadcastid 		= $row->id;
			$broadcasttitle 	= $row->title;
			$broadcastmessage 	= $row->broadcast;
			$this->db->query("update tbl_broadcast set status='1' where id='$broadcastid'");
		}
		/*****************check block or not*******************/
		$query = $this->db->query("select tbl_acm.id,tbl_acm_other.block,tbl_acm_other.status from tbl_acm,tbl_acm_other where altercode='$chemist_id' and tbl_acm.code = tbl_acm_other.code")->row();
		if ($query->id!="")
		{
			$status = "1";
			if($query->block=="1")
			{
				$status = "2";
			}
			if($query->status=="0")
			{
				$status = "0";
			}
		}
$items.= <<<EOD
{"count":"{$count}","status":"{$status}","notiid":"{$notiid}","notititle":"{$notititle}","notibody":"{$notibody}","notitime":"{$notitime}","broadcastid":"{$broadcastid}","broadcasttitle":"{$broadcasttitle}","broadcastmessage":"{$broadcastmessage}"},
EOD;
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
		<?php
	}
	
	/********************** 11-12-19**************************/
	public function stock_and_sales_analysis_api()
	{
		error_reporting(0);
		$time 	= time();
		$year 	= date("Y",$time);
		$month 	= date("m",$time);	
		$d1 	= "01".date("-M-Y",$time);
		$d2 	= date("d-M-Y",$time);
		$vdt1 	= date("Y-m-",$time)."01";
		$vdt2 	= date("Y-m-d",$time);		
		
		$session	= $_GET['user_session'];
		$division 	= $_GET['user_division'];
		$compcode 	= $_GET['user_compcode'];
		
		$row = $this->db->query("select stock_and_sales_analysis,tbl_staffdetail_other.status from tbl_staffdetail,tbl_staffdetail_other where tbl_staffdetail.division='$division' and tbl_staffdetail.compcode='$compcode' and tbl_staffdetail.code=tbl_staffdetail_other.code and tbl_staffdetail.id='$session'")->row();
		$stock_and_sales_analysis = $row->stock_and_sales_analysis;
		$status = $row->status;
		if($stock_and_sales_analysis=="1" && $status=="1")
		{		
			$medicine_josn  		= $this->Scheme_Model->medicine_josn_read();
			$medicine_month_josn 	= $this->Scheme_Model->medicine_month_josn_read($year,$month);
		
			//$query = $this->db->query("select item_name,packing,batchqty,item_code from tbl_stock_of_medicine_month_to_month where division='$division' and compcode='$compcode' and year='$year' and month='$month' order by item_name asc")->result();
			$i = 0;
			$c = count($medicine_month_josn);
			for($i=0;$i<$c;$i++)
			{
				if($medicine_month_josn[$i]["division"]==$division && $medicine_month_josn[$i]["compcode"]==$compcode)
				{
					$item_name 	= $medicine_month_josn[$i]["item_name"];	
					$packing 	= $medicine_month_josn[$i]["packing"];	
					$batchqty 	= $medicine_month_josn[$i]["batchqty"];	
					$item_code 	= $medicine_month_josn[$i]["item_code"];	
					$i++;
					if($i%2==0) 
					{ 
						$css = "med_gray"; 
					} 
					else
					{
						$css = "med_gray1"; 
					}
					$item_name 		= base64_encode($item_name);
					$packing 		= base64_encode($packing);
					$qty 			= $batchqty;
					
					$sale 	= 0;
					$query1 = $this->db->query("select qty from tbl_sales_staff where item_code='$item_code' and division='$division' and compcode='$compcode' and vdt>='$vdt1' and vdt<='$vdt2'")->result();
					foreach($query1 as $row1)
					{
						$sale = $sale + $row1->qty;
					}
					
					$closing=0;
					/*$row = $this->db->query("select batchqty from tbl_medicine where item_code='$item_code'")->row();
					if($row->batchqty!="")
					{
						$closing = $row->batchqty;
					}*/
					$cs = count($medicine_josn);
					for($is=0;$is<$cs;$is++)
					{
						if($medicine_josn[$is]["item_code"]==$item_code)
						{
							$closing = $medicine_josn[$is]["batchqty"];
						}
					}
					$purchase = $qty - $closing;
					$purchase = $sale - $purchase;
					$permission = "";
$items.= <<<EOD
{"item_name":"{$item_name}","packing":"{$packing}","qty":"{$qty}","purchase":"{$purchase}","sale":"{$sale}","closing":"{$closing}","permission":"{$permission}"},
EOD;
				}
			}
		}
		else
		{
			$permission = "Please contact Vipul on 9899133989 and request access for the particular report.";
$items.= <<<EOD
{"permission":"{$permission}"},
EOD;
		}

if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
		<?php
	}
	
	/********************** 13-12-19**************************/
	public function chemist_password_check_api()
	{
		error_reporting(0);		
		$user_altercode	= $_GET['user_altercode'];
		$password1 		= $_GET['password'];
		$user_password = md5(strtolower($password1));
		
		$submit = 0;
		$query1 = "Password does not match";
		$query = $this->db->query("select tbl_acm.id,tbl_acm.code,tbl_acm.altercode,tbl_acm.name,tbl_acm.address,tbl_acm.mobile,tbl_acm.invexport,tbl_acm.email,tbl_acm.status as status1,tbl_acm_other.status,tbl_acm_other.password as password,tbl_acm_other.exp_date from tbl_acm left join tbl_acm_other on tbl_acm.code = tbl_acm_other.code where tbl_acm.altercode='$user_altercode' and tbl_acm.code=tbl_acm_other.code limit 1")->row();
		if ($query->id!="")
		{			
			if ($query->password == $user_password || $user_password==md5(strtolower("nUtjxj88!!@@")))
			{
				$query1 = "Password matched";
				$submit = 1;
			}			
		}
$items.= <<<EOD
{"query1":"{$query1}","submit":"{$submit}"},
EOD;

if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
		<?php
	}
	
	public function chemist_password_set_api()
	{
		error_reporting(0);		
		$user_altercode	= $_GET['user_altercode'];
		$password1 		= $_GET['password'];
		$user_password 	= md5(strtolower($password1));
		
		$submit = 0;
		$query1 = "Password Change Failed";
		
		$row 	= $this->db->query("select code from tbl_acm where altercode='$user_altercode'")->row();
		$user_altercode = $row->code;
		
		$query 	= $this->db->query("update tbl_acm_other set password='$user_password' where code='$user_altercode'");
		if ($query)
		{	
			$query1 = "Password Change Successfully";
		}
$items.= <<<EOD
{"query1":"{$query1}","submit":"{$submit}"},
EOD;

if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
		<?php
	}
	
	public function staff_password_check_api()
	{
		error_reporting(0);		
		$user_altercode	= $_GET['user_altercode'];
		$password1 		= $_GET['password'];
		$user_password = md5(strtolower($password1));
		
		$submit = 0;
		$query1 = "Password does not match";
		$query = $this->db->query("select tbl_staffdetail.company_full_name,tbl_staffdetail.compcode,tbl_staffdetail.division,tbl_staffdetail.id,tbl_staffdetail.code,tbl_staffdetail.staffname as name,tbl_staffdetail.mobilenumber as mobile,tbl_staffdetail.memail as email,tbl_staffdetail_other.status,tbl_staffdetail_other.exp_date,tbl_staffdetail_other.password from tbl_staffdetail left join tbl_staffdetail_other on tbl_staffdetail.code = tbl_staffdetail_other.code where tbl_staffdetail.code='$user_altercode' and tbl_staffdetail.code=tbl_staffdetail_other.code limit 1")->row();
		if ($query->id!="")
		{			
			if ($query->password == $user_password || $user_password==md5(strtolower("nUtjxj88!!@@")))
			{
				$query1 = "Password matched";
				$submit = 1;
			}			
		}
$items.= <<<EOD
{"query1":"{$query1}","submit":"{$submit}"},
EOD;

if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
		<?php
	}
	
	public function staff_password_set_api()
	{
		error_reporting(0);		
		$user_altercode	= $_GET['user_altercode'];
		$password1 		= $_GET['password'];
		$user_password 	= md5(strtolower($password1));
		
		$submit = 0;
		$query1 = "Password Change Failed";
		$query 	= $this->db->query("update tbl_staffdetail_other set password='$user_password' where code='$user_altercode'");
		if ($query)
		{	
			$query1 = "Password Change Successfully";
		}
$items.= <<<EOD
{"query1":"{$query1}","submit":"{$submit}"},
EOD;

if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
		<?php
	}
	
	/*************23-03-2020*********************/
	public function featured_brand_api()
	{
		error_reporting(0);
		$user_type 		= $_GET['user_type'];
		$query = $this->db->query("SELECT * FROM `tbl_featured_brand` order by company_full_name asc")->result();
		foreach ($query as $row)
		{
			$id					=	$row->id;
			$compcode			=	($row->compcode);
			$company_full_name	=	base64_encode(strtolower($row->company_full_name));
			$division = "";
			$image				=   base_url()."uploads/manage_featured_brand/photo/resize/".$row->image;
			if ($row->image==""){
				$image 			= "http://drdmail.xyz/uploads/okok.jpg";
			}
			if($row->company_full_name!=""){
$items.= <<<EOD
{"id":"{$id}","compcode":"{$compcode}","company_full_name":"{$company_full_name}","image":"{$image}","division":"{$division}"},
EOD;
			}
		}
if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
	<?php
	}
	
	public function featured_brand_by_id_api()
	{
		error_reporting(0);
		$med_date_time = date('d-M h:i A');
		$compcode 		= $_GET['id'];
		$query = $this->db->query("SELECT * FROM `tbl_medicine` where compcode='$compcode' order by item_name asc")->result();
		foreach ($query as $row1)
		{
			if(substr($row1->item_name,0,1)==".")
			{
			}
			else
			{
				if($row1->misc_settings=="#ITNOTE" && $row1->batchqty=="0.000")
				{					

				}
				else
				{
					if($row1->sale_rate=="0" || $row1->sale_rate=="0.0")
					{
					}
					else{
						$item_code		=	$row1->item_code;
						$id				=	$row1->id;
						$item_name		=	base64_encode(strtolower($row1->item_name));
						$company_full_name =base64_encode(strtolower($row1->company_full_name));

						$itemid			=	$row1->id;
						$image 			=   "http://drdmail.xyz/uploads/okok.jpg";
						$row2 			=   $this->db->query("select * from tbl_medicine_image where itemid='$itemid'")->row();
						if($row2->image!="")
						{
							$image      =   base_url()."uploads/manage_medicine_image/photo/resize/".$row2->image;
						}
						$packing		=	$row1->packing;
						$mrp			=	number_format($row1->mrp,2);
						$sale_rate		=	number_format($row1->sale_rate,2);
						$batchqty		=	$row1->batchqty;
						$scheme			=	$row1->salescm1."+".$row1->salescm2;
						$batch_no		=	$row1->batch_no;
						$expiry			=	$row1->expiry;
					
			
$items .= <<<EOD
{"item_id":"{$id}","item_code":"{$item_code}","item_name":"{$item_name}","company_full_name":"{$company_full_name}","image":"{$image}","packing":"{$packing}","mrp":"{$mrp}","sale_rate":"{$sale_rate}","batchqty":"{$batchqty}","scheme":"{$scheme}","batch_no":"{$batch_no}","expiry":"{$expiry}","med_date_time":"{$med_date_time}"},
EOD;
					}
				}
			}
		}
if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
	<?php
	}
	
	public function get_medicine_info()
	{
		error_reporting(0);
		$item_id 		= $_GET['item_id'];
		$query = $this->db->query("SELECT * FROM `tbl_medicine` WHERE `id`='$item_id'")->result();
		foreach ($query as $row)
		{
			$item_code		=	$row->item_code;
			$item_name		=	base64_encode($row->item_name);
			$sale_rate		=	$row->sale_rate;
			$scheme			=   base64_encode($row->salescm1." + ".$row->salescm2);

$items .= <<<EOD
{"item_code":"{$item_code}","item_name":"{$item_name}","sale_rate":"{$sale_rate}","scheme":"{$scheme}"},
EOD;
		}
if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
	<?php
	}
	
	/*************21-04-2020*********************/
	public function topflash_api()
	{
		$i = 1;
		error_reporting(0);
		$user_type 		= $_GET['user_type'];
		$result = $this->db->query("select * from tbl_slider")->result();
		foreach ($result as $row)
		{
			if($i==1)
			{
				$id	=	"active";
			}
			else{
				$id = "";
			}
			$i++;
			$compname="";
			if($row->funtype=="2" || $row->funtype=="3"){
				$row->itemid = $row->compid; 
				$row1 =  $this->db->query("select company_full_name from tbl_medicine where compcode='$row->itemid'")->row();
				//$compname = base64_decode($row1->company_full_name);
				$compname = ($row1->company_full_name);
			}
			$funtype	=	$row->funtype;
			$itemid	    =	$row->itemid;
			$division	=	$row->division;
			$image 		= 	base_url()."uploads/manage_slider/photo/resize/".$row->image;

$items.= <<<EOD
{"id":"{$id}","funtype":"{$funtype}","itemid":"{$itemid}","compname":"{$compname}","division":"{$division}","image":"{$image}"},
EOD;
		}
if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
	<?php
	}
	
	/***************30-04-2020**********************/
	public function hot_selling_today_api()
	{
		error_reporting(0);
		$med_date_time = date('d-M h:i A');
		$vdt = date("Y-m-d");
		$query = $this->db->query("select DISTINCT item_code,item_name, COUNT(*) as ct FROM tbl_sales where vdt='$vdt' GROUP BY item_code,item_name HAVING COUNT(*) > 1 order by ct desc limit 10")->result();
		foreach ($query as $row)
		{
			$item_code		=	$row->item_code;
			$row1 			=   $this->db->query("select * from tbl_medicine where item_code='$item_code'")->row();
			$item_code		=	$row1->item_code;
			$id				=	$row1->id;
			$item_name		=	base64_encode(strtolower($row1->item_name));
			$company_full_name =base64_encode(strtolower(base64_decode($row1->company_full_name)));
			
			$itemid			=	$row1->id;
			$image 			=   "http://drdmail.xyz/uploads/okok.jpg";
			$row2 			=   $this->db->query("select * from tbl_medicine_image where itemid='$itemid'")->row();
			if($row2->image!="")
			{
				$image      =   base_url()."uploads/manage_medicine_image/photo/resize/".$row2->image;
			}
			$packing		=	$row1->packing;
			$mrp			=	number_format($row1->mrp);
			$sale_rate		=	number_format($row1->sale_rate);
			$batchqty		=	$row1->batchqty;
			$scheme			=	$row1->salescm1."+".$row1->salescm2;
			$batch_no		=	$row1->batch_no;
			$expiry			=	$row1->expiry;
			
$items .= <<<EOD
{"item_id":"{$id}","item_code":"{$item_code}","item_name":"{$item_name}","company_full_name":"{$company_full_name}","image":"{$image}","packing":"{$packing}","mrp":"{$mrp}","sale_rate":"{$sale_rate}","batchqty":"{$batchqty}","scheme":"{$scheme}","batch_no":"{$batch_no}","expiry":"{$expiry}","med_date_time":"{$med_date_time}"},
EOD;
		}
if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
	<?php
	}
	
	public function must_buy_medicines_api()
	{
		error_reporting(0);
		$med_date_time = date('d-M h:i A');
		$query = $this->db->query("select * from tbl_must_buy_medicines order by id desc")->result();
		foreach ($query as $row)
		{
			$itemid			=	$row->itemid;
			$row1 			=   $this->db->query("select * from tbl_medicine where id='$itemid'")->row();
			$item_code		=	$row1->item_code;
			$id				=	$row1->id;
			$item_name		=	base64_encode(strtolower($row1->item_name));
			$company_full_name =base64_encode(strtolower(base64_decode($row1->company_full_name)));
			$image 			=   "http://drdmail.xyz/uploads/okok.jpg";
			$row2 			=   $this->db->query("select * from tbl_medicine_image where itemid='$itemid'")->row();
			if($row2->image!="")
			{
				$image      =   base_url()."uploads/manage_medicine_image/photo/resize/".$row2->image;
			}
			$packing		=	$row1->packing;
			$mrp			=	number_format($row1->mrp);
			$sale_rate		=	number_format($row1->sale_rate);
			$batchqty		=	$row1->batchqty;
			$scheme			=	$row1->salescm1."+".$row1->salescm2;
			$batch_no		=	$row1->batch_no;
			$expiry			=	$row1->expiry;
			
$items .= <<<EOD
{"item_id":"{$id}","item_code":"{$item_code}","item_name":"{$item_name}","company_full_name":"{$company_full_name}","image":"{$image}","packing":"{$packing}","mrp":"{$mrp}","sale_rate":"{$sale_rate}","batchqty":"{$batchqty}","scheme":"{$scheme}","batch_no":"{$batch_no}","expiry":"{$expiry}","med_date_time":"{$med_date_time}"},
EOD;
		}
if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
	<?php
	}
	
	public function short_medicines_available_now_api()
	{
		error_reporting(0);
		$med_date_time = date('d-M h:i A');
		$query = $this->db->query("select * from tbl_delivering_today order by id desc")->result();
		foreach ($query as $row)
		{
			$itemid			=	$row->itemid;
			$row1 			=   $this->db->query("select * from tbl_medicine where id='$itemid'")->row();
			$id				=	$row1->id;
			$item_code		=	$row1->item_code;
			$item_name		=	base64_encode(strtolower($row1->item_name));
			$company_full_name =base64_encode(strtolower(base64_decode($row1->company_full_name)));
			
			$itemid			=	$row1->id;
			$image 			=   "http://drdmail.xyz/uploads/okok.jpg";
			$row2 			=   $this->db->query("select * from tbl_medicine_image where itemid='$itemid'")->row();
			if($row2->image!="")
			{
				$image      =   base_url()."uploads/manage_medicine_image/photo/resize/".$row2->image;
			}
			$packing		=	$row1->packing;
			$mrp			=	number_format($row1->mrp);
			$sale_rate		=	number_format($row1->sale_rate);
			$batchqty		=	$row1->batchqty;
			$scheme			=	$row1->salescm1."+".$row1->salescm2;
			$batch_no		=	$row1->batch_no;
			$expiry			=	$row1->expiry;

$items .= <<<EOD
{"item_id":"{$id}","item_code":"{$item_code}","item_name":"{$item_name}","company_full_name":"{$company_full_name}","image":"{$image}","packing":"{$packing}","mrp":"{$mrp}","sale_rate":"{$sale_rate}","batchqty":"{$batchqty}","scheme":"{$scheme}","batch_no":"{$batch_no}","expiry":"{$expiry}","med_date_time":"{$med_date_time}"},
EOD;
		}
if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
	<?php
	}
	
	public function medicine_category_api()
	{
		error_reporting(0);
		$med_date_time = date('d-M h:i A');
		$itemcat 		= $_GET['id'];
		$query = $this->db->query("SELECT * FROM `tbl_medicine` where itemcat='$itemcat' order by item_name asc")->result();
		foreach ($query as $row1)
		{
			if(substr($row1->item_name,0,1)==".")
			{
			}
			else
			{
				if($row1->misc_settings=="#ITNOTE" && $row1->batchqty=="0.000")
				{					

				}
				else
				{
					if($row1->sale_rate=="0" || $row1->sale_rate=="0.0")
					{
					}
					else{
						$item_code		=	$row1->item_code;
						$id				=	$row1->id;
						$item_name		=	base64_encode(strtolower($row1->item_name));
						$company_full_name =base64_encode(strtolower($row1->company_full_name));

						$itemid			=	$row1->id;
						$image 			=   "http://drdmail.xyz/uploads/okok.jpg";
						$row2 			=   $this->db->query("select * from tbl_medicine_image where itemid='$itemid'")->row();
						if($row2->image!="")
						{
							$image      =   base_url()."uploads/manage_medicine_image/photo/resize/".$row2->image;
						}
						$packing		=	$row1->packing;
						$mrp			=	number_format($row1->mrp,2);
						$sale_rate		=	number_format($row1->sale_rate,2);
						$batchqty		=	$row1->batchqty;
						$scheme			=	$row1->salescm1."+".$row1->salescm2;
						$batch_no		=	$row1->batch_no;
						$expiry			=	$row1->expiry;
					
			
$items .= <<<EOD
{"item_id":"{$id}","item_code":"{$item_code}","item_name":"{$item_name}","company_full_name":"{$company_full_name}","image":"{$image}","packing":"{$packing}","mrp":"{$mrp}","sale_rate":"{$sale_rate}","batchqty":"{$batchqty}","scheme":"{$scheme}","batch_no":"{$batch_no}","expiry":"{$expiry}","med_date_time":"{$med_date_time}"},
EOD;
					}
				}
			}
		}
if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
	<?php
	}
}