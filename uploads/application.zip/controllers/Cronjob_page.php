<?php
defined('BASEPATH') OR exit('No direct script access allowed');
ini_set('memory_limit', '-1');
ini_set('post_max_size', '100M');
ini_set('upload_max_filesize', '100M');
ini_set('max_execution_time', 36000);
require_once APPPATH."/third_party/PHPExcel.php";
class Cronjob_page extends CI_Controller {

	public function create_medicine_json()
	{
		$this->Cronjob_Model->create_medicine_json();
		echo "okok";
	}
	
	public function create_new_json_for_items()
	{
		$this->Cronjob_Model->create_new_json_for_items();
		//$this->create_new_json_for_acm();
		//$this->create_new_json_for_staff();
		//$this->Cronjob_Model->create_new_json_for_items_stock_and_sales_analysis();
	}
	public function create_new_json_for_acm()
	{		$this->Cronjob_Model->create_new_json_for_acm();
	}
	public function create_new_json_for_staff()
	{		$this->Cronjob_Model->create_new_json_for_staff();
	}	
	public function cronjob_insert_order()
	{
		$files = glob("uplaods_order/*.json");
		for($i=0;$i<count($files);$i++)
		{
			$url = base_url().$files[$i];
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_URL, $url);
			$result123 = curl_exec($ch);
			curl_close($ch);
			$this->cronjob_insert_order_fun($result123,$files[$i]);
			die;
		}
	}	
	public function tbl_order_id()
	{
		$q = $this->db->query("select order_id from tbl_order_id where id='1'")->row();
		$order_id = $q->order_id + 1;
		$this->db->query("update tbl_order_id set order_id='$order_id' where id='1'");
		return $order_id;
	}
	
	public function cronjob_insert_order_fun($result123,$file_name)
	{
		error_reporting(0);
		$order_id 	= $this->tbl_order_id();
		$time 	= time();
		$date 	= date('Y-m-d');
		$x = 0;
		$myi = 0;
		$total = $total1 = 0;
		$result123 = json_decode($result123, true);
		foreach($result123 as $ks)
		{			
			$quantity			= ($ks["item_qty"]);
			$item_id			= ($ks["item_id"]);
			//04-01-20
			if($item_id=="")
			{
				unlink($file_name);
				die;
			}
			$slice_type			= ($ks["slice_type"]);
			$slice_item			= ($ks["slice_item"]);
			if($slice_type==1)
			{
				if($total1<$slice_item)	
				{
					$tbl_medicine = $this->db->query("select sale_rate from tbl_medicine where id='$item_id'")->row();
					$sale_rate 	= $tbl_medicine->sale_rate;
					$total1 	= $total1 + ($sale_rate * $quantity);				
				}
			}
		}
		$slice_item_new = $total1;
		foreach($result123 as $ks)
		{
			$user_type 			= ($ks["user_type"]);
			$chemist_id 		= ($ks["chemist_id"]);
			$selesman_id 		= ($ks["selesman_id"]);
			$order_type			= ($ks["order_type"]);
			$filename			= ($ks["filename"]);
			$remarks			= ($ks["remarks"]);			
			$quantity			= ($ks["item_qty"]);
			$item_id			= ($ks["item_id"]);
			$join_temp			= ($ks["join_temp"]);
			
			if($user_type=="sales")
			{
				$temp_rec = $order_id."_".$user_type."_".$chemist_id."_".$selesman_id;
			}
			else
			{
				$temp_rec = $order_id."_".$user_type."_".$chemist_id;
			}
			
			$tbl_medicine = $this->db->query("select item_code,item_name,sale_rate from tbl_medicine where id='$item_id'")->row();
			$item_code = $tbl_medicine->item_code;
			$item_name = $tbl_medicine->item_name;
			$sale_rate = $tbl_medicine->sale_rate;
			$total = $total + ($sale_rate * $quantity);
			
			// kisi karana agar tbl_medicine null ha to 
			if($item_code!="")
			{
				if($slice_type=="")
				{
					// jab koi be slice nahi ho rahi ha to i means direct order
					$x = $this->db->query("insert into tbl_order set temp_rec='$temp_rec',order_id='$order_id',user_type='$user_type',chemist_id='$chemist_id',selesman_id='$selesman_id',order_type='$order_type',filename='$filename',remarks='$remarks',quantity='$quantity',item_code='$item_code',item_name='$item_name',sale_rate='$sale_rate',date='$date',time='$time',join_temp='$join_temp'");
				}
				
				if($slice_type==1)
				{
					// jab koi be slice rahi ha to slice order
					if($total<=$slice_item_new)	
					{
						$x = $this->db->query("insert into tbl_order set temp_rec='$temp_rec',order_id='$order_id',user_type='$user_type',chemist_id='$chemist_id',selesman_id='$selesman_id',order_type='$order_type',filename='$filename',remarks='$remarks',quantity='$quantity',item_code='$item_code',item_name='$item_name',sale_rate='$sale_rate',date='$date',time='$time',join_temp='$join_temp'");
					}
					else
					{
						$y = 1;
						$posts[] = array('join_temp'=>$join_temp,'order_type'=>$order_type,'filename'=>$filename,'user_type'=>$user_type,'chemist_id'=>$chemist_id,'selesman_id'=>$selesman_id,'remarks'=>$remarks,'slice_type'=>$slice_type,'slice_item'=>$slice_item,'item_id'=>$item_id,'item_qty'=>$quantity,);
					}
				}
				if($slice_type==2)
				{
					// jab koi be slice rahi ha to slice order
					if($myi<$slice_item)	
					{
						$x = $this->db->query("insert into tbl_order set temp_rec='$temp_rec',order_id='$order_id',user_type='$user_type',chemist_id='$chemist_id',selesman_id='$selesman_id',order_type='$order_type',filename='$filename',remarks='$remarks',quantity='$quantity',item_code='$item_code',item_name='$item_name',sale_rate='$sale_rate',date='$date',time='$time',join_temp='$join_temp'");
					}
					else
					{
						$y = 1;
						$posts[] = array('join_temp'=>$join_temp,'order_type'=>$order_type,'filename'=>$filename,'user_type'=>$user_type,'chemist_id'=>$chemist_id,'selesman_id'=>$selesman_id,'remarks'=>$remarks,'slice_type'=>$slice_type,'slice_item'=>$slice_item,'item_id'=>$item_id,'item_qty'=>$quantity,);
					}				
					$myi++;
				}
			}
		}
		if($item_code=="")
		{
			unlink($file_name);
		}
		if($y==1)
		{
			$time=time();
			//$response['posts'] = $posts;
			$fp = fopen('uplaods_order/again_order_'.$time.'.json', 'w');
			fwrite($fp, json_encode($posts));
			fclose($fp);
		}
		if($x==1)
		{
			if(is_file($file_name)){
				//Use the unlink function to delete the file.
				unlink($file_name);
				$this->Email_Model->save_order($temp_rec,$order_id);
			}
		}
	}
	
	/***********28-01-2020**************/
	public function chemist_invoice_report()
	{
		error_reporting(0);
		$vdt = date("Y-m-d");
		//$vdt = "2019-08-29";
		$q = $this->db->query("select gstvno,acno,vdt,time,url_link from tbl_sales_main where status='1' and email_status='0' and vdt='$vdt' limit 20")->result();
		foreach($q as $row)
		{
			$this->Email_Model->chemist_invoice_report($row->gstvno,$row->acno,$row->vdt,$row->time,$row->url_link);
		}
	}
	
	public function staff_invoice_whatsapp_messsage()
	{
		error_reporting(0);		
		$this->Email_Model->staff_invoice_whatsapp_messsage();
	}
	
	public function Myexcle_export()
	{
		echo "oks";
		$delimiter = ",";
		$fp = fopen('uploads_medicine_csv/item_list.csv', 'w');
		$fields = array('Company_Name','DIVISION','Item_Code','Item_Name','Packing','Expiry','BatchNo','SaleRate','MRP','SaleScm1','SaleScm2','BATCHQTY','GSTPER','Item_Date','Date','Time');
		fputcsv($fp, $fields, $delimiter);
		$result = $this->db->query("select * from tbl_medicine")->result();
		foreach($result as $row)
		{
			$dt = date("d-M-Y");
			$tt = date("H:i:s");
			$item_date = date("d-M-Y", strtotime($row->item_date));
			$lineData = array("$row->company_name","$row->division","$row->item_code","$row->item_name","$row->packing","$row->expiry","$row->batch_no","$row->sale_rate","$row->mrp","$row->salescm1","$row->salescm2","$row->batchqty","$row->gstper","$item_date","$dt","$tt");
			fputcsv($fp, $lineData, $delimiter);
		}
		fclose($fp);
	}
	
	public function cronjob_fail_order()
	{
		error_reporting(0);
		$result = $this->db->query("select DISTINCT temp_rec from tbl_temp_rec limit 1")->result();
		foreach($result as $row)
		{
			$temp_rec = $row->temp_rec;
			$row1 = $this->db->query("select * from tbl_temp_rec where temp_rec='$temp_rec'")->row();
			
			$user_session 		= $row1->user_session;
			$user_type 			= $row1->user_type;
			$user_altercode 	= $row1->user_altercode;
			$order_type			= $row1->order_type;
			$remarks			= $row1->remarks;
			$chemist_id			= $row1->chemist_id;
			
			$this->Email_Model->save_order($temp_rec,$user_session,$user_type,$user_altercode,$chemist_id,$remarks,$order_type);
		}
	}
	
	/****************delete one month old sales************************/
	public function delete_one_month_sales()
	{
		$time = time();
		//echo $vdt = date("Y-m-d", strtotime("-1 month", $time));
		$vdt = date("Y-m-d", strtotime("-15 days", $time));
		$vdt1 = date("Y-m-d", strtotime("-60 days", $time));
		$vdt2 = date("Y-m-d", strtotime("-1 days", $time));
		$vdt3 = date("Y-m-d", strtotime("-30 days", $time));
		$vdt5 = date("Y-m-d", strtotime("-40 days", $time));
		$vdt4 = date("Y-m-d",$time);
		
		$this->db->query("update tbl_gmail_username_password set emaillimit='0' ,date='$vdt4' where date='$vdt2'");
		
		$this->db->query("DELETE FROM `tbl_deliverby` WHERE vdt<='$vdt2'");
		$this->db->query("DELETE FROM `tbl_sales` WHERE vdt<='$vdt'");
		$this->db->query("DELETE FROM `tbl_sales_main` WHERE vdt<='$vdt'");
		
		$this->db->query("DELETE FROM `tbl_low_stock_alert` WHERE date<='$vdt'");
		$this->db->query("DELETE FROM `tbl_order` WHERE date<='$vdt3'");
		$this->db->query("DELETE FROM `tbl_delete_import` WHERE date<='$vdt3'");
		$this->db->query("DELETE FROM `tbl_new_notification` WHERE date<='$vdt3'");
		$this->db->query("DELETE FROM `tbl_sales_deleted` WHERE vdt<='$vdt5'");
		$this->db->query("DELETE FROM `tbl_sales_staff` WHERE vdt<='$vdt3'");
		$this->db->query("DELETE FROM `tbl_android_device_id` WHERE date<='$vdt1'");
		
		/*$files = glob("temp_rec_folder/*.xls");
		for($i=0;$i<count($files);$i++)
		{
			if(is_file($files[$i])){
				//Use the unlink function to delete the file.
				unlink($files[$i]);
			}
		}
		
		$files = glob("temp_rec_folder/*.txt");
		for($i=0;$i<count($files);$i++)
		{
			if(is_file($files[$i])){
				//Use the unlink function to delete the file.
				unlink($files[$i]);
			}
		}*/
	}
	
	public function send_whatsapp_message()
	{
		$query = $this->db->query("select * from tbl_whatsapp_message order by id desc limit 50")->result();
		foreach($query as $row)
		{
			$mid 			= $row->id;
			$mobile 		= $row->mobile;
			$media 			= $row->media;
			$message 		= base64_decode($row->message);
			$chemist_id 	= $row->chemist_id;
			$this->Email_Model->send_whatsapp_message($mobile,$message,$media,$chemist_id);
			$this->db->query("DELETE FROM `tbl_whatsapp_message` WHERE id='$mid'");
		}
	}
	
	public function send_group_message_when_pending_order_not_download_alert()
	{
		error_reporting(0);
		$date = date("Y-m-d");
		$myvalue = "";
		$query = $this->db->query("select distinct order_id from `tbl_order` WHERE gstvno='' and date='$date' order by id desc")->result();
		foreach($query as $row)
		{
			$row1 = $this->db->query("select chemist_id from `tbl_order` WHERE order_id='$row->order_id'")->row();
			$row2 = $this->db->query("select name from `tbl_acm` WHERE altercode='$row1->chemist_id'")->row();
			$myvalue.= "\\n $row->order_id - $row2->name ($row1->chemist_id)";
		}
		
		if($myvalue!="")
		{
			/******************group message******************************/
			$w_message 	= "Hi Team,\\n \\nFollowing orders received today have not been generated with an invoice number till now. Please cross check in easy sol. \\n \\n$myvalue \\n \\nThanks";
			$whatsapp_group1 = $this->Scheme_Model->get_website_data("whatsapp_group1");
			//$w_group 	= "919899333989-1567708298@g.us";
			$this->Email_Model->whatsapp_group_message($whatsapp_group1,$w_message,$w_altercode);
			/**********************************************************/
		}
	}
	
	public function fail_report_messages()
	{
		$result = $this->db->query("select * from tbl_whatsapp_email_fail limit 1")->result();
		foreach($result as $row)
		{
			$altercode = $row->altercode;
			$row1 = $this->db->query("select * from tbl_acm where altercode='$altercode'")->row();
			$name = $row1->name;
			$name = "Please Correct Details for : $name ($altercode)";
			$message = $row->message;
			/******************group message******************************/
			$w_message 	= "Hi Team,\\n \\n$name\\n $message";
			$whatsapp_group1 = $this->Scheme_Model->get_website_data("whatsapp_group1");
			$w_altercode = ""; // no need
			$this->Email_Model->whatsapp_group_message($whatsapp_group1,$w_message,$w_altercode);
			/**********************************************************/
			
			$this->db->query("delete from tbl_whatsapp_email_fail where id='$row->id'");
		}
	}
	
	
	
	/***************************02-11-19*********************/
	public function read_skip_invoice()
	{
		$files = glob("uploads_skip_invoice/*.json");
		for($i=0;$i<count($files);$i++)
		{
			$url = base_url().$files[$i];
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_URL, $url);
			$result123 = curl_exec($ch);
			curl_close($ch);
			$this->read_skip_invoice_fun($result123,$files[$i]);
			die;
		}
	}
	
	public function read_skip_invoice_fun($result123,$file_name)
	{
		error_reporting(0);
		$result123 = json_decode($result123, true);
		foreach($result123 as $ks)
		{			
			$amt			= ($ks["amt"]);
			$gstvno			= ($ks["gstvno"]);
			$acno 			= ($ks["acno"]);
			$vno			= ($ks["vno"]);
			$vdt 			= ($ks["vdt"]);
			$psrlno 		= ($ks["psrlno"]);
			$itemc 			= ($ks["itemc"]);
			$batch 			= ($ks["batch"]);
			$qty			= ($ks["qty"]);
			$fqty 			= ($ks["fqty"]);
			$ntrate			= ($ks["ntrate"]);
			$ftrate 		= ($ks["ftrate"]);
			$taxamt 		= ($ks["taxamt"]);
			$dis 			= ($ks["dis"]);
			$disamt 		= ($ks["disamt"]);
			$netamt 		= ($ks["netamt"]);
			$status 		= ($ks["status"]);
			$halfp 			= ($ks["halfp"]);
			$mrp 			= ($ks["mrp"]);
			$hsncode 		= ($ks["hsncode"]);
			$expiry 		= ($ks["expiry"]);
			$scm1 			= ($ks["scm1"]);
			$scm2 			= ($ks["scm2"]);
			$scmper 		= ($ks["scmper"]);
			$localcent 		= ($ks["localcent"]);
			$excise 		= ($ks["excise"]);
			$cgst 			= ($ks["cgst"]);
			$sgst 			= ($ks["sgst"]);
			$igst 			= ($ks["igst"]);
			$adnlvat 		= ($ks["adnlvat"]);
			$gdn 			= ($ks["gdn"]);
			$compcode		= ($ks["compcode"]);
			$division		= ($ks["division"]);
			$item_name		= ($ks["item_name"]);
			$item_code		= ($ks["item_code"]);
			$packing		= ($ks["packing"]);
			$comp_name		= ($ks["comp_name"]);
			$comp_shortname	= ($ks["comp_shortname"]);
			$escode			= ($ks["escode"]);
			$vtype			= ($ks["vtype"]);
			$mdatatype 		= ($ks["mdatatype"]);						

			$old_date_timestamp = strtotime($vdt);
			$vdt 			= date('Y-m-d H:i:s', $old_date_timestamp);
			$delete_slcd	= ($ks["delete_slcd"]);
			$delete_amt		= ($ks["delete_amt"]);
			$delete_namt	= ($ks["delete_namt"]);
			$delete_remarks	= ($ks["delete_remarks"]);
			$delete_descp	= ($ks["delete_descp"]);
			
			$date			= date('Y-m-d');
			$time			= time();
			$qr = $this->db->query("select id from tbl_sales_main where gstvno='$gstvno'")->row();
			if($qr->id=="")
			{
				$url_link = $this->url_link();
				$this->db->query("insert into tbl_sales_main set amt='$amt',gstvno='$gstvno',vdt='$vdt',acno='$acno',vno='$vno',status='$status',compcode='$compcode',division='$division',comp_name='$comp_name',comp_shortname='$comp_shortname',date='$date',time='$time',url_link='$url_link'");	
			}		

			$x = $this->db->query("insert into tbl_sales set gstvno='$gstvno',vdt='$vdt',psrlno='$psrlno',itemc='$itemc',batch='$batch',qty='$qty',fqty='$fqty',ntrate='$ntrate',ftrate='$ftrate',taxamt='$taxamt',dis='$dis',disamt='$disamt',netamt='$netamt',halfp='$halfp',mrp='$mrp',hsncode='$hsncode',expiry='$expiry',scm1='$scm1',scm2='$scm2',scmper='$scmper',localcent='$localcent',excise='$excise',cgst='$cgst',sgst='$sgst',igst='$igst',adnlvat='$adnlvat',gdn='$gdn',item_name='$item_name',item_code='$item_code',packing='$packing',mdatatype='$mdatatype',delete_slcd='$delete_slcd',delete_amt='$delete_amt',delete_namt='$delete_namt',delete_remarks='$delete_remarks',delete_descp='$delete_descp',escode='$escode',vtype='$vtype'");
				
			if($mdatatype=="insert" && $gdn==0)
			{
				$this->db->query("insert into tbl_sales_staff set gstvno='$gstvno',vdt='$vdt',acno='$acno',compcode='$compcode',division='$division',qty='$qty',fqty='$fqty',ntrate='$ntrate',dis='$dis',netamt='$netamt',item_name='$item_name',item_code='$item_code',itemc='$itemc',packing='$packing',vtype='$vtype'");
			}
			if($mdatatype=="delete")
			{
				$this->db->query("insert into tbl_sales_deleted set gstvno='$gstvno',vdt='$vdt',itemc='$itemc',delete_slcd='$delete_slcd',delete_amt='$delete_amt',delete_namt='$delete_namt',delete_remarks='$delete_remarks',delete_descp='$delete_descp',item_name='$item_name',item_code='$item_code',packing='$packing'");
			}
		}
		if($x==1)
		{
			if(is_file($file_name)){
				//Use the unlink function to delete the file.
				unlink($file_name);
			}
		}
	}
	
	public function url_link() {
		$alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
		$pass = array(); //remember to declare $pass as an array
		$alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
		for ($i = 0; $i < 10; $i++) {
			$n = rand(0, $alphaLength);
			$pass[] = $alphabet[$n];
		}
		return implode($pass); //turn the array into a string
	}
	
	/******************29-01-2020********************************/
	public function sales_deleted_daily_report()
	{ 
		error_reporting(0);
		$vdt = date("Y-m-d");
		$row = $this->db->query("select id from tbl_sales_deleted where(delete_descp='ITEM DELETE' or delete_descp='QTY.CHANGE') and vdt='$vdt' and email_status='0' order by id desc")->row();
		if($row->id!="")
		{
			$this->Email_Model->sales_deleted_daily_report($vdt);
		}
	}
	
	/*****************16-11-19***********************/
	//  /usr/bin/curl http://drdmail.xyz/cronjob_page/insert_pending_order
	public function insert_pending_order()
	{
		error_reporting(0);
		$row = $this->db->query("select * from tbl_pending_order where status='1' limit 1")->row();
		if($row->item_code!="")
		{
			$company = $row->company;
			$date_range = $row->date_range;
			$item_code = $row->item_code;
			$row1 = $this->db->query("select compcode from tbl_medicine where item_code='$item_code'")->row();
			if($row1->compcode!="")
			{
				$compcode = $row1->compcode;
				$row2 = $this->db->query("select acno from tbl_compjoin where compcode='$compcode'")->row();
				if($row2->acno!="")
				{
					$acno = $row2->acno;
					$row3 = $this->db->query("select email,code from tbl_acm where code='$acno'")->row();
					$user_email_id 	= $row3->email;
					$staff_compcode	= $row3->code;
				}
				else
				{
					echo "delete";
					$this->db->query("update tbl_pending_order set status='2' where company='$company'");
				}
			}
			else
			{
				echo "delete";
				$this->db->query("update tbl_pending_order set status='2' where company='$company'");
			}
		}
		if (filter_var($user_email_id, FILTER_VALIDATE_EMAIL)) {
		
		}
		else{
			$user_email_id="";
		}
		if($user_email_id!="")
		{
			//28-01-2020 // update
			$this->Email_Model->new_insert_pending_order($user_email_id,$company,$date_range,$staff_compcode);
		}
		else
		{
			if($row->item_code!="")
			{
				echo "delete";
				$this->db->query("update tbl_pending_order set status='2' where company='$company'");
			}
			else
			{
				//28-01-2020 // update
				//insert_pending_order_fail_report
				$row = $this->db->query("select * from tbl_pending_order where status='2' limit 1")->row();
				if($row->item_code!="")
				{
					$date_range = $row->date_range;
					$this->Email_Model->insert_pending_order_fail_report($date_range);
				}
			}
		}
	}	
	
	/*****************23-12-19***********************/
	public function email_notification_send()
	{
		error_reporting(0);
		
		$result = $this->db->query("select * from tbl_email_notification order by id desc limit 20")->result();
		foreach($result as $row)
		{
			$id 			= $row->id;
			$user_email_id 	= $row->email;
			$title 			= $row->title;
			$message 		= $row->message;
			$user_name 		= $row->user_name;
			if (filter_var($user_email_id, FILTER_VALIDATE_EMAIL)) {
		
			}
			else{
				$err = $user_email_id." is Wrong Email";
				$mobile = "";
				$this->Email_Model->tbl_whatsapp_email_fail($mobile,$err,$altercode);
			
				$user_email_id="";
			}
			if($user_email_id!="")
			{
				$this->Email_Model->email_notification_send($user_email_id,$user_name,$title,$message);
			}
			$this->db->query("delete from tbl_email_notification where id='$id'");
		}
	}
	
	/*****************23-01-2020***********************/
	public function corporate_daily_report()
	{
		error_reporting(0);
		$this->Email_Model->corporate_daily_report();
	}
	/*****************28-01-2020*******************/
	public function corporate_monthly_report()
	{
		error_reporting(0);
		$this->Email_Model->corporate_monthly_report();
	}
	
	/*****************24-01-2020***********************/
	public function new_email_send()
	{
		error_reporting(0);
		
		$result = $this->db->query("select * from tbl_email_send order by id desc limit 5")->result();
		foreach($result as $row)
		{
			$id 			= $row->id;
			$user_email_id 	= $row->user_email_id;
			$subject 		= base64_decode($row->subject);
			$message 		= base64_decode($row->message);
			$email_function = $row->email_function;
			$file_name1 	= $row->file_name1;
			$file_name2 	= $row->file_name2;
			$file_name3 	= $row->file_name3;
			$file_name_1 	= $row->file_name_1;
			$file_name_2 	= $row->file_name_2;
			$file_name_3 	= $row->file_name_3;
			$mail_server 	= $row->mail_server;
			$email_other_bcc= $row->email_other_bcc;
			
			$this->Email_Model->new_email_send($user_email_id,$subject,$message,$email_function,$file_name1,$file_name2,$file_name3,$file_name_1,$file_name_2,$file_name_3,$email_other_bcc,$mail_server);
			
			$this->db->query("delete from tbl_email_send where id='$id'");
		}
	}
	
	/*****************13-02-2020*******************/
	public function send_android_notification_firebase()
	{
		error_reporting(0);
		$this->Email_Model->send_android_notification_firebase();
	}
	
	/*****************13-04-2020*******************/
	public function synchronization_of_android_medicine()
	{
		error_reporting(0);
		$count_tbl_medicine = 0;
		$result = $this->db->query("select id from tbl_medicine")->result();
		foreach($result as $row)
		{
			$count_tbl_medicine++;
		}
		//echo $count_tbl_medicine;
		
		$result = $this->db->query("select * from tbl_android_device_id")->result();
		foreach($result as $row)
		{
			if($count_tbl_medicine<$row->count_medicine)
			{
				$id = $row->id;
				$this->db->query("update tbl_android_device_id set clear_database='1' where id='$id'");
			}
		}
	}
	
	public function whats_app_sync()
	{
		$whatsapp_key = $this->Scheme_Model->get_website_data("whatsapp_key");
		$whatsapp_deviceid = $this->Scheme_Model->get_website_data("whatsapp_deviceid");
		$curl = curl_init();

		curl_setopt_array($curl, array(
		  CURLOPT_URL => "https://api.wassi.chat/v1/devices/$whatsapp_deviceid/sync",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  CURLOPT_HTTPHEADER => array(
			"token:$whatsapp_key"
		  ),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		  echo "cURL Error #:" . $err;
		  $this->whats_app_reboot();
		} else {
		  //echo $response;
		  $someArray = json_decode($response, true);
		  //print_r($someArray);
		  if($someArray["status"]=="operative")
		  {
			  echo "ok ha";
		  }
		  else{
			$this->whats_app_reboot();
		  }
		}
	}
	
	public function whats_app_reboot()
	{
		$whatsapp_key = $this->Scheme_Model->get_website_data("whatsapp_key");
		$whatsapp_deviceid = $this->Scheme_Model->get_website_data("whatsapp_deviceid");
		$curl = curl_init();

		curl_setopt_array($curl, array(
		  CURLOPT_URL => "https://api.wassi.chat/v1/devices/$whatsapp_deviceid/reboott?wait=true",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  CURLOPT_HTTPHEADER => array(
			"token:$whatsapp_key"
		  ),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
		  echo $response;
		}
	}
	
	/*****************************new json files**********************/
	public function new_json_files()
	{
		$this->website_menu();
		$this->topflash_json();
		$this->topflash2_json();
		$this->featured_brand_json();
		$this->hot_selling_today_json();
		$this->must_buy_medicines_json();
		$this->short_medicines_available_now_json();
	}
	
	public function website_menu()
	{
		$i = 1;
		$result = $this->db->query("SELECT * FROM `tbl_medicine_category` where status='1' order by short_order asc")->result();
		foreach ($result as $row)
		{
			$code		=	$row->code;
			$name		=	base64_encode(ucwords(strtolower($row->menu)));
			
			$posts[] = array('code'=>$code,'name'=>$name);
		}
		if($posts!="")
		{
			$fp = fopen('uploads_json/website_menu_json.json', 'w');
			fwrite($fp, json_encode($posts));
			fclose($fp);
		}
	}
	
	public function topflash_json()
	{
		$i = 1;
		$result = $this->db->query("select * from tbl_slider where status='1' order by short_order asc")->result();
		foreach ($result as $row)
		{
			if($i==1)
			{
				$id	=	"active";
			}
			else{
				$id = "";
			}
			$i++;
			$compname="";
			if($row->funtype=="2" || $row->funtype=="3"){
				$row->itemid = $row->compid; 
				$row1 =  $this->db->query("select company_full_name from tbl_medicine where compcode='$row->itemid'")->row();
				//$compname = base64_decode($row1->company_full_name);
				$compname = ($row1->company_full_name);
			}
			$funtype	=	$row->funtype;
			$itemid	    =	$row->itemid;
			$division	=	$row->division;
			$image 		= 	base_url()."uploads/manage_slider/photo/resize/".$row->image;
			
			$posts[] = array('id'=> $id,'funtype'=>$funtype,'itemid'=> $itemid,'compname'=>$compname,'division'=>$division,'image'=>$image);
		}
		if($posts!="")
		{
			$fp = fopen('uploads_json/topflash_json.json', 'w');
			fwrite($fp, json_encode($posts));
			fclose($fp);
		}
	}
	
	public function topflash2_json()
	{
		$i = 1;
		$result = $this->db->query("select * from tbl_slider2 where status='1' order by short_order asc")->result();
		foreach ($result as $row)
		{
			if($i==1)
			{
				$id	=	"active";
			}
			else{
				$id = "";
			}
			$i++;
			$compname="";
			if($row->funtype=="2" || $row->funtype=="3"){
				$row->itemid = $row->compid; 
				$row1 =  $this->db->query("select company_full_name from tbl_medicine where compcode='$row->itemid'")->row();
				//$compname = base64_decode($row1->company_full_name);
				$compname = ($row1->company_full_name);
			}
			$funtype	=	$row->funtype;
			$itemid	    =	$row->itemid;
			$division	=	$row->division;
			$image 		= 	base_url()."uploads/manage_slider2/photo/resize/".$row->image;
			
			$posts[] = array('id'=> $id,'funtype'=>$funtype,'itemid'=> $itemid,'compname'=>$compname,'division'=>$division,'image'=>$image);
		}
		if($posts!="")
		{
			$fp = fopen('uploads_json/topflash2_json.json', 'w');
			fwrite($fp, json_encode($posts));
			fclose($fp);
		}
	}
	
	public function featured_brand_json()
	{
		$query = $this->db->query("SELECT * FROM `tbl_featured_brand` where status='1' order by short_order asc")->result();
		foreach ($query as $row)
		{
			$id					=	$row->id;
			$compcode			=	($row->compcode);
			$company_full_name	=	base64_encode(ucwords(strtolower($row->company_full_name)));
			$division = "";
			$image				=   base_url()."uploads/manage_featured_brand/photo/resize/".$row->image;
			if ($row->image==""){
				$image 			= "http://drdmail.xyz/uploads/okok1.jpg";
			}
			if($row->company_full_name!="")
			{
				$posts[] = array('id'=> $id,'compcode'=>$compcode,'company_full_name'=> $company_full_name,'image'=>$image,'division'=>$division);
			}
		}
		if($posts!="")
		{
			$fp = fopen('uploads_json/featured_brand_json.json', 'w');
			fwrite($fp, json_encode($posts));
			fclose($fp);
		}
	}

	public function hot_selling_today_json()
	{
		error_reporting(0);
		$med_date_time = date('d-M h:i A');
		$vdt = date("Y-m-d");
		$query = $this->db->query("select DISTINCT item_code,item_name, COUNT(*) as ct FROM tbl_sales where vdt='$vdt' GROUP BY item_code,item_name HAVING COUNT(*) > 1 order by ct desc limit 10")->result();
		foreach ($query as $row)
		{
			$item_code		=	$row->item_code;
			$row1 			=   $this->db->query("select * from tbl_medicine where item_code='$item_code'")->row();
			$item_code		=	$row1->item_code;
			$id				=	$row1->id;
			$item_name		=	base64_encode(ucwords(strtolower($row1->item_name)));
			$company_full_name =base64_encode(ucwords(strtolower($row1->company_full_name)));
			
			$itemid			=	$row1->id;
			$image 			=   "http://drdmail.xyz/uploads/newok.jpg";
			$row2 			=   $this->db->query("select * from tbl_medicine_image where itemid='$itemid'")->row();
			if($row2->image!="")
			{
				$image      =   base_url()."uploads/manage_medicine_image/photo/resize/".$row2->image;
			}
			$packing		=	$row1->packing;
			$mrp			=	number_format($row1->mrp);
			$sale_rate		=	number_format($row1->sale_rate);
			$batchqty		=	$row1->batchqty;
			$scheme			=	$row1->salescm1."+".$row1->salescm2;
			$batch_no		=	$row1->batch_no;
			$expiry			=	$row1->expiry;
			
			$posts[] = array('item_id'=> $id,'item_code'=>$item_code,'item_name'=>$item_name,'company_full_name'=>$company_full_name,'image'=>$image,'packing'=>$packing,'mrp'=>$mrp,'sale_rate'=>$sale_rate,'batchqty'=>$batchqty,'scheme'=>$scheme,'batch_no'=>$batch_no,'expiry'=>$expiry,'med_date_time'=>$med_date_time);
		}
		if($posts!="")
		{
			$fp = fopen('uploads_json/hot_selling_today_json.json', 'w');
			fwrite($fp, json_encode($posts));
			fclose($fp);
		}
	}

	public function must_buy_medicines_json()
	{
		error_reporting(0);
		$med_date_time = date('d-M h:i A');
		$query = $this->db->query("select * from tbl_must_buy_medicines order by id desc")->result();
		foreach ($query as $row)
		{
			$itemid			=	$row->itemid;
			$row1 			=   $this->db->query("select * from tbl_medicine where id='$itemid'")->row();
			$item_code		=	$row1->item_code;
			$id				=	$row1->id;
			$item_name		=	base64_encode(ucwords(strtolower($row1->item_name)));
			$company_full_name =base64_encode(ucwords(strtolower($row1->company_full_name)));
			$image 			=   "http://drdmail.xyz/uploads/newok.jpg";
			$row2 			=   $this->db->query("select * from tbl_medicine_image where itemid='$itemid'")->row();
			if($row2->image!="")
			{
				$image      =   base_url()."uploads/manage_medicine_image/photo/resize/".$row2->image;
			}
			$packing		=	$row1->packing;
			$mrp			=	number_format($row1->mrp);
			$sale_rate		=	number_format($row1->sale_rate);
			$batchqty		=	$row1->batchqty;
			$scheme			=	$row1->salescm1."+".$row1->salescm2;
			$batch_no		=	$row1->batch_no;
			$expiry			=	$row1->expiry;
			
			$posts[] = array('item_id'=> $id,'item_code'=>$item_code,'item_name'=>$item_name,'company_full_name'=>$company_full_name,'image'=>$image,'packing'=>$packing,'mrp'=>$mrp,'sale_rate'=>$sale_rate,'batchqty'=>$batchqty,'scheme'=>$scheme,'batch_no'=>$batch_no,'expiry'=>$expiry,'med_date_time'=>$med_date_time);
		}
		if($posts!="")
		{
			$fp = fopen('uploads_json/must_buy_medicines_json.json', 'w');
			fwrite($fp, json_encode($posts));
			fclose($fp);
		}
	}
	
	public function short_medicines_available_now_json()
	{
		error_reporting(0);
		$med_date_time = date('d-M h:i A');
		$query = $this->db->query("select * from tbl_delivering_today order by id desc")->result();
		foreach ($query as $row)
		{
			$itemid			=	$row->itemid;
			$row1 			=   $this->db->query("select * from tbl_medicine where id='$itemid'")->row();
			$id				=	$row1->id;
			$item_code		=	$row1->item_code;
			$item_name		=	base64_encode(ucwords(strtolower($row1->item_name)));
			$company_full_name =base64_encode(ucwords(strtolower($row1->company_full_name)));
			
			$itemid			=	$row1->id;
			$image 			=   "http://drdmail.xyz/uploads/newok.jpg";
			$row2 			=   $this->db->query("select * from tbl_medicine_image where itemid='$itemid'")->row();
			if($row2->image!="")
			{
				$image      =   base_url()."uploads/manage_medicine_image/photo/resize/".$row2->image;
			}
			$packing		=	$row1->packing;
			$mrp			=	number_format($row1->mrp);
			$sale_rate		=	number_format($row1->sale_rate);
			$batchqty		=	$row1->batchqty;
			$scheme			=	$row1->salescm1."+".$row1->salescm2;
			$batch_no		=	$row1->batch_no;
			$expiry			=	$row1->expiry;
			
			$posts[] = array('item_id'=> $id,'item_code'=>$item_code,'item_name'=>$item_name,'company_full_name'=>$company_full_name,'image'=>$image,'packing'=>$packing,'mrp'=>$mrp,'sale_rate'=>$sale_rate,'batchqty'=>$batchqty,'scheme'=>$scheme,'batch_no'=>$batch_no,'expiry'=>$expiry,'med_date_time'=>$med_date_time);
		}
		if($posts!="")
		{
			$fp = fopen('uploads_json/short_medicines_available_now_json.json', 'w');
			fwrite($fp, json_encode($posts));
			fclose($fp);
		}
	}
}