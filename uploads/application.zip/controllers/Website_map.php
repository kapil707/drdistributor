<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class website_map extends CI_Controller {
	public function index($chemist_id="")
	{
		$chemist_id = base64_decode($chemist_id);
		error_reporting(0);
		$mapapikey = $this->Scheme_Model->get_website_data("mapapikey");
		$row1->name 		= "DRD Office";
		$row1->latitude 	= "28.5183163";
		$row1->longitude 	= "77.279475";
		$order_msg = "You do not have any active order out of delivery";
		$row = $this->db->query("SELECT * FROM `tbl_deliverby` WHERE `chemist_id`='$chemist_id'")->row();
		if($row->id!=""){
			$deliverby_altercode = $row->deliverby_altercode;
			$row1 = $this->db->query("SELECT * FROM `tbl_master` WHERE `altercode`='$deliverby_altercode' and slcd='SM'")->row();
			if($row1->latitude=="")
			{
				$order_msg = "You do not have any active order out of delivery";
				$row1->name 		= "DRD Office";
				$row1->latitude 	= "28.5183163";
				$row1->longitude 	= "77.279475";
			}
			else
			{
				$order_msg = "Delivery boy $row1->name";
			}
		}
		?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="refresh" content="60" />
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <style>
  /* Make the image fully responsive */
  .carousel-inner img {
	height: 100vh !important;
	width: 100%;
	object-fit: cover;
  }
   /* Set the size of the div element that contains the map */
  #map {
	height: 400px;  /* The height is 400 pixels */
	width: 100%;  /* The width is the width of the web page */
   }
    </style>
</head>
<body style="background: #f7f7f7;" class="text-center">
<br><br>
<h3><?=$order_msg ?></h3>
<br><br>
<div id="map"></div>
<Script>
function initMap() {
	var locations = [
		['<?= $row1->name; ?>', '<?= $row1->latitude; ?>','<?= $row1->longitude; ?>', 0]
	]
	
	 var map = new google.maps.Map(document.getElementById('map'), {
      zoom: 12,
      center: new google.maps.LatLng('<?= $row1->latitude; ?>','<?= $row1->longitude; ?>'),
      mapTypeId: google.maps.MapTypeId.ROADMAP
    });

    var infowindow = new google.maps.InfoWindow();

    var marker, i;

    for (i = 0; i < locations.length; i++) {  
      marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map
      });

      google.maps.event.addListener(marker, 'click', (function(marker, i) {
        return function() {
          infowindow.setContent(locations[i][0]);
          infowindow.open(map, marker);
        }
      })(marker, i));
    }
}
</script>
    <!--Load the API from the specified URL
    * The async attribute allows the browser to render the page while the API loads
    * The key parameter will contain your own API key (which is not needed for this tutorial)
    * The callback parameter executes the initMap() function
    -->
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=<?=$mapapikey?>&callback=initMap">
    </script>
    </div>
</div>
</body>
		<?php
	}
}