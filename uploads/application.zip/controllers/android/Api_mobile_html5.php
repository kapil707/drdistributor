<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Api_mobile_html5 extends CI_Controller {
	public function slider(){
		$data['result'] = $this->db->query("select * from tbl_slider")->result();
		$this->load->view('android/android_mobile_slider', $data);
	}
	public function send_email_invoice_chemist_report($gstvno,$usercode,$vdt)
	{
		error_reporting(0);
		$gstvno 	= base64_decode($gstvno);
		$usercode 	= base64_decode($usercode);
		$vdt 		= base64_decode($vdt);
		/*if($_SESSION['invexport']=="E")
		{*/
			$this->Email_Model->send_email_invoice_chemist_report($gstvno,$usercode,$vdt,"");
		//}
	}

	public function download_invoice_txt_file_chemist_report($gstvno,$usercode,$vdt)
	{
		error_reporting(0);
		$gstvno 	= base64_decode($gstvno);
		$usercode 	= base64_decode($usercode);
		$vdt 		= base64_decode($vdt);
		
		$this->Excel_Model->chemist_invoice_report_txt($gstvno,$acno,$vdt,"");
	}

	public function download_invoice_excel_chemist_report($gstvno,$usercode,$vdt)
	{
		error_reporting(0);
		$gstvno 	= base64_decode($gstvno);
		$usercode 	= base64_decode($usercode);
		$vdt 		= base64_decode($vdt);
		
		$this->Excel_Model->chemist_invoice_report_excel($gstvno,$usercode,$vdt,"");
		exit;
	}
	
	public function download_invoice_pdf_chemist_report($gstvno,$usercode,$vdt)
	{
		// not working right now
		error_reporting(0);		
	}
	
	public function item_wise_report()
	{
		$user_division = $_GET["user_division"];
		$user_compcode = $_GET["user_compcode"];
		$data["user_division"] = $user_division;
		$data["user_compcode"] = $user_compcode;
		$this->load->view('android/item_wise_report',$data);
	}
	
	public function item_wise_report_month()
	{
		$user_division = $_GET["user_division"];
		$user_compcode = $_GET["user_compcode"];
		$data["user_division"] = $user_division;
		$data["user_compcode"] = $user_compcode;
		$this->load->view('android/item_wise_report_month',$data);
	}
	
	public function chemist_wise_report()
	{
		$user_division = $_GET["user_division"];
		$user_compcode = $_GET["user_compcode"];
		$data["user_division"] = $user_division;
		$data["user_compcode"] = $user_compcode;
		$this->load->view('android/chemist_wise_report',$data);
	}
	
	public function chemist_wise_report_month()
	{
		$user_division = $_GET["user_division"];
		$user_compcode = $_GET["user_compcode"];
		$data["user_division"] = $user_division;
		$data["user_compcode"] = $user_compcode;
		$this->load->view('android/chemist_wise_report_month',$data);
	}
}