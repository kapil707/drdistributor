<?php
header('Content-Type: application/json');
defined('BASEPATH') OR exit('No direct script access allowed');
class Read_json extends CI_Controller {	
	
	public function item_wise_report_api()
	{
		error_reporting(0);
		$user_session	=	$_POST["user_session"];
		$user_division	=	$_POST["user_division"];
		$user_compcode	=	$_POST["user_compcode"];
		$formdate		= 	$_POST["formdate"];
		$todate	 		= 	$_POST["todate"];
		$monthdate	 	= 	$_POST["monthdate"];
		
		$json_url = base_url()."api_website/item_wise_report_api?formdate=$formdate&todate=$todate&monthdate=$monthdate&user_session=$user_session&&user_division=$user_division&user_compcode=$user_compcode";
		$ch = curl_init($json_url);
		$options = array(
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_HTTPHEADER => array('Content-type: application/json'),
		);
		curl_setopt_array($ch,$options);
		$result = curl_exec($ch);
		print_r($result);
	}
	
	public function chemist_wise_report_api()
	{
		error_reporting(0);
		$user_session	=	$_POST["user_session"];
		$user_division	=	$_POST["user_division"];
		$user_compcode	=	$_POST["user_compcode"];
		$formdate		= 	$_POST["formdate"];
		$todate	 		= 	$_POST["todate"];
		$monthdate	 	= 	$_POST["monthdate"];
		
		$json_url = base_url()."api_website/chemist_wise_report_api?formdate=$formdate&todate=$todate&monthdate=$monthdate&user_session=$user_session&user_division=$user_division&user_compcode=$user_compcode";
		$ch = curl_init($json_url);
		$options = array(
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_HTTPHEADER => array('Content-type: application/json'),
		);
		curl_setopt_array($ch,$options);
		$result = curl_exec($ch);
		print_r($result);
	}
	
	public function stock_and_sales_analysis_api()
	{
		error_reporting(0);
		$user_session	=	$_POST["user_session"];
		$user_division	=	$_POST["user_division"];
		$user_compcode	=	$_POST["user_compcode"];
		
		$json_url = base_url()."api_website/stock_and_sales_analysis_api?formdate=$formdate&todate=$todate&monthdate=$monthdate&user_session=$user_session&user_division=$user_division&user_compcode=$user_compcode";
		$ch = curl_init($json_url);
		$options = array(
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_HTTPHEADER => array('Content-type: application/json'),
		);
		curl_setopt_array($ch,$options);
		$result = curl_exec($ch);
		print_r($result);
	}
	
	/********************chemist*******************/
	
	public function notification_api(){
		error_reporting(0);
		$user_type 			= $_POST['user_type'];
		$user_altercode		= $_POST['user_altercode'];
		$lastid1			= $_POST['lastid1'];
		$json_url = base_url()."api_website/notification_api?user_type=$user_type&user_altercode=$user_altercode&lastid1=$lastid1";
		$ch = curl_init($json_url);
		$options = array(
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_HTTPHEADER => array('Content-type: application/json'),
		);
		curl_setopt_array($ch,$options);
		$result = curl_exec($ch);
		print_r($result);
	}
	
	public function notification_view_api(){
		error_reporting(0);
		$user_type 			= $_POST['user_type'];
		$user_altercode		= $_POST['user_altercode'];
		$id					= $_POST['id'];
		$json_url = base_url()."api_website/notification_view_api?id=$id";
		$ch = curl_init($json_url);
		$options = array(
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_HTTPHEADER => array('Content-type: application/json'),
		);
		curl_setopt_array($ch,$options);
		$result = curl_exec($ch);
		print_r($result);
	}
	
	public function my_invoice_api(){
		error_reporting(0);
		$user_type 		= $_POST['user_type'];
		$user_code		= $_POST['user_code'];
		$lastid1		= $_POST['lastid1'];
		$json_url = base_url()."api_website/my_invoice_api?user_type=$user_type&user_code=$user_code&lastid1=$lastid1";
		$ch = curl_init($json_url);
		$options = array(
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_HTTPHEADER => array('Content-type: application/json'),
		);
		curl_setopt_array($ch,$options);
		$result = curl_exec($ch);
		print_r($result);
	}
	
	public function my_invoice_view_api(){
		error_reporting(0);
		$gstvno		= $_POST['gstvno'];
		$acno		= $_POST['acno'];
		$vdt		= $_POST['vdt'];
		$json_url = base_url()."api_website/my_invoice_view_api?gstvno=$gstvno&acno=$acno&vdt=$vdt";
		$ch = curl_init($json_url);
		$options = array(
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_HTTPHEADER => array('Content-type: application/json'),
		);
		curl_setopt_array($ch,$options);
		$result = curl_exec($ch);
		print_r($result);
	}
	
	public function send_email_invoice_chemist_report()
	{
		error_reporting(0);
		$gstvno	 	= $_REQUEST["gstvno"];
		$acno	 	= $_REQUEST["acno"];
		$vdt	 	= $_REQUEST["vdt"];
		$json_url 	= base_url()."api_website_html/send_email_invoice_chemist_report/$gstvno/$acno/$vdt";
		$ch = curl_init($json_url);
		$options = array(
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_HTTPHEADER => array('Content-type: application/json'),
		);
		curl_setopt_array($ch,$options);
		$result = curl_exec($ch);
		print_r($result);
	}
	
	public function my_orders_api(){
		error_reporting(0);
		$user_type 		= $_POST['user_type'];
		$user_altercode	= $_POST['user_altercode'];
		$lastid1	 	= $_POST["lastid1"];
		$json_url = base_url()."api_website/my_orders_api?user_type=$user_type&user_altercode=$user_altercode&lastid1=$lastid1";
		$ch = curl_init($json_url);
		$options = array(
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_HTTPHEADER => array('Content-type: application/json'),);
		curl_setopt_array($ch,$options);
		$result = curl_exec($ch);
		print_r($result);
	}
	
	public function my_orders_view_api(){
		error_reporting(0);
		$user_type 		= $_POST['user_type'];
		$user_altercode	= $_POST['user_altercode'];
		$order_id		= $_POST['order_id'];
		$json_url = base_url()."api_website/my_orders_view_api?user_type=$user_type&user_altercode=$user_altercode&order_id=$order_id";
		$ch = curl_init($json_url);
		$options = array(
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_HTTPHEADER => array('Content-type: application/json'),
		);
		curl_setopt_array($ch,$options);
		$result = curl_exec($ch);
		print_r($result);
	}
}
?>