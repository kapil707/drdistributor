<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Api_mobile_html12 extends CI_Controller {
	public function slider(){
		$data['result'] = $this->db->query("select * from tbl_slider")->result();
		$this->load->view('android/android_mobile_slider', $data);
	}	
	public function item_wise_report()
	{
		error_reporting(0);
		$user_session  = $_GET["user_session"];
		$user_division = $_GET["user_division"];
		$user_compcode = $_GET["user_compcode"];
		$data["user_session"]  = $user_session;
		$data["user_division"] = $user_division;
		$data["user_compcode"] = $user_compcode;
		$this->load->view('android/item_wise_report',$data);
	}
	
	public function item_wise_report_month()
	{
		error_reporting(0);
		$user_session  = $_GET["user_session"];
		$user_division = $_GET["user_division"];
		$user_compcode = $_GET["user_compcode"];
		$data["user_session"]  = $user_session;
		$data["user_division"] = $user_division;
		$data["user_compcode"] = $user_compcode;
		$this->load->view('android/item_wise_report_month',$data);
	}
	
	public function chemist_wise_report()
	{
		error_reporting(0);
		$user_session  = $_GET["user_session"];
		$user_division = $_GET["user_division"];
		$user_compcode = $_GET["user_compcode"];
		$data["user_session"]  = $user_session;
		$data["user_division"] = $user_division;
		$data["user_compcode"] = $user_compcode;
		$this->load->view('android/chemist_wise_report',$data);
	}
	
	public function chemist_wise_report_month()
	{
		error_reporting(0);
		$user_session  = $_GET["user_session"];
		$user_division = $_GET["user_division"];
		$user_compcode = $_GET["user_compcode"];
		$data["user_session"]  = $user_session;
		$data["user_division"] = $user_division;
		$data["user_compcode"] = $user_compcode;
		$this->load->view('android/chemist_wise_report_month',$data);
	}
	
	public function stock_and_sales_analysis()
	{
		error_reporting(0);
		$user_session  = $_GET["user_session"];
		$user_division = $_GET["user_division"];
		$user_compcode = $_GET["user_compcode"];
		$data["user_session"]  = $user_session;
		$data["user_division"] = $user_division;
		$data["user_compcode"] = $user_compcode;
		$this->load->view('android/stock_and_sales_analysis',$data);
	}
	
	/*********************chemist************************/
	
	public function chemist_notification()
	{
		error_reporting(0);
		$user_altercode  	= $_GET["user_altercode"];
		$user_type 			= $_GET["user_type"];
		$data["user_altercode"]  = $user_altercode;
		$data["user_type"] = $user_type;
		$this->load->view('android/chemist/notification',$data);
	}
	
	public function chemist_notification_view($id)
	{
		error_reporting(0);
		$data["id"] = $id;
		$this->load->view('android/chemist/notification_view',$data);
	}
	
	public function chemist_my_invoice()
	{
		error_reporting(0);
		$user_type 		= $_GET['user_type'];
		$user_code		= $_GET['user_code'];
		$data["user_type"] = $user_type;
		$data["user_code"] = $user_code;
		$this->load->view('android/chemist/my_invoice',$data);
	}
	
	public function chemist_my_invoice_view($gstvno,$acno,$vdt)
	{
		error_reporting(0);
		$data["gstvno"] = ($gstvno);
		$data["acno"] 	= ($acno);
		$data["vdt"] 	= ($vdt);
		$this->load->view('android/chemist/my_invoice_view',$data);
	}
	
	public function chemist_my_orders(){
		$user_type 		= $_GET['user_type'];
		$user_altercode	= $_GET['user_altercode'];
		$data["user_type"] 		= $user_type;
		$data["user_altercode"] = $user_altercode;
		$this->load->view('android/chemist/my_orders',$data);
	}
	
	public function chemist_my_orders_view($order_id="",$user_type="",$user_altercode="")
	{	
		error_reporting(0);
		$data["order_id"] = base64_decode($order_id);
		$data["user_type"] = base64_decode($user_type);
		$data["user_altercode"] = base64_decode($user_altercode);
		$this->load->view('android/chemist/my_orders_view',$data);
	}
}