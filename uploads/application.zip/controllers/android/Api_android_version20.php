<?php header("Content-type: application/json; charset=utf-8");
defined('BASEPATH') OR exit('No direct script access allowed');
class Api_android_version20 extends CI_Controller {
	public function api_android_version_check()
	{
		error_reporting(0);
		$firebase_token = $_POST["firebase_token"];
		$device_id		= $_POST["device_id"];
		$user_type 		= $_POST["user_type"];
		$chemist_id		= $_POST["chemist_id"];
		$user_code		= $_POST["user_code"];
		$user_password	= $_POST["user_password"];
		$count_medicine	= $_POST["count_medicine"];
		$count_draft	= $_POST["count_draft"];
		$versioncode	= $_POST["versioncode"];
		$latitude		= $_POST['latitude'];
		$longitude		= $_POST['longitude'];
		$time			= time();
		$date			= date("Y-m-d");
		$datetime 		= time();
		$timei 			= date("i",$time);
		$timef  		= date("H:i",$time);
		$row = $this->db->query("select id from tbl_acm_info where user_altercode='$chemist_id' and user_type='$user_type' and device_id='$device_id' and latitude='$latitude' and longitude='$longitude' order by id desc")->row();
		if($row->id=="")
		{
			$this->db->query("insert into tbl_acm_info set latitude='$latitude',longitude='$longitude',user_altercode='$chemist_id',user_type='$user_type',date='$date',time='$timef',datetime='$datetime',device_id='$device_id'");
		}
		$row = $this->db->query("select * from tbl_android_device_id where device_id='$device_id' ")->row();
		if($row->id=="")
		{
			$this->db->query("insert into tbl_android_device_id set device_id='$device_id',user_type='$user_type',chemist_id='$chemist_id',versioncode='$versioncode',firebase_token='$firebase_token',time='$time',date='$date',count_medicine='$count_medicine',count_draft='$count_draft'");
		}
		else
		{
			$this->db->query("update tbl_android_device_id set device_id='$device_id',user_type='$user_type',chemist_id='$chemist_id',versioncode='$versioncode',firebase_token='$firebase_token',time='$time',date='$date',count_medicine='$count_medicine',count_draft='$count_draft' where device_id='$device_id'");
		}
		
		$logout = $row->logout;
		if($logout==1)
		{
			$this->db->query("update tbl_android_device_id set logout='0' where device_id='$device_id'");
		}
		
		$clear_database = $row->clear_database;
		if($clear_database==1)
		{
			$this->db->query("update tbl_android_device_id set clear_database='0' where device_id='$device_id'");
		}
		
		$broadcast_title = $row->title;
		$broadcast = $row->broadcast;
		if($broadcast!="")
		{
			$this->db->query("update tbl_android_device_id set title='',broadcast='' where device_id='$device_id'");
		}
		
		$android_versioncode 	= $this->Scheme_Model->get_website_data("android_versioncode");
		$force_update 			= $this->Scheme_Model->get_website_data("force_update");
		$android_mobile 		= $this->Scheme_Model->get_website_data("android_mobile");
		$android_email 			= $this->Scheme_Model->get_website_data("android_email");
		$android_whatsapp 		= $this->Scheme_Model->get_website_data("android_whatsapp");
		
		$android_noti = 0;
		if($user_type == "chemist")
		{
			$row = $this->db->query("select id from tbl_new_notification where user_type='chemist' and chemist_id='$chemist_id' and status='0'")->row();
			if($row->id!="")
			{
				$android_noti = 1;
			}
		}
		
		$user_error_message = "can not permission to work with this file";
		$status = "0";
		if($user_type=="chemist")
		{
			$query = $this->db->query("select tbl_acm.id,tbl_acm.code,tbl_acm.altercode,tbl_acm.name,tbl_acm.address,tbl_acm.mobile,tbl_acm.invexport,tbl_acm.email,tbl_acm.status as status1,tbl_acm_other.status,tbl_acm_other.password as password,tbl_acm_other.exp_date from tbl_acm left join tbl_acm_other on tbl_acm.code = tbl_acm_other.code where tbl_acm.altercode='$chemist_id' and tbl_acm.code=tbl_acm_other.code limit 1")->row();
			if($query->id!="")
			{
				$user_error_message = "Can not Place order. Please Logout and Login again with your Password, as the old Password has expired.";
				if ($query->password == $user_password)
				{
					$status = "1";
					$user_error_message = "";
				}
			}
		}
		
		if($user_type=="sales")
		{
			$query = $this->db->query("select u.id,u.customer_code,u.customer_name,u.cust_addr1,u.cust_mobile,u.cust_email,u.is_active,u.user_role,u.login_expiry,u.divison,u.company_name,lu.password	from tbl_users u left join tbl_users_other lu on lu.customer_code = u.customer_code where lu.customer_code='$chemist_id' limit 1")->row();
			if($query->id!="")
			{
				$user_error_message = "Can not Place order. Please Logout and Login again with your Password, as the old Password has expired.";
				if ($query->password == $user_password)
				{
					$status = "1";
					$user_error_message = "";
				}
			}
		}
		$query = $this->db->query("SELECT * FROM `tbl_featured_brand` where status='1' order by company_full_name asc")->result();
		foreach ($query as $row)
		{
			$id					=	$row->id;
			$compcode			=	($row->compcode);
			$division			=	($row->division);
			$company_full_name	=	base64_encode($row->company_full_name);
			$image				=   base_url()."uploads/manage_featured_brand/photo/resize/".$row->image;
			if ($row->image==""){
				$image 			= "http://drdmail.xyz/uploads/okok.jpg";
			}
			if($row->company_full_name!=""){
$items1 .= <<<EOD
{"id":"{$id}","compcode":"{$compcode}","company_full_name":"{$company_full_name}","image":"{$image}","division":"{$division}"},
EOD;
			}
		}
if ($items1 != '') {
	$items1 = substr($items1, 0, -1);
}
$items1 = "[$items1]";

		$vdt = date("Y-m-d");
		$query = $this->db->query("select DISTINCT item_code,item_name, COUNT(*) as ct FROM tbl_sales where vdt='$vdt' GROUP BY item_code,item_name HAVING COUNT(*) > 1 order by ct desc limit 10")->result();
		foreach ($query as $row)
		{
			$item_code		=	$row->item_code;
			$item_name		=	base64_encode($row->item_name);
			$row1 			=   $this->db->query("select id,packing,mrp,sale_rate,company_full_name from tbl_medicine where item_code='$item_code'")->row();
			$id				=	$row1->id;
			$image 			=   "http://drdmail.xyz/uploads/okok.jpg";
			$company_full_name   =	base64_encode($row1->company_full_name);
			$packing		=	$row1->packing;
			$mrp			=	number_format($row1->mrp);
			$sale_rate		=	number_format($row1->sale_rate);
$items2 .= <<<EOD
{"id":"{$id}","item_code":"{$item_code}","item_name":"{$item_name}","image":"{$image}","packing":"{$packing}","mrp":"{$mrp}","sale_rate":"{$sale_rate}","company_full_name":"{$company_full_name}"},
EOD;
		}
if ($items2 != '') {
	$items2 = substr($items2, 0, -1);
}
$items2 = "[$items2]";

		$query = $this->db->query("select * from tbl_must_buy_medicines order by id desc")->result();
		foreach ($query as $row)
		{
			$itemid			=	$row->itemid;
			$row1 			=   $this->db->query("select * from tbl_medicine where id='$itemid'")->row();
			$item_code		=	$row1->item_code;
			$item_name		=	base64_encode($row1->item_name);			
			$id				=	$row1->id;
			$image 			=   "http://drdmail.xyz/uploads/okok.jpg";
			$company_full_name   =	base64_encode($row1->company_full_name);
			$packing		=	$row1->packing;
			$mrp			=	number_format($row1->mrp);
			$sale_rate		=	number_format($row1->sale_rate);
$items3 .= <<<EOD
{"id":"{$id}","item_code":"{$item_code}","item_name":"{$item_name}","image":"{$image}","packing":"{$packing}","mrp":"{$mrp}","sale_rate":"{$sale_rate}","company_full_name":"{$company_full_name}"},
EOD;
		}
if ($items3 != '') {
	$items3 = substr($items3, 0, -1);
}
$items3 = "[$items3]";

		$query = $this->db->query("select * from tbl_delivering_today order by id desc")->result();
		foreach ($query as $row)
		{
			$itemid			=	$row->itemid;
			$row1 			=   $this->db->query("select * from tbl_medicine where id='$itemid'")->row();
			$item_code		=	$row1->item_code;
			$item_name		=	base64_encode($row1->item_name);			
			$id				=	$row1->id;
			$image 			=   "http://drdmail.xyz/uploads/okok.jpg";
			$company_full_name   =	base64_encode($row1->company_full_name);
			$packing		=	$row1->packing;
			$mrp			=	number_format($row1->mrp);
			$sale_rate		=	number_format($row1->sale_rate);
$items4 .= <<<EOD
{"id":"{$id}","item_code":"{$item_code}","item_name":"{$item_name}","image":"{$image}","packing":"{$packing}","mrp":"{$mrp}","sale_rate":"{$sale_rate}","company_full_name":"{$company_full_name}"},
EOD;
		}
if ($items4 != '') {
	$items4 = substr($items4, 0, -1);
}
$items4 = "[$items4]";

$items .= <<<EOD
{"status":"{$status}","logout":"{$logout}","clear_database":"{$clear_database}","broadcast_title":"{$broadcast_title}","broadcast":"{$broadcast}","user_error_message":"{$user_error_message}","android_versioncode":"{$android_versioncode}","force_update":"{$force_update}","android_mobile":"{$android_mobile}","android_email":"{$android_email}","android_whatsapp":"{$android_whatsapp}","android_noti":"{$android_noti}","items1":$items1,"items2":$items2,"items3":$items3,"items4":$items4},
EOD;
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
}