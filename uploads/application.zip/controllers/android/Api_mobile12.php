<?php header("Content-type: application/json; charset=utf-8");
defined('BASEPATH') OR exit('No direct script access allowed');
class Api_mobile12 extends CI_Controller {
	public function login($page_type)
	{
		error_reporting(0);
		if($page_type=="get")
		{
			$submit		= $_GET['submit'];
			$user_name1 = $_GET['user_name1'];
			$password1 	= $_GET['password1'];
		}
		if($page_type=="post")
		{
			$submit		= $_POST['submit'];
			$user_name1 = $_POST['user_name1'];
			$password1 	= $_POST['password1'];
		}
		$submit1 = md5("my_sweet_login");
		$submit1 = sha1($submit1);
		$submit1 = md5($submit1);
		$submit1 = sha1($submit1);
		$submit1 = md5($submit1);
		$submit1 = sha1($submit1);
		if($submit==$submit1)
		{
			$defaultpassword= $this->Scheme_Model->get_website_data("defaultpassword");
			$user_return 	= 	"0";
			$user_alert 	= 	"Wrong Anything Else";
			if($user_name1!="" && $password1!="")
			{
				$user_password = md5(strtolower($password1));
				$alert = "Enter true User name or Password";			

				$query = $this->db->query("select tbl_acm.id,tbl_acm.code,tbl_acm.altercode,tbl_acm.name,tbl_acm.address,tbl_acm.mobile,tbl_acm.invexport,tbl_acm.email,tbl_acm.status as status1,tbl_acm_other.status,tbl_acm_other.password as password,tbl_acm_other.exp_date,tbl_acm_other.block from tbl_acm left join tbl_acm_other on tbl_acm.code = tbl_acm_other.code where tbl_acm.altercode='$user_name1' and tbl_acm.code=tbl_acm_other.code limit 1")->row();
				if ($query->id!="")
				{
					if ($query->password == $user_password || $user_password==md5(strtolower($defaultpassword)))
					{
						if($query->block=="0")
						{
							$user_session 	= 	$query->id;
							$user_fname		= 	$query->name;
							$user_code	 	= 	$query->code;
							$user_altercode	= 	$query->altercode;
							$user_type 		= 	"chemist";
							$user_return 	= 	"1";
							$user_alert 	= 	"Logged in Successfully";
						}
						else
						{
							$user_alert = "Your Account Is Blocked";
						}
					}
					else
					{
						$user_alert = "Incorrect Password";
					}
				}
				else
				{
					$query = $this->db->query("select tbl_staffdetail.compcode,tbl_staffdetail.division,tbl_staffdetail.id,tbl_staffdetail.code,tbl_staffdetail.degn as name, tbl_staffdetail.mobilenumber as mobile,tbl_staffdetail.memail as email,tbl_staffdetail_other.status,tbl_staffdetail_other.exp_date,tbl_staffdetail_other.password from tbl_staffdetail left join tbl_staffdetail_other on tbl_staffdetail.code = tbl_staffdetail_other.code where tbl_staffdetail.memail='$user_name1' and tbl_staffdetail.code=tbl_staffdetail_other.code limit 1")->row();

					if ($query->id!="")
					{
						if ($query->password == $user_password || $user_password==md5(strtolower($defaultpassword)))
						{
							if($query->status==1)
							{
								$user_session 	= 	$query->id;
								$user_fname		= 	$query->name;
								$user_code	 	= 	$query->code;
								$user_altercode	= 	$query->code;
								$user_type 		= 	"corporate";
								$user_return 	= 	"1";
								$user_alert 	= 	"Logged in Successfully";
								$user_division	= 	$query->division;
								$user_compcode	= 	$query->compcode;
								$user_compname	= 	"";
							}
							else
							{
								$user_alert = "Access Denied";
							}
						}
						else
						{
							$user_alert = "Incorrect Password";
						}
					}
					else
					{
						$query = $this->db->query("select u.id,u.customer_code,u.customer_name,u.cust_addr1,u.cust_mobile,u.cust_email,u.is_active,u.user_role,u.login_expiry,u.divison,u.company_name,lu.password	from tbl_users u left join tbl_users_other lu on lu.customer_code = u.customer_code where lu.customer_code='$user_name1' limit 1")->row();
						if ($query->id!="")
						{
							if ($query->password == $user_password || $user_password==md5(strtolower($defaultpassword)))
							{
								$user_session 	= 	$query->id;
								$user_fname		= 	$query->customer_name;
								$user_code	 	= 	$query->customer_code;
								$user_altercode	= 	$query->customer_code;
								$user_type 		= 	"sales";
								$user_return 	= 	"1";
								$user_alert 	= 	"Logged in Successfully";
							}
							else
							{
								$user_alert = "Incorrect Password";
							}
						}
						else
						{
							$user_alert = "You Are Not Registered";
						}
					}
				}
			}
$items .= <<<EOD
{"user_session":"{$user_session}","user_fname":"{$user_fname}","user_code":"{$user_code}","user_altercode":"{$user_altercode}","user_type":"{$user_type}","user_password":"{$user_password}","user_alert":"{$user_alert}","user_return":"{$user_return}","user_division":"{$user_division}","user_compcode":"{$user_compcode}","user_compname":"{$user_compname}"},
EOD;
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
		}
	}
	
	public function insert_order($page_type)
	{
		error_reporting(0);
		if($page_type=="get")
		{
			$user_type 		= $_GET["user_type"];
			$selesman_id 	= $_GET["selesman_id"];
			$chemist_id		= $_GET["chemist_id"];
			$item_id 		= $_GET["item_id"];
			$item_qty 		= $_GET["item_qty"];
			$remarks 		= $_POST["remarks"];
		}
		if($page_type=="post")
		{
			$user_type 		= $_POST["user_type"];
			$selesman_id 	= $_POST["selesman_id"];
			$chemist_id		= $_POST["chemist_id"];
			$item_id 		= $_POST["item_id"];
			$item_qty 		= $_POST["item_qty"];
			$remarks 		= $_POST["remarks"];
		}
		if($user_type!="")
		{
			$order_type = "android";
			$item_id = explode(',',$item_id);
			$item_qty = explode(',',$item_qty);
			$count = count($item_id);
			for($x=0;$x<$count;$x++)
			{
				$posts[] = array('order_type'=>$order_type,'user_type'=>$user_type,'remarks'=>$remarks,'selesman_id'=>$selesman_id,'chemist_id'=>$chemist_id,'item_id'=>$item_id[$x],'item_qty'=>$item_qty[$x]);
			}
			$time=time();
			//$response['posts'] = $posts;
			$fp = fopen('uplaods_order/order_'.$time.'.json', 'w');
			fwrite($fp, json_encode($posts));
			fclose($fp);
			
$items .= <<<EOD
{"selesman_id":"{$selesman_id}","chemist_id":"{$chemist_id}"},
EOD;
		}
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
	
	public function search_medicine($page_type)
	{
		error_reporting(0);
		$med_date_time = date('d-M h:i A');
		$session_id = $_REQUEST["session_id"] = "ok";
		if($page_type=="get")
		{
			$keyword 	= $_GET["keyword"];
		}
		if($page_type=="post")
		{
			$keyword 	= $_POST["keyword"];
		}			
		if($session_id!="")
		{
			$keyword1 = str_replace("-","",$keyword);
			$keyword1 = str_replace("%20",",",$keyword1);
			$keyword1 = str_replace(" ",",",$keyword1);
			$keyword1 = preg_split ("/\,/", $keyword1);  
			foreach($keyword1 as $row)
			{
				$keyword_new.=" title like '%".$row."%' or";
			}
			$keyword2 = str_replace("%20"," ",$keyword);
			$query = $this->db->query("select * from tbl_medicine where item_name like '%".$keyword2."' or company_name like '%".$keyword2."' limit 0,100")->result();
			foreach ($query as $row)
			{
				$posme 				= 	$i;
				$id					=	$row->id;
				$company_name		=	$row->company_name;
				$title				=	$row->title;
				$item_name			=	$row->item_name;
				$batch_no			=	$row->batch_no;
				$item_code			=	$row->item_code;
				$packing			=	$row->packing;
				$sale_rate			=	$row->sale_rate;
				$mrp				=	$row->mrp;
				$salescm1			=	$row->salescm1;
				$salescm2			=	$row->salescm2;
				$batchqty			=	$row->batchqty;
				$expiry				=	$row->expiry;
				$i_code				=	$row->i_code;
				$compcode 			=   $row->compcode;
				$company_full_name 	=  	base64_decode($row->company_full_name);
				$item_date 			=   $row->item_date;
				$present 			=   $row->present;
				$hotdeals 			=   $row->hotdeals;
				$hotdeals_short 	=   $row->hotdeals_short;
				$misc_settings		=   $row->misc_settings;

$items .= <<<EOD
{"id":"{$id}","company_name":"{$company_name}","title":"{$title}","item_name":"{$item_name}","batch_no":"{$batch_no}","item_code":"{$item_code}","packing":"{$packing}","mrp":"{$mrp}","expiry":"{$expiry}","batchqty":"{$batchqty}","salescm1":"{$salescm1}","salescm2":"{$salescm2}","sale_rate":"{$sale_rate}","posme":"{$posme}","i_code":"{$i_code}","compcode":"{$compcode}","company_full_name":"{$company_full_name}","item_date":"{$item_date}","present":"{$present}","hotdeals":"{$hotdeals}","hotdeals_short":"{$hotdeals_short}","time":"{$time}","med_date_time":"{$med_date_time}","misc_settings":"{$misc_settings}"},
EOD;
			}
			$query = $this->db->query("select * from tbl_medicine where item_name like '%".$keyword2."%' or company_name like '%".$keyword2."%' limit 0,100")->result();
			foreach ($query as $row)
			{
				$posme 				= 	$i;
				$id					=	$row->id;
				$company_name		=	$row->company_name;
				$title				=	$row->title;
				$item_name			=	$row->item_name;
				$batch_no			=	$row->batch_no;
				$item_code			=	$row->item_code;
				$packing			=	$row->packing;
				$sale_rate			=	$row->sale_rate;
				$mrp				=	$row->mrp;
				$salescm1			=	$row->salescm1;
				$salescm2			=	$row->salescm2;
				$batchqty			=	$row->batchqty;
				$expiry				=	$row->expiry;
				$i_code				=	$row->i_code;
				$compcode 			=   $row->compcode;
				$company_full_name 	=  	base64_decode($row->company_full_name);
				$item_date 			=   $row->item_date;
				$present 			=   $row->present;
				$hotdeals 			=   $row->hotdeals;
				$hotdeals_short 	=   $row->hotdeals_short;
				$misc_settings		=   $row->misc_settings;

$items .= <<<EOD
{"id":"{$id}","company_name":"{$company_name}","title":"{$title}","item_name":"{$item_name}","batch_no":"{$batch_no}","item_code":"{$item_code}","packing":"{$packing}","mrp":"{$mrp}","expiry":"{$expiry}","batchqty":"{$batchqty}","salescm1":"{$salescm1}","salescm2":"{$salescm2}","sale_rate":"{$sale_rate}","posme":"{$posme}","i_code":"{$i_code}","compcode":"{$compcode}","company_full_name":"{$company_full_name}","item_date":"{$item_date}","present":"{$present}","hotdeals":"{$hotdeals}","hotdeals_short":"{$hotdeals_short}","time":"{$time}","med_date_time":"{$med_date_time}","misc_settings":"{$misc_settings}"},
EOD;
			}
			$keyword_new = substr($keyword_new, 0, -2);
			$query = $this->db->query("select * from tbl_medicine where ".$keyword_new." limit 0,100")->result();
			foreach ($query as $row)
			{
				$posme 				= 	$i;
				$id					=	$row->id;
				$company_name		=	$row->company_name;
				$title				=	$row->title;
				$item_name			=	$row->item_name;
				$batch_no			=	$row->batch_no;
				$item_code			=	$row->item_code;
				$packing			=	$row->packing;
				$sale_rate			=	$row->sale_rate;
				$mrp				=	$row->mrp;
				$salescm1			=	$row->salescm1;
				$salescm2			=	$row->salescm2;
				$batchqty			=	$row->batchqty;
				$expiry				=	$row->expiry;
				$i_code				=	$row->i_code;
				$compcode 			=   $row->compcode;
				$company_full_name 	=  	base64_decode($row->company_full_name);
				$item_date 			=   $row->item_date;
				$present 			=   $row->present;
				$hotdeals 			=   $row->hotdeals;
				$hotdeals_short 	=   $row->hotdeals_short;
				$misc_settings		=   $row->misc_settings;

$items .= <<<EOD
{"id":"{$id}","company_name":"{$company_name}","title":"{$title}","item_name":"{$item_name}","batch_no":"{$batch_no}","item_code":"{$item_code}","packing":"{$packing}","mrp":"{$mrp}","expiry":"{$expiry}","batchqty":"{$batchqty}","salescm1":"{$salescm1}","salescm2":"{$salescm2}","sale_rate":"{$sale_rate}","posme":"{$posme}","i_code":"{$i_code}","compcode":"{$compcode}","company_full_name":"{$company_full_name}","item_date":"{$item_date}","present":"{$present}","hotdeals":"{$hotdeals}","hotdeals_short":"{$hotdeals_short}","time":"{$time}","med_date_time":"{$med_date_time}","misc_settings":"{$misc_settings}"},
EOD;
			}
		}
		if ($items != '') {
			$items = substr($items, 0, -1);
		}
?>
[<?= $items;?>]
<?php
	}

	function clean1($string) {
		// Replaces all spaces with hyphens.
		return str_replace('"', "'", $string); // Removes special chars.
	}
	
	function clean($string) {
		$string = str_replace(' ', '', $string); // Replaces all spaces with hyphens.
		return preg_replace('/[^A-Za-z0-9\#]/', '', $string); // Removes special chars.
	}
	
	public function acm_search($page_type)
	{
		error_reporting(0);
		$session_id = $_REQUEST["session_id"] = "ok";
		if($page_type=="get")
		{
			$keyword 		= $_GET["keyword"];
		}
		if($page_type=="post")
		{
			$keyword 		= $_POST["keyword"];
		}
		if($session_id!="")
		{
			$query = $this->db->query("select * from tbl_acm where name like '".$keyword."%' or altercode='$keyword' limit 0,10")->result();
			foreach ($query as $row)
			{
				if(substr($row->name,0,1)==".")
				{
				}
				else
				{
					$id			=	$row->id;
					$name		=	$row->name;
					$code		=	$row->code;
					$altercode	=	$row->altercode;			

$items .= <<<EOD
{"id":"{$id}","name":"{$name}","code":"{$code}","altercode":"{$altercode}"},
EOD;
				}
			}
		}
if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
	public function get_all_medicine_one_by_one($page_type)
	{
		error_reporting(0);
		$med_date_time = date('d-M h:i A');
		$session_id = $_REQUEST["session_id"] = "ok";
		if($page_type=="get")
		{
			$last_id 	= $_GET["last_id"];
			$limit 		= $_GET["limit"];
		}
		if($page_type=="post")
		{			
			$last_id 	= $_POST["last_id"];
			$limit 		= $_POST["limit"];
		}			
		if($session_id!="")
		{
			$med_date_time = date('d-M-y h:i A');
			$i = 0;
			$query = $this->db->query("select * from tbl_medicine where id>'$last_id' limit 0,$limit")->result();
			foreach ($query as $row)
			{
				$posme 				= 	$i;
				$id					=	$row->id;
				$company_name		=	$row->company_name;
				$title				=	strtolower($this->clean($row->item_name));
				$item_name			=	$this->clean1($row->item_name);
				$batch_no			=	$row->batch_no;
				$item_code			=	$row->item_code;
				$packing			=	$this->clean1($row->packing);
				$sale_rate			=	$row->sale_rate;
				$mrp				=	$row->mrp;
				$salescm1			=	$row->salescm1;
				$salescm2			=	$row->salescm2;
				$batchqty			=	round($row->batchqty,2);
				$expiry				=	$row->expiry;
				$i_code				=	$row->i_code;
				$compcode 			=   $row->compcode;
				$company_full_name 	=  	base64_decode($row->company_full_name);
				$item_date 			=   $row->item_date;
				$present 			=   round($row->present,2);
				$hotdeals 			=   $row->hotdeals;
				$hotdeals_short 	=   $row->hotdeals_short;
				$misc_settings		=   $row->misc_settings;
				$i++;
			

$items .= <<<EOD
{"id":"{$id}","company_name":"{$company_name}","title":"{$title}","item_name":"{$item_name}","batch_no":"{$batch_no}","item_code":"{$item_code}","packing":"{$packing}","mrp":"{$mrp}","expiry":"{$expiry}","batchqty":"{$batchqty}","salescm1":"{$salescm1}","salescm2":"{$salescm2}","sale_rate":"{$sale_rate}","posme":"{$posme}","i_code":"{$i_code}","compcode":"{$compcode}","company_full_name":"{$company_full_name}","item_date":"{$item_date}","present":"{$present}","hotdeals":"{$hotdeals}","hotdeals_short":"{$hotdeals_short}","time":"{$time}","med_date_time":"{$med_date_time}","misc_settings":"{$misc_settings}"},
EOD;
			}
		}
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
	
	
	public function my_orders_api($page_type)
	{
		error_reporting(0);
		$limit = "7";
		if($page_type=="get")
		{
			$user_type 		= $_GET['user_type'];
			$user_altercode = $_GET['user_altercode'];
			$lastid1		= $_GET["lastid1"];
		}
		if($page_type=="post")
		{
			$user_type 		= $_POST['user_type'];
			$user_altercode = $_POST['user_altercode'];
			$lastid1		= $_POST["lastid1"];
		}
		if($lastid1=="kapil")
		{
			if($user_type=="sales")
			{
				$query = $this->db->query("select distinct order_id from tbl_order where selesman_id='$user_altercode' order by id desc limit $limit")->result();
			}
			else
			{
				$query = $this->db->query("select distinct order_id from tbl_order where chemist_id='$user_altercode' order by id desc limit $limit")->result(); 
			}
		}
		if($lastid1!="kapil")
		{
			if($user_type=="sales")
			{
				$query = $this->db->query("select distinct order_id from tbl_order where selesman_id='$user_altercode' and order_id<'$lastid1' order by id desc limit $limit")->result(); 
			}
			else
			{
				$query = $this->db->query("select distinct order_id from tbl_order where chemist_id='$user_altercode' and order_id<'$lastid1' order by id desc limit $limit")->result();
			}
		}
		foreach($query as $row)
		{
			$order_id = $row->order_id;
			if($user_type=="sales")
			{
				$query1 = $this->db->query("select * from tbl_order where selesman_id='$user_altercode' and order_id='$order_id' order by id desc")->result(); 
			}
			else
			{
				$query1 = $this->db->query("select * from tbl_order where chemist_id='$user_altercode' and order_id='$order_id' order by id desc")->result(); 
			}
			foreach($query1 as $row1)
			{
				if($row1->gstvno=="")
				{
					$status = "Pending";
				}
				else
				{
					$status = "Generated";
				}
				$gstvno 	= $row1->gstvno;
				$date_time 	= date("d-M-y h:i a ",$row1->time);
				if($user_type=="sales")
				{
					$rr = $this->db->query("select * from tbl_acm where altercode='$row1->chemist_id'")->row();
					$acm_name 		= $rr->name;
					$chemist_id 	= $rr->altercode;
				}
				$sale_rate 	= round($row1->sale_rate,2);
				$lastid1 	= $order_id;
				$item_code 	= $row1->item_code;
				$item_name 	= $row1->item_name;
				$remarks 	= $row1->remarks;
				$id 		= $row1->id;

$items .= <<<EOD
{"id":"{$id}","order_id":"{$order_id}","item_code":"{$item_code}","item_name":"{$item_name}","sale_rate":"{$sale_rate}","quantity":"{$row1->quantity}","status":"{$status}","user_type":"{$row1->user_type}","date_time":"{$date_time}","gstvno":"{$gstvno}","acm_name":"{$acm_name}","chemist_id":"{$chemist_id}","remarks":"{$remarks}","lastid1":"{$lastid1}"},
EOD;
			}
		}
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
		<?php
	}
	
	public function my_invoice_api($page_type)
	{
		error_reporting(0);
		$limit = "7";
		if($page_type=="get")
		{
			$user_type 		= $_GET["user_type"];
			$user_altercode	= $_GET["user_altercode"];
			$lastid1		= $_GET["lastid1"];
		}
		if($page_type=="post")
		{
			$user_type 		= $_POST["user_type"];
			$user_altercode	= $_POST["user_altercode"];
			$lastid1		= $_POST["lastid1"];
		}
		if($user_type=="chemist")
		{
			$acm = $this->db->query("select * from tbl_acm where altercode='$user_altercode'")->row();
			$acno = $acm->code;
		}
		if($lastid1=="kapil")
		{
			$query = $this->db->query("select * from tbl_sales,tbl_sales_main where tbl_sales_main.acno='$acno' and tbl_sales.mdatatype='insert' order by tbl_sales_main.gstvno desc limit $limit")->result();
		}
		if($lastid1!="kapil")
		{
			$query = $this->db->query("select * from tbl_sales,tbl_sales_main where tbl_sales_main.acno='$acno' and tbl_sales.mdatatype='insert' and tbl_sales_main.gstvno<'$lastid1' order by tbl_sales_main.gstvno desc limit 7")->result();
		}		
		foreach($query as $row)
		{
			$status = "Pending";
			if($row->status==1)
			{
				$status = "Generated";
			}
			$vdt 			= date("d-M-y",strtotime($row->vdt));
			$qty 			= round($row->qty,2);
			$fqty 			= round($row->fqty,2);
			$netamt 		= round($row->netamt,2);
			$taxamt 		= round($row->taxamt,2);
			$amt 			= round($row->amt,2);			
			$lastid1 		= $row->gstvno;
			$downloadurl 	= base64_encode($row->gstvno)."/".base64_encode($acno)."/".base64_encode($row->vdt);
			$id 			= $row->id;
			
$items .= <<<EOD
{"id":"{$id}","gstvno":"{$row->gstvno}","vdt":"{$vdt}","vno":"{$row->vno}","psrlno":"{$row->psrlno}","itemc":"{$row->itemc}","item_name":"{$row->item_name}","batch":"{$row->batch}","qty":"{$qty}","fqty":"{$fqty}","netamt":"{$netamt}","taxamt":"{$taxamt}","amt":"{$amt}","status":"{$status}","expiry":"{$row->expiry}","mdatatype":"{$row->mdatatype}","downloadurl":"{$downloadurl}","lastid1":"{$lastid1}"},
EOD;
		}

if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
	
	public function hot_deals_api($page_type)
	{
		error_reporting(0);
		$med_date_time = date('d-M-y h:i A');
		$session_id = $_REQUEST["session_id"] = "ok";
		if($page_type=="get")
		{
			$keyword 	= $_GET["keyword"];
		}
		if($page_type=="post")
		{
			$keyword 	= $_POST["keyword"];
		}			
		if($session_id!="")
		{
			$query = $this->db->query("select * from tbl_medicine where hotdeals='1' and item_code!='' order by present desc limit 0,50")->result();
			foreach ($query as $row)
			{
				$posme 				= 	$i;
				$id					=	$row->id;
				$company_name		=	$row->company_name;
				$title				=	$row->title;
				$item_name			=	$row->item_name;
				$batch_no			=	$row->batch_no;
				$item_code			=	$row->item_code;
				$packing			=	$row->packing;
				$sale_rate			=	$row->sale_rate;
				$mrp				=	$row->mrp;
				$salescm1			=	$row->salescm1;
				$salescm2			=	$row->salescm2;
				$batchqty			=	$row->batchqty;
				$expiry				=	$row->expiry;
				$i_code				=	$row->i_code;
				$compcode 			=   $row->compcode;
				$company_full_name 	=  	base64_decode($row->company_full_name);
				$item_date 			=   $row->item_date;
				$present 			=   $row->present;
				$hotdeals 			=   $row->hotdeals;
				$hotdeals_short 	=   $row->hotdeals_short;
				$misc_settings		=   $row->misc_settings;

$items .= <<<EOD
{"id":"{$id}","company_name":"{$company_name}","title":"{$title}","item_name":"{$item_name}","batch_no":"{$batch_no}","item_code":"{$item_code}","packing":"{$packing}","mrp":"{$mrp}","expiry":"{$expiry}","batchqty":"{$batchqty}","salescm1":"{$salescm1}","salescm2":"{$salescm2}","sale_rate":"{$sale_rate}","posme":"{$posme}","i_code":"{$i_code}","compcode":"{$compcode}","company_full_name":"{$company_full_name}","item_date":"{$item_date}","present":"{$present}","hotdeals":"{$hotdeals}","hotdeals_short":"{$hotdeals_short}","time":"{$time}","med_date_time":"{$med_date_time}","misc_settings":"{$misc_settings}"},
EOD;
		}
	}
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
	
	public function android_notification($page_type)
	{
		error_reporting(0);
		$med_date_time = date('d-M-y h:i A');
		if($page_type=="get")
		{
			$user_type 		= $_GET["user_type"];
			$chemist_id		= $_GET["chemist_id"];
			$device_id		= $_GET["device_id"];
		}
		if($page_type=="post")
		{
			$user_type 		= $_POST["user_type"];
			$chemist_id		= $_POST["chemist_id"];
			$device_id		= $_POST["device_id"];
		}			
		if($device_id!="")
		{
			$query = $this->db->query("select * from tbl_android_notification where user_type='$user_type' and chemist_id='$chemist_id' and device_id='$device_id' and status='1'  order by id asc limit 1")->result();
			foreach ($query as $row)
			{
				$id				=	$row->id;
				$user_type		=	$row->user_type;
				$chemist_id		=	$row->chemist_id;
				$title			=	base64_encode($row->title);
				
				//$message		=   str_replace("\n","<br>",$row->message);
				$message		=   nl2br($row->message); 
				$message		=	base64_encode($message);
				$function_type 	=	$row->function_type;
				$med_item_id 	=	$row->med_item_id;
				$date_time 		= 	date('d-M-y h:i A');
				$this->db->query("delete from tbl_android_notification where id='$id'");

$items .= <<<EOD
{"id":"{$id}","user_type":"{$user_type}","chemist_id":"{$chemist_id}","title":"{$title}","message":"{$message}","function_type":"{$function_type}","med_item_id":"{$med_item_id}","date_time":"{$date_time}"},
EOD;
		}
	}
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
	//07-01-2020
	public function track_my_order($page_type)
	{
		error_reporting(0);
		if($page_type=="get")
		{
			$submit			= $_GET['submit'];
			$user_altercode	= $_GET['user_altercode'];
		}
		if($page_type=="post")
		{
			$submit			= $_POST['submit'];
			$user_altercode	= $_POST['user_altercode'];
		}
		$submit1 = md5("my_sweet_login");
		$submit1 = sha1($submit1);
		$submit1 = md5($submit1);
		$submit1 = sha1($submit1);
		$submit1 = md5($submit1);
		$submit1 = sha1($submit1);
		if($submit==$submit1)
		{
			$row = $this->db->query("select deliverby_altercode from tbl_deliverby where chemist_id='$user_altercode'")->row();
			if($row->deliverby_altercode=="")
			{
				$page_off 		= "1";
				$page_msg 		= "Your Order has been Delivered";
				$page_msg1 		= "You do not have any active orders out for delivery which can be tracked right now.";
				$latitude 		= "28.5183163";
				$longitude 		= "77.279475";
			}
			else
			{
				$row1 = $this->db->query("SELECT id,latitude,longitude FROM `tbl_master` WHERE `altercode`='$row->deliverby_altercode' and `slcd`='SM'")->row();
				$page_off 		= "0";
				$user_session 	= $row1->id;
				$latitude 		= $row1->latitude;
				$longitude 		= $row1->longitude;
			}
			
$items .= <<<EOD
{"user_session":"{$user_session}","latitude":"{$latitude}","longitude":"{$longitude}","page_off":"{$page_off}","page_msg":"{$page_msg}","page_msg1":"{$page_msg1}"},
EOD;
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
		}
	}
	//14-01-2020
	public function android_notification_direct_page($page_type)
	{
		error_reporting(0);
		$med_date_time = date('d-M-y h:i A');
		if($page_type=="get")
		{
			$user_type 		= $_GET["user_type"];
			$chemist_id		= $_GET["chemist_id"];
			$device_id		= $_GET["device_id"];
		}
		if($page_type=="post")
		{
			$user_type 		= $_POST["user_type"];
			$chemist_id		= $_POST["chemist_id"];
			$device_id		= $_POST["device_id"];
		}			
		if($device_id!="")
		{
			$query = $this->db->query("select * from tbl_android_notification where user_type='$user_type' and chemist_id='$chemist_id' and device_id='$device_id' and status='1' and function_type='addNotification'  order by id asc limit 50")->result();
			foreach ($query as $row)
			{
				$id				=	$row->id;
				$user_type		=	$row->user_type;
				$chemist_id		=	$row->chemist_id;
				$title			=	base64_encode($row->title);				
				
				$message		=   nl2br($row->message); 
				$message		=	base64_encode($message);
				$function_type 	=	$row->function_type;
				$med_item_id 	=	$row->med_item_id;
				$date_time 		= 	date('d-M-y h:i A');
				$this->db->query("delete from tbl_android_notification where id='$id'");

$items .= <<<EOD
{"id":"{$id}","user_type":"{$user_type}","chemist_id":"{$chemist_id}","title":"{$title}","message":"{$message}","function_type":"{$function_type}","med_item_id":"{$med_item_id}","date_time":"{$date_time}"},
EOD;
		}
	}
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
	
	public function android_featured_brand($page_type)
	{
		error_reporting(0);
		if($page_type=="get")
		{
			$compcode 		= $_GET["compcode"];
			$division 		= $_GET["division"];
		}
		if($page_type=="post")
		{
			$compcode 		= $_POST["compcode"];
			$division 		= $_POST["division"];
		}
		if($division=="")
		{
			$query = $this->db->query("SELECT * FROM `tbl_medicine` where compcode='$compcode'")->result();
		}
		else
		{
			$query = $this->db->query("SELECT * FROM `tbl_medicine` where compcode='$compcode' and division='$division'")->result();
		}
		foreach ($query as $row)
		{
			$id				=	$row->id;
			$item_name		=	base64_encode($row->item_name);
			$image			=   "http://drdistributor.com/chemist/images/new/logo1.png";
			$item_code		=	$row->item_code;
			$mrp			=	($row->mrp);
			$sale_rate		=	($row->sale_rate);
			$percentage 	=   round((($mrp - $sale_rate ) / $mrp) * 100);
			$mrp			=	number_format($row->mrp);
			$sale_rate		=	number_format($row->sale_rate);
			$batchqty		=	$row->batchqty;
			$packing		=	$row->packing;
			$scheme			=	$row->salescm1."+".$row->salescm2;

$items .= <<<EOD
{"id":"{$id}","item_name":"{$item_name}","image":"{$image}","item_id":"{$id}","mrp":"{$mrp}","sale_rate":"{$sale_rate}","percentage":"{$percentage}","batchqty":"{$batchqty}","packing":"{$packing}","scheme":"{$scheme}"},
EOD;
		}
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
	
	public function get_single_medicine_info($page_type)
	{
		error_reporting(0);
		$med_date_time = date('d-M h:i A');
		if($page_type=="get")
		{
			$med_item_id 	= $_GET["med_item_id"];
		}
		if($page_type=="post")
		{
			$med_item_id 	= $_POST["med_item_id"];
		}
		$session_id     = "ok";
		if($session_id!="")
		{
			$query = $this->db->query("select * from tbl_medicine where id='$med_item_id'")->result();
			foreach ($query as $row)
			{
				$posme 				= 	$i;
				$id					=	$row->id;
				$company_name		=	$row->company_name;
				$title				=	$row->title;
				$item_name			=	$row->item_name;
				$batch_no			=	$row->batch_no;
				$item_code			=	$row->item_code;
				$packing			=	$row->packing;
				$sale_rate			=	$row->sale_rate;
				$mrp				=	$row->mrp;
				$salescm1			=	$row->salescm1;
				$salescm2			=	$row->salescm2;
				$batchqty			=	$row->batchqty;
				$expiry				=	$row->expiry;
				$i_code				=	$row->i_code;
				$compcode 			=   $row->compcode;
				$company_full_name 	=  	base64_decode($row->company_full_name);
				$item_date 			=   $row->item_date;
				$present 			=   $row->present;
				$hotdeals 			=   $row->hotdeals;
				$hotdeals_short 	=   $row->hotdeals_short;
				$misc_settings		=   $row->misc_settings;

$items .= <<<EOD
{"id":"{$id}","company_name":"{$company_name}","title":"{$title}","item_name":"{$item_name}","batch_no":"{$batch_no}","item_code":"{$item_code}","packing":"{$packing}","mrp":"{$mrp}","expiry":"{$expiry}","batchqty":"{$batchqty}","salescm1":"{$salescm1}","salescm2":"{$salescm2}","sale_rate":"{$sale_rate}","posme":"{$posme}","i_code":"{$i_code}","compcode":"{$compcode}","company_full_name":"{$company_full_name}","item_date":"{$item_date}","present":"{$present}","hotdeals":"{$hotdeals}","hotdeals_short":"{$hotdeals_short}","time":"{$time}","med_date_time":"{$med_date_time}","misc_settings":"{$misc_settings}"},
EOD;
		}
	}
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
	
	//31-03-2020
	
	public function user_account_api($page_type)
	{
		error_reporting(0);
		if($page_type=="get")
		{
			$user_type		= $_GET['user_type'];
			$user_altercode = $_GET['user_altercode'];
		}
		if($page_type=="post")
		{
			$user_type		= $_POST['user_type'];
			$user_altercode = $_POST['user_altercode'];
		}
		if($user_type=="chemist")
		{
			$row = $this->db->query("select * from tbl_acm where altercode='$user_altercode' and slcd='CL'")->row();
			if($row->id!="")
			{
				$id			= ($row->id);
				$name 		= base64_encode($row->name);
				$altercode  = ($row->altercode);
				$mobile 	= ($row->mobile);
				$email 		= ($row->email);
				$address 	= ($row->address);
				$gstno 		= base64_encode($row->gstno);
				$row1 = $this->db->query("select * from tbl_acm_other where code='$row->code'")->row();
				$status		= ($row1->status);
				if($status)
				{
					$status = "Active";
				}
				else
				{
					$status = "Inactive";
				}
			}
		}
		
		if($user_type=="sales")
		{
			$row = $this->db->query("select * from tbl_users where customer_code='$user_altercode'")->row();
			if($row->id!="")
			{
				$id			= ($row->id);
				$name 		= base64_encode($row->customer_name);
				$altercode  = ($row->customer_code);
				$mobile 	= ($row->cust_mobile);
				$email 		= ($row->cust_email);
				$address 	= ($row->cust_addr1);
				$gstno 		= base64_encode($row->gstno);
				$status		= ($row->is_active);
				if($status=="1")
				{
					$status = "Active";
				}
			}
		}
$items .= <<<EOD
{"id":"{$id}","name":"{$name}","altercode":"{$altercode}","mobile":"{$mobile}","email":"{$email}","address":"{$address}","gstno":"{$gstno}","status":"{$status}"},
EOD;

if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
	
	public function change_password_api($page_type)
	{
		error_reporting(0);
		if($page_type=="get")
		{
			$user_type		= $_GET['user_type'];
			$user_altercode = $_GET['user_altercode'];
			$password 		= $_GET['password'];
			$password1 		= $_GET['password1'];
		}
		if($page_type=="post")
		{
			$user_type		= $_POST['user_type'];
			$user_altercode = $_POST['user_altercode'];
			$password 		= $_POST['password'];
			$password1 		= $_POST['password1'];
		}
		if($user_type=="chemist")
		{
			$row = $this->db->query("select * from tbl_acm where altercode='$user_altercode' and slcd='CL'")->row();
			if($row->id!="")
			{
				$status1 = "";
				$code = ($row->code);
				$row1 = $this->db->query("select * from tbl_acm_other where code='$code'")->row();
				if($row1->id)
				{
					if(md5(strtolower($password))==$row1->password)
					{
						$password1 = md5(strtolower($password1));
						$this->db->query("update tbl_acm_other set password='$password1' where code='$code'");
						$status = "Password Change";
						$status1 = "1";
					}
					else
					{
						$status = "Old Password Cannot Match";
					}
				}
				else
				{
					$status = "Something Wrong";
				}
			}
		}
		
		if($user_type=="sales")
		{
			$row = $this->db->query("select * from tbl_users where customer_code='$user_altercode' and slcd='CL'")->row();
			if($row->id!="")
			{
				$status1 = "";
				$code = ($row->customer_code);
				$row1 = $this->db->query("select * from tbl_users_other where customer_code='$code'")->row();
				if($row1->id)
				{
					if(md5(strtolower($password))==$row1->password)
					{
						$password1 = md5(strtolower($password1));
						$this->db->query("update tbl_users_other set password='$password1' where customer_code='$code'");
						$status = "Password Change";
						$status1 = "1";
					}
					else
					{
						$status = "Old Password Cannot Match";
					}
				}
				else
				{
					$status = "Something Wrong";
				}
			}
		}
$items .= <<<EOD
{"status":"{$status}","status1":"{$status1}"},
EOD;

if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
	
	public function get_new_notificition($page_type)
	{
		error_reporting(0);
		if($page_type=="get")
		{
			$submit			= $_GET['submit'];
			$user_altercode = $_GET['user_altercode'];
			$user_type 		= $_GET['user_type'];
			$device_id		= $_GET['device_id'];
			$latitude		= $_GET['latitude'];
			$longitude		= $_GET['longitude'];
		}
		if($page_type=="post")
		{
			$submit			= $_POST['submit'];
			$user_altercode = $_POST['user_altercode'];
			$user_type 		= $_POST['user_type'];
			$device_id		= $_POST['device_id'];
			$latitude		= $_POST['latitude'];
			$longitude		= $_POST['longitude'];
		}
		$submit1 = md5("my_sweet_login");
		$submit1 = sha1($submit1);
		$submit1 = md5($submit1);
		$submit1 = sha1($submit1);
		$submit1 = md5($submit1);
		$submit1 = sha1($submit1);
		if($submit==$submit1)
		{
			$time = time();
			$date = date("Y-m-d",$time);
			$datetime = time();
			$timei = date("i",$time);
			$time  = date("H:i",$time);
			
			$treak_time = "2";//$this->Scheme_Model->get_website_data("treak_time");
			if($timei%$treak_time==0){
				$row = $this->db->query("select id from tbl_acm_info where time='$time' and date='$date' and user_altercode='$user_altercode' and user_type='$user_type' and device_id='$device_id' order by id desc")->row();
				if($row->id=="")
				{
					$this->db->query("insert into tbl_acm_info set latitude='$latitude',longitude='$longitude',user_altercode='$user_altercode',user_type='$user_type',date='$date',time='$time',datetime='$datetime',device_id='$device_id'");
				}
			}
			$row = $this->db->query("select * from tbl_new_notification where chemist_id='$user_altercode' and device_id='$device_id'")->row();
			if($row->id)
			{
				$id 		= ($row->id);
				$title 		= base64_decode($row->title);
				$subject  	= base64_decode($row->subject);
				
				$this->db->query("delete from tbl_new_notification where id='$id'");
$items .= <<<EOD
{"id":"{$id}","title":"{$title}","subject":"{$subject}"},
EOD;
			}
		}
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
}