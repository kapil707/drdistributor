<?php header("Content-type: application/json; charset=utf-8");
defined('BASEPATH') OR exit('No direct script access allowed');
class Api_android_version extends CI_Controller {
	public function api_android_version_check()
	{
		error_reporting(0);
		$device_id		= $_POST["device_id"];
		$user_type 		= $_POST["user_type"];
		$chemist_id		= $_POST["chemist_id"];
		$versioncode	= $_POST["versioncode"];
		$time			= time();
		$date			= date("Y-m-d");;
		$row = $this->db->query("select id from tbl_android_device_id where device_id='$device_id' and user_type='$user_type' and chemist_id='$chemist_id'")->row();
		if($row->id=="")
		{
			$this->db->query("insert into tbl_android_device_id set device_id='$device_id',user_type='$user_type',chemist_id='$chemist_id',versioncode='$versioncode',time='$time',date='$date'");
		}
		else
		{
			$this->db->query("update tbl_android_device_id set versioncode='$versioncode',time='$time' where device_id='$device_id' and user_type='$user_type' and chemist_id='$chemist_id'");
		}
		$android_versioncode = $this->Scheme_Model->get_website_data("android_versioncode");
		$version = $android_versioncode;
$items .= <<<EOD
{"version":"{$version}"},
EOD;
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
[<?= $items;?>]
<?php
	}
}