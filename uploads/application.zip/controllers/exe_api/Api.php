<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Api extends CI_Controller {
	public function index()
	{
		$time = time();
		$this->db->query("update tbl_exe_info set time='$time' where exe='s1'");
		
		error_reporting(0);
		$x = "";
		$data = json_decode(file_get_contents('php://input'),true);
		$items = $data["items"];
		foreach($items as $ks)
		{
			$gstvno 		= ($ks["gstvno"]);
			$vdt 			= ($ks["vdt"]);
			$deliverby 		= ($ks["deliverby"]);
			$vno 			= ($ks["vno"]);
			$acno 			= ($ks["acno"]);
			
			$deliverby_altercode = (int)$deliverby;
			
			$row = $this->db->query("SELECT altercode FROM `tbl_acm` WHERE `code`='$acno'")->row();
			if($row->altercode!="")
			{
				$chemist_id = $row->altercode;
				
				$dt = array(
				'gstvno'=>$gstvno,
				'vdt'=>$vdt,
				'deliverby'=>$deliverby,
				'vno'=>$vno,
				'acno'=>$acno,
				'chemist_id'=>$chemist_id,
				'deliverby_altercode'=>$deliverby_altercode,
				);
				$x = $this->Scheme_Model->insert_fun("tbl_deliverby",$dt);
			}
		}
		if($x)
		{
?>update online_web_sales_imports set status3='2' where vno='<?php echo $vno ?>' and vdt='<?php echo $vdt ?>';
<?php
		}
	}
}