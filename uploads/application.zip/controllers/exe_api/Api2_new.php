<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Api2_new extends CI_Controller {
	public function index()
	{
		$time = time();
		$this->db->query("update tbl_exe_info set time='$time' where exe='s2'");
		
		$myquery = "";
		$x = "0";
		error_reporting(0);		$data = json_decode(file_get_contents('php://input'),true);
		$items = $data["items"];
		foreach($items as $ks)
		{
			$query	= base64_decode($ks["query"]);
			$query1	= ($ks["query1"]);
			
			$this->db->query($query);			
			//$myquery.= "update online_web_items_imports set status2='1' where i_code='$i_code'; ";
		}
		if($query1!="")
		{
			echo $query1;
		}
	}	
	public function delete_all_rec()
	{
		error_reporting(0);
		/*18-01-2020*/
		$x = $this->db->query("TRUNCATE TABLE tbl_pending_order_medicine");
		
		$x = $this->db->query("TRUNCATE TABLE tbl_medicine");
		if($x)
		{
			echo "ok";
		}
	}
	public function delete_all_acm()
	{
		error_reporting(0);
		$x = $this->db->query("TRUNCATE TABLE tbl_acm");
		if($x)
		{
			echo "ok";
		}
	}	
	public function upload_all_acm()
	{
		$time = time();
		$this->db->query("update tbl_exe_info set time='$time' where exe='s2'");
		
		error_reporting(0);
		$myquery = "";
		$data = json_decode(file_get_contents('php://input'),true);
		$items = $data["items"];
		foreach($items as $ks)
		{
			$code			= base64_decode($ks["code"]);
			$altercode		= base64_decode($ks["altercode"]);
			$groupcode		= base64_decode($ks["groupcode"]);
			$name			= base64_decode($ks["name"]);
			$type	 		= base64_decode($ks["type"]);
			$trimname 		= base64_decode($ks["trimname"]);
			$address		= ($ks["address"]);
			$address1		= ($ks["address1"]);
			$address2 		= ($ks["address2"]);
			$address3		= ($ks["address3"]);
			$telephone 		= base64_decode($ks["telephone"]);
			$telephone1		= base64_decode($ks["telephone1"]);
			$mobile 		= base64_decode($ks["mobile"]);
			$email 			= base64_decode($ks["email"]);
			$gstno 			= base64_decode($ks["gstno"]);
			$status 		= base64_decode($ks["status"]);
			$statecode 		= base64_decode($ks["statecode"]);
			$invexport 		= base64_decode($ks["invexport"]);
			$slcd 			= base64_decode($ks["slcd"]);

			$dt = array(
			'code'=>$code,
			'altercode'=>$altercode,
			'groupcode'=>$groupcode,
			'name'=>$name,
			'type'=>$type,
			'trimname'=>$trimname,
			'address'=>$address,
			'address1'=>$address1,
			'address2'=>$address2,
			'address3'=>$address3,
			'telephone'=>$telephone,
			'telephone1'=>$telephone1,
			'mobile'=>$mobile,
			'email'=>$email,
			'gstno'=>$gstno,
			'status'=>$status,
			'statecode'=>$statecode,
			'invexport'=>$invexport,
			'slcd'=>$slcd,
			);
			$q = $this->db->query("select id from tbl_acm where code='$code'")->row();
			if($q->id=="")
			{
				$x = $this->Scheme_Model->insert_fun("tbl_acm",$dt);				
				$status = "1";
				$exp_date = "2021-01-01";			
				$qr = $this->db->query("select * from tbl_acm_other where code='$code'")->row();
				if($qr->id=="")
				{
					$x = $this->db->query("insert into tbl_acm_other set code='$code',status='$status',exp_date='$exp_date'");
				}
			}
			else
			{
				$where = array('code'=>$code);
				$x = $this->Scheme_Model->edit_fun("tbl_acm",$dt,$where);
			}		
			$myquery.= "update online_web_acm set status2='1' where code='$code'; ";
		}
		if($myquery!="")
		{			echo $myquery;
		}
	}
	public function delete_all_staff()
	{
		error_reporting(0);
		$x = $this->db->query("TRUNCATE TABLE tbl_staffdetail");
		if($x)
		{
			echo "ok";
		}
	}
	public function upload_all_staff()
	{
		$time = time();
		$this->db->query("update tbl_exe_info set time='$time' where exe='s2'");
		
		error_reporting(0);
		$myquery = "";
		$data = json_decode(file_get_contents('php://input'),true);
		$items = $data["items"];
		foreach($items as $ks)
		{
			$code			= base64_decode($ks["code"]);
			$compcode		= base64_decode($ks["compcode"]);
			$staffname 		= base64_decode($ks["staffname"]);
			$degn			= base64_decode($ks["degn"]);
			$mobilenumber	= base64_decode($ks["mobilenumber"]);
			$division 		= base64_decode($ks["division"]);
			$memail 		= base64_decode($ks["memail"]);
			$slcd 			= base64_decode($ks["slcd"]);
			$automail		= base64_decode($ks["automail"]);
			$staffid 		= base64_decode($ks["staffid"]);
			$staffpwd		= base64_decode($ks["staffpwd"]);
			$withsalerep 	= base64_decode($ks["withsalerep"]);
			$salerepdt 		= base64_decode($ks["salerepdt"]);
			$withcustsale 	= base64_decode($ks["withcustsale"]);
			$custrepdt 		= base64_decode($ks["custrepdt"]);
			$branchstatus 	= base64_decode($ks["branchstatus"]);
			$maxosamt 		= base64_decode($ks["maxosamt"]);
			$maxosinv 		= base64_decode($ks["maxosinv"]);
			$snsrepdt 		= base64_decode($ks["snsrepdt"]);
			$bank 			= base64_decode($ks["bank"]);
			$chqno 			= base64_decode($ks["chqno"]);
			$company_full_name 	= base64_decode($ks["company_full_name"]);$comp_altercode 	= base64_decode($ks["comp_altercode"]);		
			$staffname 	= $this->clean1($staffname);
			$degn 	= $this->clean1($degn);
			$company_full_name 	= $this->clean1($company_full_name);	

			$dt = array(
			'code'=>$code,
			'compcode'=>$compcode,
			'staffname'=>$staffname,
			'degn'=>$degn,
			'mobilenumber'=>$mobilenumber,
			'division'=>$division,
			'memail'=>$memail,
			'slcd'=>$slcd,
			'automail'=>$automail,
			'staffid'=>$staffid,
			'staffpwd'=>$staffpwd,
			'withsalerep'=>$withsalerep,
			'salerepdt'=>$salerepdt,
			'withcustsale'=>$withcustsale,
			'custrepdt'=>$custrepdt,
			'branchstatus'=>$branchstatus,
			'maxosamt'=>$maxosamt,
			'maxosinv'=>$maxosinv,
			'snsrepdt'=>$snsrepdt,
			'bank'=>$bank,
			'chqno'=>$chqno,
			'company_full_name'=>$company_full_name,
			'comp_altercode'=>$comp_altercode, 
			);			
			$q = $this->db->query("select id from tbl_staffdetail where code='$code'")->row();
			if($q->id=="")
			{
				$x = $this->Scheme_Model->insert_fun("tbl_staffdetail",$dt);
				$status 	= "0";
				$exp_date 	= "2021-01-01";
				$time 		= time();
				$daily_date = date("Y-m-d", $time);
				$monthly    = date("m", $time);		
				$qr = $this->db->query("select * from tbl_staffdetail_other where code='$code'")->row();
				if($qr->id=="")
				{
					$x = $this->db->query("insert into tbl_staffdetail_other set code='$code',status='$status',exp_date='$exp_date',daily_date='$daily_date',monthly='$monthly'");
				}
			}
			else
			{
				$where = array('code'=>$code);
				$x = $this->Scheme_Model->edit_fun("tbl_staffdetail",$dt,$where);
			}
			$myquery.= "update online_web_staff set status2='1' where code='$code'; ";
		}
		if($myquery!="")
		{
			echo $myquery;
		}
	}
	
	public function delete_all_compjoin()
	{
		error_reporting(0);
		$x = $this->db->query("TRUNCATE TABLE tbl_compjoin");
		if($x)
		{
			echo "ok";
		}
	}

	public function upload_all_compjoin()
	{
		$time = time();
		$this->db->query("update tbl_exe_info set time='$time' where exe='s2'");
		
		error_reporting(0);
		$myquery = "";
		$data = json_decode(file_get_contents('php://input'),true);
		$items = $data["items"];
		foreach($items as $ks)
		{
			$acno			= base64_decode($ks["acno"]);
			$compcode		= base64_decode($ks["compcode"]);
			
			$q = $this->db->query("select id from tbl_compjoin where acno='$acno' and compcode='$compcode'")->row();
			if($q->id=="")
			{
				$x = $this->db->query("insert into tbl_compjoin set acno='$acno',compcode='$compcode'");	
			}
			$myquery.= "update online_compjoin set status2='1' where acno='$acno' and compcode='$compcode'; ";
		}
		if($myquery!="")
		{
			echo $myquery;
		}
	}
	
	function clean($string) {
		$string = str_replace(' ', '', $string);
		$string = str_replace('-', '', $string);
		// Replaces all spaces with hyphens.
		return preg_replace('/[^A-Za-z0-9\#]/', '', $string); // Removes special chars.
	}
	function clean1($string) {
		$string = str_replace('"', "'", $string);
		$string = str_replace('\'', '', $string);
		return $string;
	}
	
	/*****************18-12-19************************/
	
	public function delete_all_master()
	{
		error_reporting(0);
		$x = $this->db->query("TRUNCATE TABLE tbl_master");
		if($x)
		{
			echo "ok";
		}
	}

	public function upload_all_master()
	{
		$time = time();
		$this->db->query("update tbl_exe_info set time='$time' where exe='s2'");
		
		error_reporting(0);
		$myquery = "";
		$data = json_decode(file_get_contents('php://input'),true);
		$items = $data["items"];
		foreach($items as $ks)
		{
			$code		= base64_decode($ks["code"]);
			$altercode	= base64_decode($ks["altercode"]);
			$slcd 		= base64_decode($ks["slcd"]);
			$name		= base64_decode($ks["name"]);
			$telephone	= base64_decode($ks["telephone"]);
			$telephone1	= base64_decode($ks["telephone1"]);
			$mobile		= base64_decode($ks["mobile"]);
			$email		= base64_decode($ks["email"]);
			$status		= base64_decode($ks["status"]);
			$transport	= base64_decode($ks["transport"]);
			$trimname	= base64_decode($ks["trimname"]);	

			$dt = array(
			'code'=>$code,
			'altercode'=>$altercode,
			'slcd'=>$slcd,
			'name'=>$name,
			'telephone'=>$telephone,
			'telephone1'=>$telephone1,
			'mobile'=>$mobile,
			'email'=>$email,
			'status'=>$status,
			'transport'=>$transport,
			'trimname'=>$trimname,
			);			

			$q = $this->db->query("select id from tbl_master where code='$code'")->row();
			if($q->id=="")
			{
				$x = $this->Scheme_Model->insert_fun("tbl_master",$dt);

				$status = "1";
				$exp_date = "2021-01-01";			

				$qr = $this->db->query("select * from tbl_master_other where code='$code'")->row();
				if($qr->id=="")
				{
					$x = $this->db->query("insert into tbl_master_other set code='$code',status='$status',exp_date='$exp_date'");
				}
			}
			else
			{
				$where = array('code'=>$code);
				$x = $this->Scheme_Model->edit_fun("tbl_master",$dt,$where);
			}
			$myquery.= "update online_web_master set status2='1' where code='$code'; ";
		}
		if($myquery!="")
		{
			echo $myquery;
		}
	}
	
	public function get_new_order_in_server()
	{
		error_reporting(0);
		$time = time();
		$this->db->query("update tbl_exe_info set time='$time' where exe='s2'");

		$q = $this->db->query("select distinct temp_rec from tbl_order where download_status='0' limit 1")->row();
		
		$new_temp_rec = time(); // yha temp rec nichay drd database ne temp rec banta ha
		$result = $this->db->query("select * from tbl_order where download_status='0' and temp_rec='$q->temp_rec'")->result();
		foreach($result as $row)
		{
			
$items .= "('$row->id','$row->order_id','$row->item_code','$row->quantity','$row->chemist_id','$row->user_type','$row->chemist_id','$row->temp_rec','$row->order_status','$row->remarks','$row->sale_rate',$new_temp_rec),";
		}
if ($items != '') {
	$items = substr($items, 0, -1);
}
if($items)
		{
?>
INSERT INTO online_web_order (online_id,order_id,item_code,quantity,chemist_id,user_type,salesman_id,temp_rec,order_status,remarks,sale_rate,new_temp_rec) VALUES <?= $items;?>;<?= $row->order_id ?>
<?php
		}
	}
	
	public function update_online_rec_insert_sucessfuly_on_esysol($order_id)
	{
		$this->db->query("update tbl_order set download_status='1' where order_id='$order_id'");
		echo "ok";
	}
	
	public function insert_gstvno_on_server()
	{
		error_reporting(0);
		$time = time();
		$this->db->query("update tbl_exe_info set time='$time' where exe='s2'");
		
		$data = json_decode(file_get_contents('php://input'),true);
		$items = $data["items"];
		foreach($items as $ks)
		{
			$gstvno 			= base64_decode($ks["gstvno"]);
			$ordno_new 			= base64_decode($ks["ordno_new"]);
			$odt 				= base64_decode($ks["odt"]);
			$temp_rec			= base64_decode($ks["temp_rec"]);			

			$x = $this->db->query("update tbl_order set gstvno='$gstvno',ordno_new='$ordno_new',odt='$odt' where temp_rec='$temp_rec'");
		}
		if($x!="")
		{
			?>
update online_web_order set order_status='3' where ordno_new='<?php echo $ordno_new ?>' and odt='<?php echo $odt ?>';
			<?php
			die;
		}
	}
}