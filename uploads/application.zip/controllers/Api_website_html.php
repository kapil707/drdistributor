<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Api_website_html extends CI_Controller {
	public function slider(){
		$data['result'] = $this->db->query("select * from tbl_slider")->result();
		$this->load->view('android/android_mobile_slider', $data);
	}
	public function website_slider(){
		$data['result'] = $this->db->query("select * from tbl_slider")->result();
		$this->load->view('android/website_slider', $data);
	}
	public function download_invoice_pdf_file_chemist_report($gstvno,$usercode,$vdt)
	{
		error_reporting(0);		$gstvno 	= base64_decode($gstvno);
		$usercode 	= base64_decode($usercode);
		$vdt 		= base64_decode($vdt);
		/*if($_SESSION['invexport']=="E")
		{*/			//$this->auth_model->download_invoice_pdf_file_chemist_report($gstvno,$usercode,$vdt);
		//}
	}
	public function send_email_invoice_chemist_report($gstvno,$usercode,$vdt)
	{
		error_reporting(0);
		$gstvno 	= base64_decode($gstvno);
		$acno 		= base64_decode($usercode);
		$vdt 		= base64_decode($vdt);
		$q = $this->db->query("select * from tbl_sales_main where gstvno='$gstvno' and acno='$acno' and vdt='$vdt'")->result();
		foreach($q as $row)
		{
			$this->Email_Model->chemist_invoice_report($row->gstvno,$row->acno,$row->vdt,$row->time,$row->url_link);
		}
	}
	public function download_invoice_txt_file_chemist_report($gstvno,$usercode,$vdt)
	{
		error_reporting(0);
		$gstvno 	= base64_decode($gstvno);
		$usercode 	= base64_decode($usercode);
		$vdt 		= base64_decode($vdt);
		
		$this->Excel_Model->chemist_invoice_report_txt($gstvno,$acno,$vdt,"");
	}
	public function download_invoice_excel_chemist_report($gstvno,$usercode,$vdt)
	{
		error_reporting(0);
		$gstvno 	= base64_decode($gstvno);
		$usercode 	= base64_decode($usercode);
		$vdt 		= base64_decode($vdt);
		
		$this->Excel_Model->chemist_invoice_report_excel($gstvno,$usercode,$vdt,"");
		exit;
	}	
	public function insert_order()	{
		error_reporting(0);
		$user_type 		= $_GET["user_type"];
		$selesman_id 	= $_GET["selesman_id"];
		$chemist_id		= $_GET["chemist_id"];
		$remarks		= $_GET["remarks"];
		$order_type		= $_GET["order_type"];
		$filename		= $_GET["filename"];
		$temp_rec		= $_GET["temp_rec"];
		$slice_type		= $_GET["slice_type"];
		$slice_item		= $_GET["slice_item"];
		$join_temp		= $_GET["join_temp"];
		if($user_type=="chemist")
		{
			$selesman_id = "";
		}
		if($user_type!="")
		{
			$item_id 	= $_GET["item_id"];
			$item_qty 	= $_GET["item_qty"];
			$item_id 	= explode(',',$item_id);
			$item_qty 	= explode(',',$item_qty);
			$count 		= count($item_id);
			for($x=0;$x<$count;$x++)
			{
				$posts[] = array('join_temp'=>$join_temp,'order_type'=>$order_type,'filename'=>$filename,'user_type'=>$user_type,'chemist_id'=>$chemist_id,'selesman_id'=>$selesman_id,'remarks'=>$remarks,'slice_type'=>$slice_type,'slice_item'=>$slice_item,'item_id'=>$item_id[$x],'item_qty'=>$item_qty[$x],);
			}
			$time=time();
			//$response['posts'] = $posts;
			$fp = fopen('uplaods_order/order_'.$time.'.json', 'w');
			fwrite($fp, json_encode($posts));
			fclose($fp);
			echo "ok";
		}
	}
	
	public function import_orders_delete_items()
	{
		error_reporting(0);	
		
		$date 		= date('Y-m-d');
		$time 		= time();
		
		$chemist_id 	= $_GET["chemist_id"];
		$temp_rec 		= $_GET["temp_rec"];
		$selesman_id 	= $_GET["selesman_id"];
		$user_type 		= $_GET["user_type"];
		$your_item_name	= $_GET["your_item_name"];
		$your_item_mrp	= $_GET["your_item_mrp"];
		$order_type		= $_GET["order_type"];
		if($chemist_id==null)
		{
			$chemist_id = "";
		}
		
		if($user_type=="chemist")
		{
			$users = $this->db->query("select * from tbl_acm where altercode='$chemist_id' ")->row();
			$acm_altercode 	= $users->altercode;
			$acm_name		= $users->name;
			$acm_email 		= $users->email;
			$acm_mobile 	= $users->mobile;			
			
			$chemist_excle 	= "$acm_name ($acm_altercode)";
			$file_name 		= $acm_altercode;
		}
		if($user_type=="sales")
		{
			//jab sale man say login hota ha to
			$users = $this->db->query("select * from tbl_acm where altercode='$chemist_id' ")->row();
			$user_session	= $users->id;
			$acm_altercode 	= $users->altercode;
			$acm_name 		= $users->name;
			$acm_email 		= $users->email;
			$acm_mobile 	= $users->mobile;

			$users = $this->db->query("select * from tbl_users where customer_code='$selesman_id' ")->row();
			$salesman_name 		= $users->firstname." ".$users->lastname;
			$salesman_mobile	= $users->cust_mobile;
			$salesman_altercode	= $users->customer_code;
			
			$chemist_excle 	= $acm_name." ($acm_altercode)";
			$file_name 		= $acm_altercode;
		}
		if($user_type!="")
		{
			$your_item_name = $_GET["your_item_name"];
			$your_item_mrp 	= $_GET["your_item_mrp"];
			$item_qty 		= $_GET["item_qty"];
			$your_item_name = explode(',',$your_item_name);
			$your_item_mrp = explode(',',$your_item_mrp);
			$item_qty = explode(',',$item_qty);
			$count = count($item_qty);
			$i = 0;
			for($x=0;$x<$count;$x++)
			{
				$i++;
				$xx = base64_decode($your_item_name[$x]);
				$yy = $your_item_mrp[$x];
				$zz = $item_qty[$x];
				
				$dt1 = "<br><table border='1' width='100%'><tr><td>Sno</td><td>Deleted Item Name</td><td>Deleted Item Mrp.</td><td>Deleted Item Quantity</td></tr>";

				$dt.= "<tr><td>".$i."</td><td>".$xx."</td><td>".$yy."</td><td>".$zz."</td></tr>";
				$dt2.= "</table>";
				
				$this->db->query("insert into tbl_delete_import set your_item_name='$xx',your_item_mrp='$yy',item_qty='$zz',acm_altercode='$acm_altercode',salesman_altercode='$salesman_altercode',user_type='$user_type',date='$date',time='$time'");
			}
			$message = $dt1.$dt.$dt2;
			$this->Email_Model->import_orders_delete_items($message,$acm_altercode,$acm_email,$date,$time);
		}
	}
	
	/*************************staff****************************/
	public function staff_download_item_wise_report($user_session,$user_division,$user_compcode,$formdate,$todate)
	{
		error_reporting(0);
		$user_session  = base64_decode($user_session);
		$user_division = base64_decode($user_division);
		$user_compcode = base64_decode($user_compcode);
		$from 	= date("Y-m-d",strtotime($formdate));
		$to 	= date("Y-m-d",strtotime($todate));		
		
		$this->Excel_Model->staff_download_item_wise_report($user_session,$user_division,$user_compcode,$from,$to,"direct_download");
	}
	
	public function staff_download_item_wise_report_month($user_session,$user_division,$user_compcode,$monthdate)
	{
		error_reporting(0);
		$user_session  = base64_decode($user_session);
		$user_division = base64_decode($user_division);
		$user_compcode = base64_decode($user_compcode);
		
		$date 	= date('Y-m');
		$year  	= date('Y');
		$date 	= "$year-{$monthdate}";
		$ts 	= strtotime($date);
		$from 	= date('Y-m-01',$ts);
		$to 	= date('Y-m-t',$ts);
		
		$this->Excel_Model->staff_download_item_wise_report($user_session,$user_division,$user_compcode,$from,$to,"direct_download");
	}
	
	public function staff_download_chemist_wise_report($user_session,$user_division,$user_compcode,$formdate,$todate)
	{
		error_reporting(0);
		$user_session  = base64_decode($user_session);
		$user_division = base64_decode($user_division);
		$user_compcode = base64_decode($user_compcode);
		$from 	= date("Y-m-d",strtotime($formdate));
		$to 	= date("Y-m-d",strtotime($todate));		
		
		$this->Excel_Model->staff_download_chemist_wise_report($user_session,$user_division,$user_compcode,$from,$to,"direct_download");
	}
	
	public function staff_download_chemist_wise_report_month($user_session,$user_division,$user_compcode,$monthdate)
	{
		error_reporting(0);
		$user_session  = base64_decode($user_session);
		$user_division = base64_decode($user_division);
		$user_compcode = base64_decode($user_compcode);
		
		$date 	= date('Y-m');
		$year  	= date('Y');
		$date 	= "$year-{$monthdate}";
		$ts 	= strtotime($date);
		$from 	= date('Y-m-01',$ts);
		$to 	= date('Y-m-t',$ts);
		
		$this->Excel_Model->staff_download_chemist_wise_report($user_session,$user_division,$user_compcode,$from,$to,"direct_download");
	}
	
	/******************27-01-2020*********************/
	public function staff_download_stock_and_sales_analysis($user_session,$user_division,$user_compcode)
	{
		error_reporting(0);
		$session 	= $user_session = base64_decode($user_session);
		$division 	= $user_division = base64_decode($user_division);
		$compcode 	= $user_compcode = base64_decode($user_compcode);
		
		$time 	= time();
		$year 	= date("Y",$time);
		$month 	= date("m",$time);
		$d1 	= "01".date("-M-Y",$time);
		$d2 	= date("d-M-Y",$time);
		$vdt1 	= date("Y-m-",$time)."01";
		$vdt2 	= date("Y-m-d",$time);
		
		$row = $this->db->query("select stock_and_sales_analysis,tbl_staffdetail_other.status from tbl_staffdetail,tbl_staffdetail_other where tbl_staffdetail.division='$division' and tbl_staffdetail.compcode='$compcode' and tbl_staffdetail.code=tbl_staffdetail_other.code and tbl_staffdetail.id='$session'")->row();
		$stock_and_sales_analysis = $row->stock_and_sales_analysis;
		$status = $row->status;
		if($stock_and_sales_analysis=="1" && $status=="1")
		{
			$this->Excel_Model->staff_download_stock_and_sales_analysis($user_session,$user_division,$user_compcode,$year,$month,$d1,$d2,$vdt1,$vdt2,"direct_download");
		}
	}
}