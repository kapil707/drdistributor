<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Api_mobile_html extends CI_Controller {
	public function slider(){
		$data['result'] = $this->db->query("select * from tbl_slider")->result();
		$this->load->view('android/android_mobile_slider', $data);
	}
	public function myorders($user_type,$id){
		error_reporting(0);
		if($user_type=="chemist")
		{
			$acm = $this->db->query("select * from acm where altercode='$id'")->row();
			$id = $acm->id;
		}
		$data['user_type'] = $user_type;
		$data['list'] = $this->auth_model->get_orderList("customer_code",$id);
		$this->load->view('android/myorders', $data);
	}	
	public function my_invoice($user_type,$id){
		error_reporting(0);
		if($user_type=="chemist")
		{
			$acm = $this->db->query("select * from acm where altercode='$id'")->row();
			$id = $acm->id;
		}
		$data['usercode'] = $acm->code;
		$data['invexport'] = $acm->invexport;
		$data['user_type'] = $user_type;
		$this->load->view('android/my_invoice',$data);	}	
	public function send_email_invoice_chemist_report($invexport,$gstvno,$usercode,$vdt)
	{
		error_reporting(0);
		$gstvno 	= base64_decode($gstvno);
		$usercode 	= base64_decode($usercode);
		$vdt 		= base64_decode($vdt);
		/*if($_SESSION['invexport']=="E")
		{*/
			$this->Email_Model->send_email_invoice_chemist_report($gstvno,$usercode,$vdt,"");
		//}
	}
	public function download_invoice_txt_file_chemist_report($invexport,$gstvno,$usercode,$vdt)
	{
		error_reporting(0);
		if($invexport=="Y")
		{
			$gstvno 	= base64_decode($gstvno);
			$usercode 	= base64_decode($usercode);
			$vdt 		= base64_decode($vdt);			
			$txt = $this->Excel_Model->download_invoice_txt_file_chemist_report($gstvno,$usercode,$vdt);
			$this->load->helper('download');
			$data = $txt[0];
			$name = substr($txt[1],0,19);
			$name = $gstvno."_D.R.DISTRIBUTORS PVT_".$name.".txt";
			force_download($name, $data,TRUE);
		}
	}
	public function download_invoice_excel_chemist_report($invexport,$gstvno,$usercode,$vdt)
	{
		error_reporting(0);
		if($invexport=="E")
		{
			$gstvno 	= base64_decode($gstvno);
			$usercode 	= base64_decode($usercode);
			$vdt 		= base64_decode($vdt);
			$this->Excel_Model->download_invoice_excel_chemist_report($gstvno,$usercode,$vdt,"");
		}
	}	
	/*public function insert_order()
	{
		error_reporting(0);	
		$user_session 	= $_REQUEST["user_session"];
		$user_type 		= $_REQUEST["user_type"];
		$user_code 		= $_REQUEST["user_code"];
		$user_altercode = $_REQUEST["user_altercode"];
		$chemist_id		= $_REQUEST["chemist_id"];
		if($user_session!="")
		{
			$order_type = "android";
			$item_id = $_REQUEST["item_id"];
			$item_qty = $_REQUEST["item_qty"];			$item_id = explode(',',$item_id);
			$item_qty = explode(',',$item_qty);
			$count = count($item_id);
			for($x=0;$x<$count;$x++)
			{
				$posts[] = array('order_type'=>$order_type,'user_session'=>$user_session,'user_type'=>$user_type,'user_code'=>$user_code,'user_altercode'=>$user_altercode,'chemist_id'=>$chemist_id,'item_id'=>$item_id[$x],'item_qty'=>$item_qty[$x]);
			}
			$time=time();
			//$response['posts'] = $posts;
			$fp = fopen('uplaods_order/order_'.$time.'.json', 'w');
			fwrite($fp, json_encode($posts));
			fclose($fp);
			echo "ok";
		}
	}*/
	public function item_wise_report()
	{	
		error_reporting(0);
		if(isset($_GET["submit"]))
		{
			date_default_timezone_set('Asia/Kolkata');
			$from = date("Y-m-d",strtotime($_GET["from"]));
			$to = date("Y-m-d",strtotime($_GET["to"]));		
			if($_GET["month"]!="")
			{
				if(isset($_GET["month"]))
				{
					$date = date('Y-m');
					$year  = date('Y');
					$date = "$year-{$_REQUEST["month"]}";
					$ts = strtotime($date);
					$from = date('Y-m-01',$ts);
					$to = date('Y-m-t',$ts);
				}
			}
			$division = $_REQUEST['division'];
			$compcode = $_REQUEST['compcode'];
			$myitem_code = "";
			if(isset($_GET["item_code"]))
			{
				if($_GET["item_code"]!="")
				{
					$item_code = $_GET["item_code"];
					$myitem_code = " and cp.item_code='$item_code' ";
				}
			}			
			$query = $this->db->query("select * from online_main_sales_tbl where division='$division' and compcode='$compcode' and vdt >= '$from' and vdt <= '$to' and mdatatype='insert' order by acno desc")->result();
			$item_name = [];
			$batchqty = [];
			$item_codes = [];
			$row_id = [];
			$acno = [];
			$qty = [];
			$fqty = [];
			$gstvno = [];
			$i = 0;
			foreach ($query as $value)
			{
				$key = array_search($value->itemc, $last_names);
				$item_name[$value->itemc] = $key;
				$kap = $result123[$key];
				$item_name[$value->itemc] = $kap["item_name"];
				$batchqty[$value->itemc] = $kap["batchqty"];
				$item_codes[$i] = $value->itemc;
				$row_id[$i] = $value->id;
				$acno[$i] = $value->acno;
				$gstvno[$value->itemc][$value->acno][$i] = $value->gstvno;
				$inv_vdt[$value->gstvno] = $value->vdt;				$inv_vno[$value->gstvno] = $value->vno;
				$qty[$value->itemc][$value->acno] = $qty[$value->itemc][$value->acno] + $value->qty;
				$fqty[$value->itemc][$value->acno] = $fqty[$value->itemc][$value->acno] + $value->fqty;
				$i++;
			}
			for($x = 0;$x<$i;$x++)
			{
				$y = $item_codes[$x];
				$row_id1["$y"][$x] = $row_id[$x];
				$acno1["$y"][$x] = $acno[$x];
			}
		}
		$item_codes = array_unique($item_codes);
		$data["item_name"] = $item_name;
		$data["batchqty"] = $batchqty;
		$data["item_codes"] = $item_codes;
		$data["row_id1"] = $row_id1;
		$data["acno1"] = $acno1;
		$data["qty"] = $qty;
		$data["fqty"] = $fqty;
		$data["gstvno"] = $gstvno;
		$data["inv_vdt"] = $inv_vdt;
		$data["inv_vno"] = $inv_vno;	
		$this->load->view('android/item_wise_report',$data);	}
	public function item_wise_report_month()
	{		error_reporting(0);
		if(isset($_GET["submit"]))
		{
			date_default_timezone_set('Asia/Kolkata');
			$from = date("Y-m-d",strtotime($_GET["from"]));
			$to = date("Y-m-d",strtotime($_GET["to"]));		
			if($_GET["month"]!="")
			{
				if(isset($_GET["month"]))
				{
					$date = date('Y-m');
					$year  = date('Y');
					$date = "$year-{$_REQUEST["month"]}";
					$ts = strtotime($date);
					$from = date('Y-m-01',$ts);
					$to = date('Y-m-t',$ts);
				}
			}
			$division = $_REQUEST['division'];
			$compcode = $_REQUEST['compcode'];
			$myitem_code = "";
			if(isset($_GET["item_code"]))
			{
				if($_GET["item_code"]!="")
				{
					$item_code = $_GET["item_code"];
					$myitem_code = " and cp.item_code='$item_code' ";
				}
			}		
			$query = $this->db->query("select * from online_main_sales_tbl where division='$division' and compcode='$compcode' and vdt >= '$from' and vdt <= '$to' and mdatatype='insert' order by acno desc")->result();
			$item_name = [];
			$batchqty = [];
			$item_codes = [];
			$row_id = [];
			$acno = [];
			$qty = [];
			$fqty = [];
			$gstvno = [];
			$i = 0;
			foreach ($query as $value)
			{				$key = array_search($value->itemc, $last_names);
				$item_name[$value->itemc] = $key;
				$kap = $result123[$key];
				$item_name[$value->itemc] = $kap["item_name"];
				$batchqty[$value->itemc] = $kap["batchqty"];				
				$item_codes[$i] = $value->itemc;
				$row_id[$i] = $value->id;
				$acno[$i] = $value->acno;
				$gstvno[$value->itemc][$value->acno][$i] = $value->gstvno;
				$inv_vdt[$value->gstvno] = $value->vdt;
				$inv_vno[$value->gstvno] = $value->vno;
				$qty[$value->itemc][$value->acno] = $qty[$value->itemc][$value->acno] + $value->qty;
				$fqty[$value->itemc][$value->acno] = $fqty[$value->itemc][$value->acno] + $value->fqty;
				$i++;
			}
			for($x = 0;$x<$i;$x++)
			{
				$y = $item_codes[$x];
				$row_id1["$y"][$x] = $row_id[$x];
				$acno1["$y"][$x] = $acno[$x];
				//$gstvno_new["$y"][$x] = $acno[$x];
			}
		}
		$item_codes = array_unique($item_codes);
		$data["item_name"] = $item_name;
		$data["batchqty"] = $batchqty;
		$data["item_codes"] = $item_codes;
		$data["row_id1"] = $row_id1;
		$data["acno1"] = $acno1;
		$data["qty"] = $qty;
		$data["fqty"] = $fqty;
		$data["gstvno"] = $gstvno;
		$data["inv_vdt"] = $inv_vdt;
		$data["inv_vno"] = $inv_vno;		
		$this->load->view('android/item_wise_report_month',$data);
	}
	public function chemist_wise_report()
	{
		error_reporting(0);
		if(isset($_GET["submit"]))
		{
			date_default_timezone_set('Asia/Kolkata');
			$from = date("Y-m-d",strtotime($_GET["from"]));
			$to = date("Y-m-d",strtotime($_GET["to"]));
			if(isset($_GET["month"]))
			{
				$date = date('Y-m');
				$year  = date('Y');
				$date = "$year-{$_REQUEST["month"]}";
				$ts = strtotime($date);
				$from = date('Y-m-01',$ts);
				$to = date('Y-m-t',$ts);
			}			
			$division = $_REQUEST['division'];
			$compcode = $_REQUEST['compcode'];
			$myacm = "";
			if(isset($_GET["select_user"]))
			{
				if($_GET["select_user"]!="")
				{
					$ac = $_GET["select_user"];
					$myacm = " and ol.acno='$ac' ";
				}
			}
			$query = $this->db->query("select * from online_main_sales_tbl where gdn='0' and division='$division' and compcode='$compcode' and vdt >= '$from' and vdt <= '$to' and mdatatype='insert' order by itemc desc")->result();
			$item_name = [];
			$batchqty = [];
			$item_codes = [];
			$row_id = [];
			$acno = [];
			$qty = [];
			$fqty = [];
			$i = 0;
			foreach ($query as $value)
			{
				$key = array_search($value->itemc, $last_names);
				$item_name[$value->itemc] = $key;
				$kap = $result123[$key];
				$item_name[$value->itemc] = $kap["item_name"];
				$item_code[$i] = $value->itemc;
				$acno[$i] = $value->acno;
				$gstvno[$value->acno] = $value->gstvno;
				$qty[$value->acno][$value->itemc] = 
				$qty[$value->acno][$value->itemc] + $value->qty;
				
				$fqty[$value->acno][$value->itemc] = 
				$fqty[$value->acno][$value->itemc] + $value->fqty;
				$i++;
			}			
			for($x = 0;$x<$i;$x++)
			{
				$y = $acno[$x];				//$item_name1["$y"][$x] = $item_name[$x]. "(".$item_codes[$x].")";
				$item_code1["$y"][$x] = $item_code[$x];
			}
		}
		$acno = array_unique($acno);
		$data["acnos"] = $acno;
		$data["item_name"] = $item_name;
		$data["item_code1"] = $item_code1;
		$data["qty"] = $qty;
		$data["fqty"] = $fqty;	
		$this->load->view('android/chemist_wise_report',$data);
	}	
	public function chemist_wise_report_month(){
		error_reporting(0);		if(isset($_GET["submit"]))
		{
			date_default_timezone_set('Asia/Kolkata');
			$from = date("Y-m-d",strtotime($_GET["from"]));
			$to = date("Y-m-d",strtotime($_GET["to"]));
			if(isset($_GET["month"]))
			{				$date = date('Y-m');
				$year  = date('Y');
				$date = "$year-{$_REQUEST["month"]}";
				$ts = strtotime($date);
				$from = date('Y-m-01',$ts);
				$to = date('Y-m-t',$ts);
			}
			$division = $_REQUEST['division'];
			$compcode = $_REQUEST['compcode'];
			$myacm = "";
			if(isset($_GET["select_user"]))
			{
				if($_GET["select_user"]!="")
				{
					$ac = $_GET["select_user"];
					$myacm = " and ol.acno='$ac' ";
				}
			}		
			$query = $this->db->query("select * from online_main_sales_tbl where gdn='0' and division='$division' and compcode='$compcode' and vdt >= '$from' and vdt <= '$to' and mdatatype='insert' order by itemc desc")->result();
			$item_name = [];
			$batchqty = [];
			$item_codes = [];
			$row_id = [];
			$acno = [];
			$qty = [];
			$fqty = [];
			$i = 0;
			foreach ($query as $value)
			{
				$key = array_search($value->itemc, $last_names);
				$item_name[$value->itemc] = $key;				$kap = $result123[$key];
				$item_name[$value->itemc] = $kap["item_name"];
				$item_code[$i] = $value->itemc;
				//$item_name[$value->itemc] = $ci_pharmacy->item_name;
				$acno[$i] = $value->acno;
				$gstvno[$value->acno] = $value->gstvno;
				$qty[$value->acno][$value->itemc] = 
				$qty[$value->acno][$value->itemc] + $value->qty;
				
				$fqty[$value->acno][$value->itemc] = 
				$fqty[$value->acno][$value->itemc] + $value->fqty;
				$i++;
			}
			for($x = 0;$x<$i;$x++)			{				$y = $acno[$x];
				//$item_name1["$y"][$x] = $item_name[$x]. "(".$item_codes[$x].")";
				$item_code1["$y"][$x] = $item_code[$x];
			}
		}		$acno = array_unique($acno);
		$data["acnos"] = $acno;
		$data["item_name"] = $item_name;
		$data["item_code1"] = $item_code1;
		$data["qty"] = $qty;
		$data["fqty"] = $fqty;		
		$this->load->view('android/chemist_wise_report_month',$data);
	}}