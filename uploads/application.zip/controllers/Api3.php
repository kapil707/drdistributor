<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Api3 extends CI_Controller {
	public function delete_all_rec()
	{
		$x = $this->db->query("TRUNCATE TABLE tbl_sales");
		$x = $this->db->query("TRUNCATE TABLE tbl_sales_main");
		$x = $this->db->query("TRUNCATE TABLE tbl_sales_staff");
		if($x)
		{
			echo "ok";
		}
		$files = glob("temp_rec_folder/*.xls");
		for($i=0;$i<count($files);$i++)
		{
			if(is_file($files[$i])){
				//Use the unlink function to delete the file.
				unlink($files[$i]);
			}
		}
		
		$files = glob("temp_rec_folder/*.txt");
		for($i=0;$i<count($files);$i++)
		{
			if(is_file($files[$i])){
				//Use the unlink function to delete the file.
				unlink($files[$i]);
			}
		}
		
		$files = glob("uploads_skip_invoice/*.json");
		for($i=0;$i<count($files);$i++)
		{
			if(is_file($files[$i])){
				//Use the unlink function to delete the file.
				unlink($files[$i]);
			}
		}
	}
	public function cronjobinsert($pending)
	{
		$time = time();
		$this->db->query("update tbl_exe_info set time='$time',pending='$pending' where exe='s3'");
		
		$myks = 0;
		$myquery = "";
		$x = "0";
		error_reporting(0);
		$data = json_decode(file_get_contents('php://input'),true);
		$items = $data["items"];
		foreach($items as $ks)
		{
			$amt			= base64_decode($ks["amt"]);
			$gstvno			= base64_decode($ks["gstvno"]);
			$acno 			= base64_decode($ks["acno"]);
			$vno			= base64_decode($ks["vno"]);
			$vdt 			= base64_decode($ks["vdt"]);
			$psrlno 		= base64_decode($ks["psrlno"]);
			$itemc 			= base64_decode($ks["itemc"]);
			$batch 			= base64_decode($ks["batch"]);
			$qty			= base64_decode($ks["qty"]);
			$fqty 			= base64_decode($ks["fqty"]);
			$ntrate			= base64_decode($ks["ntrate"]);
			$ftrate 		= base64_decode($ks["ftrate"]);
			$taxamt 		= base64_decode($ks["taxamt"]);
			$dis 			= base64_decode($ks["dis"]);
			$disamt 		= base64_decode($ks["disamt"]);
			$netamt 		= base64_decode($ks["netamt"]);
			$status 		= base64_decode($ks["status"]);
			$halfp 			= base64_decode($ks["halfp"]);
			$mrp 			= base64_decode($ks["mrp"]);
			$hsncode 		= base64_decode($ks["hsncode"]);
			$expiry 		= base64_decode($ks["expiry"]);
			$scm1 			= base64_decode($ks["scm1"]);
			$scm2 			= base64_decode($ks["scm2"]);
			$scmper 		= base64_decode($ks["scmper"]);
			$localcent 		= base64_decode($ks["localcent"]);
			$excise 		= base64_decode($ks["excise"]);
			$cgst 			= base64_decode($ks["cgst"]);
			$sgst 			= base64_decode($ks["sgst"]);
			$igst 			= base64_decode($ks["igst"]);
			$adnlvat 		= base64_decode($ks["adnlvat"]);
			$gdn 			= base64_decode($ks["gdn"]);
			$compcode		= base64_decode($ks["compcode"]);
			$division		= base64_decode($ks["division"]);
			$item_name		= base64_decode($ks["item_name"]);
			$item_code		= base64_decode($ks["item_code"]);
			$packing		= base64_decode($ks["packing"]);
			$comp_name		= base64_decode($ks["comp_name"]);
			$comp_shortname	= base64_decode($ks["comp_shortname"]);
			$vtype			= base64_decode($ks["vtype"]);
			$mdatatype 		= ($ks["mdatatype"]);						

			$old_date_timestamp = strtotime($vdt);
			$vdt = date('Y-m-d H:i:s', $old_date_timestamp); 
			$date_time = time();			

			$delete_slcd	= base64_decode($ks["delete_slcd"]);
			$delete_amt		= base64_decode($ks["delete_amt"]);
			$delete_namt	= base64_decode($ks["delete_namt"]);
			$delete_remarks	= base64_decode($ks["delete_remarks"]);
			$delete_descp	= base64_decode($ks["delete_descp"]);			

			$posts[] = array('amt'=>$amt,'gstvno'=>$gstvno,'acno'=>$acno,'vno'=>$vno,'vdt'=>$vdt,'psrlno'=>$psrlno,'itemc'=>$itemc,'batch'=>$batch,'qty'=>$qty,'fqty'=>$fqty,'ntrate'=>$ntrate,'ftrate'=>$ftrate,'taxamt'=>$taxamt,'dis'=>$dis,'disamt'=>$disamt,'netamt'=>$netamt,'halfp'=>$halfp,'mrp'=>$mrp,'hsncode'=>$hsncode,'expiry'=>$expiry,'scm1'=>$scm1,'scm2'=>$scm2,'scmper'=>$scmper,'localcent'=>$localcent,'excise'=>$excise,'cgst'=>$cgst,'sgst'=>$sgst,'igst'=>$igst,'adnlvat'=>$adnlvat,'gdn'=>$gdn,'compcode'=>$compcode,'division'=>$division,'item_name'=> $item_name,'item_code'=>$item_code,'comp_name'=>$comp_name,'comp_shortname'=>$comp_shortname,'vtype'=>$vtype,'status'=>$status,'mdatatype'=>$mdatatype,'delete_slcd'=>$delete_slcd,'delete_amt'=>$delete_amt,'delete_namt'=>$delete_namt,'delete_remarks'=>$delete_remarks,'delete_descp'=>$delete_descp,'date_time'=>$date_time);

			$myquery.= "update online_web_sales_imports set status2='1' where vno='$vno'";
		}
		if($myquery!="")
		{
			//$time=time();
			echo $myquery;
			//$response['posts'] = $posts;
			$fp = fopen('uploads_skip_invoice/'.$gstvno.'.json', 'w');
			fwrite($fp, json_encode($posts));
			fclose($fp);
		}
	}

	public function index($pending)
	{
		$time = time();
		$this->db->query("update tbl_exe_info set time='$time',pending='$pending' where exe='s3'");
				$myks = 0;
		$myquery = "";
		$x = "0";
		error_reporting(0);
		$data = json_decode(file_get_contents('php://input'),true);
		$items = $data["items"];
		foreach($items as $ks)
		{
			$amt			= base64_decode($ks["amt"]);
			$gstvno			= base64_decode($ks["gstvno"]);
			$acno 			= base64_decode($ks["acno"]);
			$vno			= base64_decode($ks["vno"]);
			$vdt 			= base64_decode($ks["vdt"]);
			$psrlno 		= base64_decode($ks["psrlno"]);
			$itemc 			= base64_decode($ks["itemc"]);
			$batch 			= base64_decode($ks["batch"]);
			$qty			= base64_decode($ks["qty"]);
			$fqty 			= base64_decode($ks["fqty"]);
			$ntrate			= base64_decode($ks["ntrate"]);
			$ftrate 		= base64_decode($ks["ftrate"]);
			$taxamt 		= base64_decode($ks["taxamt"]);
			$dis 			= base64_decode($ks["dis"]);
			$disamt 		= base64_decode($ks["disamt"]);
			$netamt 		= base64_decode($ks["netamt"]);
			$status 		= base64_decode($ks["status"]);
			$halfp 			= base64_decode($ks["halfp"]);
			$mrp 			= base64_decode($ks["mrp"]);
			$hsncode 		= base64_decode($ks["hsncode"]);
			$expiry 		= base64_decode($ks["expiry"]);
			$scm1 			= base64_decode($ks["scm1"]);
			$scm2 			= base64_decode($ks["scm2"]);
			$scmper 		= base64_decode($ks["scmper"]);
			$localcent 		= base64_decode($ks["localcent"]);
			$excise 		= base64_decode($ks["excise"]);
			$cgst 			= base64_decode($ks["cgst"]);
			$sgst 			= base64_decode($ks["sgst"]);
			$igst 			= base64_decode($ks["igst"]);
			$adnlvat 		= base64_decode($ks["adnlvat"]);
			$gdn 			= base64_decode($ks["gdn"]);
			$compcode		= base64_decode($ks["compcode"]);
			$division		= base64_decode($ks["division"]);
			$item_name		= base64_decode($ks["item_name"]);
			$item_code		= base64_decode($ks["item_code"]);
			$packing		= base64_decode($ks["packing"]);
			$comp_name		= base64_decode($ks["comp_name"]);
			$comp_shortname	= base64_decode($ks["comp_shortname"]);
			$escode			= base64_decode($ks["escode"]);
			$vtype			= base64_decode($ks["vtype"]);
			$mdatatype 		= ($ks["mdatatype"]);						
			$old_date_timestamp = strtotime($vdt);
			$vdt 			= date('Y-m-d H:i:s', $old_date_timestamp);
			$delete_slcd	= base64_decode($ks["delete_slcd"]);
			$delete_amt		= base64_decode($ks["delete_amt"]);
			$delete_namt	= base64_decode($ks["delete_namt"]);
			$delete_remarks	= base64_decode($ks["delete_remarks"]);
			$delete_descp	= base64_decode($ks["delete_descp"]);			
			$date			= date('Y-m-d');
			$time			= time();
			$qr = $this->db->query("select id from tbl_sales_main where gstvno='$gstvno'")->row();
			if($qr->id=="")
			{
				$url_link = $this->url_link();
				$this->db->query("insert into tbl_sales_main set amt='$amt',gstvno='$gstvno',vdt='$vdt',acno='$acno',vno='$vno',status='$status',compcode='$compcode',division='$division',comp_name='$comp_name',comp_shortname='$comp_shortname',date='$date',time='$time',url_link='$url_link'");	
			}		
			$x = $this->db->query("insert into tbl_sales set gstvno='$gstvno',vdt='$vdt',psrlno='$psrlno',itemc='$itemc',batch='$batch',qty='$qty',fqty='$fqty',ntrate='$ntrate',ftrate='$ftrate',taxamt='$taxamt',dis='$dis',disamt='$disamt',netamt='$netamt',halfp='$halfp',mrp='$mrp',hsncode='$hsncode',expiry='$expiry',scm1='$scm1',scm2='$scm2',scmper='$scmper',localcent='$localcent',excise='$excise',cgst='$cgst',sgst='$sgst',igst='$igst',adnlvat='$adnlvat',gdn='$gdn',item_name='$item_name',item_code='$item_code',packing='$packing',mdatatype='$mdatatype',delete_slcd='$delete_slcd',delete_amt='$delete_amt',delete_namt='$delete_namt',delete_remarks='$delete_remarks',delete_descp='$delete_descp',escode='$escode',vtype='$vtype'");
				
			if($mdatatype=="insert" && $gdn==0)
			{
				$this->db->query("insert into tbl_sales_staff set gstvno='$gstvno',vdt='$vdt',acno='$acno',compcode='$compcode',division='$division',qty='$qty',fqty='$fqty',ntrate='$ntrate',dis='$dis',netamt='$netamt',item_name='$item_name',item_code='$item_code',itemc='$itemc',packing='$packing',vtype='$vtype'");
			}
			if($mdatatype=="delete")
			{
				$this->db->query("insert into tbl_sales_deleted set gstvno='$gstvno',vdt='$vdt',itemc='$itemc',delete_slcd='$delete_slcd',delete_amt='$delete_amt',delete_namt='$delete_namt',delete_remarks='$delete_remarks',delete_descp='$delete_descp',item_name='$item_name',item_code='$item_code',packing='$packing'");
			}
			$vdt1 = $vdt;
			$myquery.= "update online_web_sales_imports set status2='1' where vno='$vno'";
		}
		if($myquery!="")
		{
			echo $myquery;
		}
	}
	
	public function email_for_staff()
	{
		$vdt = date("Y-m-d");		
		$q = $this->db->query("select distinct stf.memail from tbl_sales as ol,tbl_staffdetail as stf where ol.gdn='0' and ol.vdt= '$vdt' and ol.mdatatype='insert' and stf.compcode=ol.compcode and stf.division=ol.division and ol.stf_email='0' order by stf.memail asc")->result();
		foreach($q as $row)
		{
			echo $row->memail;
			echo "<br>";
		}
		//$this->auth_model->download_invoice_excel_staff($vdt,"email");
	}	
	
	public function url_link() {
		$alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
		$pass = array(); //remember to declare $pass as an array
		$alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
		for ($i = 0; $i < 10; $i++) {
			$n = rand(0, $alphaLength);
			$pass[] = $alphabet[$n];
		}
		return implode($pass); //turn the array into a string
	}

	public function myinv($gstvno,$acno,$vdt)
	{
		$gstvno = base64_decode($gstvno);
		$acno 	= base64_decode($acno);
		$vdt 	= base64_decode($vdt);
		$data["gstvno"] = $gstvno;
		$data["acno"] 	= $acno;
		$data["vdt"] 	= $vdt;
		$this->load->view('myinv',$data);
	}
	public function invoice($url_link)
	{
		$data["url_link"] = $url_link;
		$this->load->view('invoice',$data);
	}
	public function android($altercode)
	{		$x = $this->db->query("insert into tbl_android_download set altercode='$altercode'");
		if($x)
		{			redirect("https://play.google.com/store/apps/details?id=com.drdistributor.dr");
		}
	}
}