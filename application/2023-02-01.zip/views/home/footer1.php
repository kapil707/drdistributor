<script src="
https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" type="text/javascript"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<script>
$(document).ready(function() {
    $('#datatable').DataTable( {
        "order": [[ 1, "asc" ]]
    });
} );
</script>